﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackConsole
{
    class Program
    {
        static Stack stack = new Stack();

        static void Main(string[] args)
        {
            Menu();
        }

        static void Pop()                       //metodo per il pop 
        {
            Console.Clear();
            try
            {
                Console.WriteLine($"POP: " + stack.Pop());              //scrive l'ultimo elemento dell'array
            }
            catch (Exception e)
            {
                Console.WriteLine("Errore" + e.Message);
            }
            Console.WriteLine("\nPremere invio per tornare al menu'");
            Console.ReadLine();
            Menu();
        }

        static void Visualizza()
        {
            Console.Clear();
            stack.Visualizza();
            Menu();
        }

        static void Menu()                              //metodo per il menù di scelta
        {
            Console.Clear();
            int selezione = 0;
            Console.WriteLine("Scegli l'operazione da svolgere");
            Console.WriteLine("1  PUSH");
            Console.WriteLine("2  POP");
            Console.WriteLine("3  NUMERO DI ELEMENTI");
            Console.WriteLine("4  CIMA DELLO STACK");
            Console.WriteLine("5  Visualizza");

            selezione = Convert.ToInt32(Console.ReadLine());
            while (selezione != 1 & selezione != 2 & selezione != 3 & selezione != 4 & selezione != 5)
            {
                Console.WriteLine("Errore. Scelta non valida. Scegliere tra le opzioni che ci sono");
                selezione = Convert.ToInt32(Console.ReadLine());
            }

            switch (selezione)
            {
                case 1: Push(); break;
                case 2: Pop(); break;
                case 3: NumeroElementi(); break;
                case 4: CimaStack(); break;
                case 5: Visualizza(); break;
            }
        }

        static void CimaStack()                                 //scrive l'elemento in cima allo stack 
        {
            Console.Clear();
            if (stack.GetElementi > 0)
            {
                Console.WriteLine($"Elemento in cima allo stack: {stack.ElementoCima}");
            }
            else
            {
                Console.WriteLine("Stack vuoto, inserire degli elementi");
            }
            Console.WriteLine("\nPremere invio per tornare al menu'");
            Console.ReadLine();
            Menu();
        }

        static void Push()                      //Metodo per il push 
        {
            Console.Clear();
            int num = 0;
            try
            {
                Console.WriteLine("Quanti numeri vuoi inserire? ");
                int numeriIns = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < numeriIns; i++)
                {
                    Console.Write("Inserire un numero: ");
                    num = Convert.ToInt32(Console.ReadLine());
                    stack.Push(num);
                }
                Console.WriteLine("\nPremere invio per tornare al menu'");
                Menu();
            }
            catch (Exception)
            {
                Console.WriteLine("impossibile eseguire il push");
            }
        }

        static void NumeroElementi()                    //mi scrive il numero di elementi presenti nello stack 
        {
            Console.Clear();
            if (stack.GetElementi > 0)              //controllo che ci siano elementi nello stack
            {
                Console.WriteLine($"Numero elementi: {stack.GetElementi}");
            }
            else
            {
                Console.WriteLine("Stack vuoto, inserire degli elementi");
            }
            Console.WriteLine("\nPremere invio per tornare al menu'");
            Console.ReadLine();
            Menu();
        }
    }
}
