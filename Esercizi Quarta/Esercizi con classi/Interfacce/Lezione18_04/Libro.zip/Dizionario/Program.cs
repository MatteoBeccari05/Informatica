﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dizionario
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Libro> libri = new List<Libro>();
            libri.Add(new Libro("Matteo", 1000));
            libri.Add(new Libro("Matteo", 1000));
            libri.Add(new Libro("Matteo", 1000));

        }
          
    }
}
