﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dizionario
{
    class Libro
    {
        public Libro(string nome, int pagine)
        {
            Nome = nome;
            Pagine = pagine;
        }

        public string Nome { get; set; }

        public int Pagine { get; set; }
    }
}
