﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfacce
{
    class Program
    {
        static void Main(string[] args)
        {
            Calciatore c1 = new Calciatore("Inzaghi", "Milan");
            c1.Visualizza();
            c1.MetodoCalciatore();
            // IEsempio e1 = new IEsempio();  non posso dato che è astratta
            
            IEsempio e1;
            e1 = c1;
            e1.Visualizza();    //funziona perchè visualizza è istanziato nell'interfaccia

            //e1.MetodoCalciatore();  il metodo calciatore è nella classe calciatore 

            Console.WriteLine();
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine();

            IEsempio[] elenco = new IEsempio[3];
            elenco[0] = new Calciatore("Pogba", "Juventus");
            elenco[1] = new Societa("Polesella Calcio", "ASDFRTYUIO98");
            elenco[2] = new Libro("Becca", 56);
            foreach (IEsempio item in elenco)
            {
                item.Visualizza();
            }


            Console.ReadLine();
        }
    }
}
