﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfacce
{
    class Libro: IEsempio
    {
        string _nome;
        int _pagine;

        public Libro(string nome, int pagine)
        {
            _nome = nome;
            _pagine = pagine;
        }

        public void Visualizza()
        {
            Console.WriteLine($"Nome: {_nome} --  Pagine: {_pagine}");
        }

        public string Nominativo { get { return _nome; } }
    }
}
