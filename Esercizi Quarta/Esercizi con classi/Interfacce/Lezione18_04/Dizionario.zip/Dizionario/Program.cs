﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dizionario
{
    class Program
    {
        static void Main(string[] args)
        {
            //utilizzare 3 collezioni dinamiche: Dictionary, SortedList, SortedDictionary
            //inserire 2 valori all'interno e creare un metodo che stampa tutto 

            Dictionary<int, string> d = new Dictionary<int, string>();

            SortedList<int, string> sl = new SortedList<int, string>();

            SortedDictionary<int, string> sd = new SortedDictionary<int, string>();

            d.Add(12 , "Rizzo");
            d.Add(67, "Becca");

            sl.Add(45, "Matteo");
            sl.Add(32, "Luca");

            sd.Add(78, "Francesco");
            sd.Add(21, "Michele");


            
            Visualizza(d);
            Visualizza(sl);
            Visualizza(sd);

            Console.ReadLine();
        }

        static void Visualizza(IDictionary<int , string> D)
        {
            foreach (KeyValuePair<int, string> K in D)
            {
                Console.WriteLine("Key: " + K.Key + "   " + "Value: " + K.Value);
            }
        }
    }
}
