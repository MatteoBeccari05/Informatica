﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfacce
{
    class Program
    {
        static void Main(string[] args)
        {
            Calciatore c1 = new Calciatore("Dybala", "Roma");
            IEsempio[] elenco = new IEsempio[3]; //flessibilità 
            elenco[0] = new Calciatore("Delfo Bellini", "Genoa");
            elenco[1] = new Libro("Shining", 1000);
            elenco[2] = new Societa("Roma Calcio", "TRGDNL05D19H620K");
            foreach (IEsempio e in elenco)
                e.Visualizza();
            //c1.Visualizza();
            //c1.MetodoCalciatore();
            //IEsempio e1;
            //e1 = c1;
            //e1.Visualizza();
            //e1.MetodoCalciatore() //ERRORE, non si può fare perchè il metodo "MetodoCalciatore" è istanziato nella classe ereditata, e non nell'interfaccia

           Console.ReadLine();
        }
    }
}
