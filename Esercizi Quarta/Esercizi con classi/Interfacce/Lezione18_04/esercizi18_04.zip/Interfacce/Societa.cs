﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfacce
{
    class Societa : ICodiceFiscale, IEsempio
    {
        string _nome;
        string _codiceFiscale;

        public Societa(string nome, string codiceFiscale)
        {
            _nome = nome;
            _codiceFiscale = codiceFiscale;
        }

        public void Visualizza()
        {
            Console.WriteLine($"nome : {_nome}, codice fiscale {_codiceFiscale}");
        }

        public string Nominativo { get { return _nome; } }

        public string CodiceFiscale { get { return _codiceFiscale; } }
    }
}
