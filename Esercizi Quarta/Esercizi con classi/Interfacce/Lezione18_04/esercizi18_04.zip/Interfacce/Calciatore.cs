﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfacce
{
    class Calciatore : IEsempio
    {
        string _nome;
        string _squadra;

        public Calciatore(string nome, string squadra)
        {
            _nome = nome;
            _squadra = squadra;
        }

        public void Visualizza()
        {
            Console.WriteLine($"nome: {_nome}, squadra: {_squadra}");
        }

        public string Nominativo { get {return _nome;} }

        public void MetodoCalciatore()
        {
            Console.WriteLine("Io sono un calciatore (non come Lukaku)");
        }
    }
}
