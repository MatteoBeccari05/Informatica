﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dizionario
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Libro> l = new List<Libro>();
            l.Add(new Libro("Shining", 100));
            l.Add(new Libro("Carlo", 100));
            l.Add(new Libro("bertoncello", 100));
            l.Sort();
        }

        
    }
}
