﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figure_Geometriche
{
    abstract class Figura : IPrint
    {
        public double Lato { get; private set; }
        public Figura(double lato)
        {
            Lato = lato;
        }

        public abstract double Perimetro();
        public abstract double Area();
        public override string ToString()
        {
            return $"{Lato}";
        }
        public abstract void Stampa();
        
    }

    class Quadrato : Figura 
    {
        public Quadrato(double lato):base(lato)
        {

        }
        override public double Perimetro()
        {
            return Lato * 4;
        }

        override public double Area()
        {
            return Lato * Lato;
        }
        public override string ToString()
        {
            return $"SONO UN QUADRATO: Perimetro: {Perimetro()}, Area: {Area()}, Lato: {base.ToString()}";
        }
        public override void Stampa()
        {
            Console.WriteLine($"SONO UN QUADRATO: Perimetro: {Perimetro()}, Area: {Area()}, Lato: {base.ToString()}");
        }

    }

    class Cerchio : Figura 
    {
        public Cerchio(double lato) : base(lato)
        {

        }
        override public double Perimetro()
        {
            return Lato * 2 *Math.PI;
        }

        override public double Area()
        {
            return (double)Math.Pow(Lato, 2) * Math.PI;
        }
        public override string ToString()
        {
            return $"SONO UN CERCHIO: Perimetro: {Perimetro()}, Area: {Area()}, Raggio: {base.ToString()}";
        }
        public override void Stampa()
        {
            Console.WriteLine($"SONO UN CERCHIO: Perimetro: {Perimetro()}, Area: {Area()}, Raggio: {base.ToString()}");
        }

    }
    class Cilindro : IPrint
    {
        public double Altezza { get; private set; }
        Cerchio _cerchio;

        
        public Cilindro( double altezza , double raggio)
        {
            Altezza = altezza;
            _cerchio = new Cerchio(raggio);
        }

        public double Superficie()
        {

            return _cerchio.Area() * Altezza ;
        }
        public double Volume()
        {

            return _cerchio.Perimetro() * Altezza + _cerchio.Area()*2;
        }

        public void Stampa()
        {
            Console.WriteLine($"Volume : {Volume()} , Superficie : {Superficie()}");
        }
    }
}
