﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figure_Geometriche
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Figura> figura = new List<Figura>();
            //Figura f = new Figura(4);
            Quadrato q = new Quadrato(4);
            Quadrato q2 = new Quadrato(8);
            Quadrato q3 = new Quadrato(12);
            Cerchio c = new Cerchio(2);
            Cerchio c2 = new Cerchio(123);
            Cilindro cilindro = new Cilindro(21, 11);
            List<IPrint> _figura = new List<IPrint>();
            cilindro.Stampa();
            Console.WriteLine(cilindro.Volume());
            Console.WriteLine("----------------------------------");
            Console.WriteLine(cilindro.Superficie());
            Console.WriteLine("----------------------------------");
            _figura.Add(q);
            _figura.Add(c);
            _figura.Add(cilindro);
            _figura.ForEach(x => x.Stampa());
            //figura.Add(q);
            //figura.Add(c);
            //figura.Add(c2);
            //figura.Add(q2);
            //figura.Add(q3);
            //figura.ForEach(x => Console.WriteLine(x.ToString()));
            //foreach (Figura f in figura)
            //Console.WriteLine(f);
            //Console.WriteLine(c);
            Console.ReadLine();
        }
    }
}
