﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackConsole
{
    class Stack
    {
        int[] array;
        int stack_pointer;

        public Stack(int dimensione)
        {
            array = new int[dimensione];
            stack_pointer = -1;
        }
        public Stack()
        {
            array = new int[10];
            stack_pointer = -1;
        }

        public void Reset()         //resetto lo stack assegnando tutti gli elementi dell'array a 0
        {
            Array.Clear(array, 0, GetElementi);         //pulisco l'array in modo che tutti gli elementi vadano a 0 
        }

        public int GetElementi
        {
            get
            {
                int i;
                for (i = 1; i < array.Length && array[i] != 0; i++) ; ;
                return i;
            }
        }

        public void Push(int push)           //ritorna 1 se tutto va a buon fine, 0 se lo stack è pieno o qualcosa non funziona  
        {
            if (!Pieno())
            {
                array[++stack_pointer] = push;
            }
            else
            {
                throw new Exception("Stack vuoto");
            }
        }

        public int ElementoCima       //trovo il primo elemento dell'array
        {
            get
            {
                if (GetElementi > 0)
                {
                    return array[0];
                }
                else
                {
                    return -1;
                }
            }
        }

        public int Pop()           
        {
            if (!Vuoto())
            {
                int pop = array[stack_pointer];
                stack_pointer--;
                return pop;
            }
            else
            {
                throw new Exception("Stack vuoto");
            }
        }

        public bool Pieno()
        {
            return stack_pointer == array.Length -1;
        }

        public bool Vuoto()
        {
            return stack_pointer == -1;
        }

        public void Visualizza()
        {
            
            if (GetElementi > 0)
            {
                for (int i = 0; i < GetElementi ; i++)
                {
                    Console.WriteLine(array[i]);
                }
                Console.ReadLine();    
            }
        }
        
    }
}
