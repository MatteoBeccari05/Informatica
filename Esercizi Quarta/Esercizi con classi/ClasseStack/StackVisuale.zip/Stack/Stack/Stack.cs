﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stack
{
    class Stack
    {
        int[] array;
        int stack_pointer;

        public Stack(int dimensione)
        {
            array = new int[dimensione];
            stack_pointer = -1;
        }
        public Stack()
        {
            array = new int[10];
            stack_pointer = -1;
        }

        public void Reset()         //resetto lo stack assegnando tutti gli elementi dell'array a 0
        {
            Array.Clear(array, 0, GetElementi);         //pulisco l'array in modo che tutti gli elementi vadano a 0 
        }

        public int GetElementi
        {
            get
            {
                int i;
                for (i = 0; i < array.Length && array[i] != 0; i++) ; ;
                return i;
            }
        }

        public List<int> Ritorno
        {
            get
            {
                return array.ToList();
            }
        }

        public int Push(object obj)           //ritorna 1 se tutto va a buon fine, 0 se lo stack è pieno o qualcosa non funziona  
        {
            int[] tmp = new int[array.Length];

            if (GetElementi < array.Length)
            {
                if (!int.TryParse(obj.ToString(), out int ins))
                {
                    return 0;
                }
                else
                {
                    tmp[0] = ins;
                    for (int i = 1; i < GetElementi + 1; i++)
                    {
                        tmp[i] = array[i - 1];
                    }
                    array = tmp;
                    stack_pointer = GetElementi - 1;
                    return 1;
                } 
            }
            else
            {
                return 0;
            }
        }

        public int ElementoCima       //trovo il primo elemento dell'array
        {
            get
            {
                if (GetElementi > 0)
                {
                    return array[0];
                }
                else
                {
                    return -1;
                }
            }
        }

        public int Pop()            //ritorna 1 se va tutto a buon fine, se ci sono dei problemi ritorna 0
        {
            if (GetElementi > 0)
            {
                return 1;
            }                               //DA SISTEMARE 
            else
            {
                return 0;
            }
        }
    }
}
