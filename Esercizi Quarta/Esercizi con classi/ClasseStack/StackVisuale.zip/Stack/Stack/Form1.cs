﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stack
{
    public partial class Form1 : Form
    {
        Stack stack = new Stack();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnNElementi_Click(object sender, EventArgs e)             //conto quanti elementi ci sono dentro lo stack 
        {
            ContaElementi();
        }

        public void AggiornaTXT()           //aggiorno la lista
        {
            listaStack.DataSource = null;
            listaStack.DataSource = stack.Ritorno;
            txtInsert.Text = string.Empty;
        }

        private void btnPush_Click(object sender, EventArgs e)
        {
            Push();
        }

        private void btnTop_Click(object sender, EventArgs e)           //stampo a video il primo elemento dello stack 
        {
            ElementoCima();
        }

        private void btnClear_Click(object sender, EventArgs e)     //resetto lo stack 
        {
            stack.Reset();
            AggiornaTXT();
        }

        public void ElementoCima()
        {
            if (stack.GetElementi > 0)
            {
                MessageBox.Show($"Elemento in cima allo stack: {stack.ElementoCima}");
            }
            else
            {
                MessageBox.Show("Stack vuoto, inserire degli elementi");
            }
        }

        public void Push()
        {
            try
            {
                if (stack.Push(txtInsert.Text) == 1)            //ritorna 1 quindi aggiorno le text box 
                {
                    AggiornaTXT();
                }
                else if (stack.Push(txtInsert.Text) == 0)       //ritorna 0 e scrivo 'errore'
                {
                    MessageBox.Show("Errore");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("impossibile eseguire il push");
            }
        }

        public void ContaElementi()
        {
            if (stack.GetElementi > 0)              //controllo che ci siano elementi nello stack
            {
                MessageBox.Show($"Numero elementi: {stack.GetElementi}");
            }
            else
            {
                MessageBox.Show("Stack vuoto, inserire degli elementi");
            }
        }
    }
}
