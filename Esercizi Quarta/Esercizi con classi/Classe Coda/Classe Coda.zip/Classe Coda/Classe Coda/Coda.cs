﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classe_Coda
{
    
    class Coda
    {
        List<string> queue;

        public Coda()
        {
            queue = new List<string>(10);
        }

        public void Reset()
        {
            queue.Clear();
        }

        public int Count
        {
            get
            {
                return queue.Count;
            }
        }

        public void Enqueue(string str)
        {
            if (queue.Count < 10)
            {
                queue.Add(str);
                
            }
            else
            {
                throw new Exception("Coda piena");
            }
        }

        public void Dequeue()
        {
            if (queue.Count > 0)
            {
                queue.Remove(queue[0]);
            }
            else
            {
                throw new Exception("Coda vuota");
            }
        }

        public string Peek()
        {
            if (queue.Count < 10)
            {
                return queue[1];
            }
            else
            {
                throw new Exception("Coda vuota");
            }
        }

        public List<string> Visualizza()
        {
            return queue;
        }
    }
}
