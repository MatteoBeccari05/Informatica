﻿
namespace Classe_Coda
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.listbox = new System.Windows.Forms.ListBox();
            this.txtInserimento = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.btnEnQueue = new System.Windows.Forms.Button();
            this.btnDeQueue = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnLastEl = new System.Windows.Forms.Button();
            this.btnNumElementi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listbox
            // 
            this.listbox.FormattingEnabled = true;
            this.listbox.Location = new System.Drawing.Point(12, 78);
            this.listbox.Name = "listbox";
            this.listbox.Size = new System.Drawing.Size(149, 225);
            this.listbox.TabIndex = 0;
            // 
            // txtInserimento
            // 
            this.txtInserimento.Location = new System.Drawing.Point(12, 38);
            this.txtInserimento.Name = "txtInserimento";
            this.txtInserimento.Size = new System.Drawing.Size(149, 20);
            this.txtInserimento.TabIndex = 1;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(13, 19);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(102, 13);
            this.lbl1.TabIndex = 2;
            this.lbl1.Text = "Inserire un elemento";
            // 
            // btnEnQueue
            // 
            this.btnEnQueue.Location = new System.Drawing.Point(197, 50);
            this.btnEnQueue.Name = "btnEnQueue";
            this.btnEnQueue.Size = new System.Drawing.Size(75, 23);
            this.btnEnQueue.TabIndex = 3;
            this.btnEnQueue.Text = "Enqueue";
            this.btnEnQueue.UseVisualStyleBackColor = true;
            this.btnEnQueue.Click += new System.EventHandler(this.btnEnQuewe_Click);
            // 
            // btnDeQueue
            // 
            this.btnDeQueue.Location = new System.Drawing.Point(197, 94);
            this.btnDeQueue.Name = "btnDeQueue";
            this.btnDeQueue.Size = new System.Drawing.Size(75, 23);
            this.btnDeQueue.TabIndex = 4;
            this.btnDeQueue.Text = "Dequeue";
            this.btnDeQueue.UseVisualStyleBackColor = true;
            this.btnDeQueue.Click += new System.EventHandler(this.btnDeQuewe_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(197, 140);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnLastEl
            // 
            this.btnLastEl.Location = new System.Drawing.Point(197, 187);
            this.btnLastEl.Name = "btnLastEl";
            this.btnLastEl.Size = new System.Drawing.Size(75, 40);
            this.btnLastEl.TabIndex = 6;
            this.btnLastEl.Text = "Ultimo elemento";
            this.btnLastEl.UseVisualStyleBackColor = true;
            this.btnLastEl.Click += new System.EventHandler(this.btnLastEl_Click);
            // 
            // btnNumElementi
            // 
            this.btnNumElementi.Location = new System.Drawing.Point(197, 247);
            this.btnNumElementi.Name = "btnNumElementi";
            this.btnNumElementi.Size = new System.Drawing.Size(75, 40);
            this.btnNumElementi.TabIndex = 7;
            this.btnNumElementi.Text = "Numero elementi";
            this.btnNumElementi.UseVisualStyleBackColor = true;
            this.btnNumElementi.Click += new System.EventHandler(this.btnNumElementi_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 315);
            this.Controls.Add(this.btnNumElementi);
            this.Controls.Add(this.btnLastEl);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDeQueue);
            this.Controls.Add(this.btnEnQueue);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.txtInserimento);
            this.Controls.Add(this.listbox);
            this.Name = "Form1";
            this.Text = "Coda";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listbox;
        private System.Windows.Forms.TextBox txtInserimento;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Button btnEnQueue;
        private System.Windows.Forms.Button btnDeQueue;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnLastEl;
        private System.Windows.Forms.Button btnNumElementi;
    }
}

