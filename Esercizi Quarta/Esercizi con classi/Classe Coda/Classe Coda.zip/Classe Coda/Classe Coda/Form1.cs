﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Classe_Coda
{
    public partial class Form1 : Form
    {
        Coda cd = new Coda();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEnQuewe_Click(object sender, EventArgs e)
        {
            try
            {
                cd.Enqueue(txtInserimento.Text);
                txtInserimento.Text = string.Empty;
                Visualizza();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Errore: " + ex.Message);
            }
        }

        private void btnDeQuewe_Click(object sender, EventArgs e)
        {
            try
            {
                cd.Dequeue();
                Visualizza();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Errore: " + ex.Message);
            }
        }

        private void btnLastEl_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show("Ultimo elemento: " + cd.Peek());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            cd.Reset();
            Visualizza();
        }

        private void Visualizza()
        {
            listbox.DataSource = null;
            listbox.DataSource = cd.Visualizza();
        }

        private void btnNumElementi_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Numero elementi: " + cd.Count);
        }
    }
}
