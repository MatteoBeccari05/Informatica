﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasseAstratta
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Figura> listaFigure = new List<Figura>();
            Quadrato q = new Quadrato(12);
            Quadrato q2 = new Quadrato(10);
            Quadrato q3 = new Quadrato(8);
            
            Cerchio c = new Cerchio(6);
            Cerchio c2 = new Cerchio(12);
            Cerchio c3 = new Cerchio(18);

            listaFigure.Add(q);
            listaFigure.Add(q2);
            listaFigure.Add(q3);
            listaFigure.Add(c);
            listaFigure.Add(c2);
            listaFigure.Add(c3);

            foreach (Figura i in listaFigure)
            {
                Console.WriteLine(i.ToString() + "\n");
            }

            //listaFigure.ForEach(X => Console.WriteLine(X));

            /*Console.WriteLine("Quadrato: "+ q.ToString());
            Console.WriteLine("Cerchio" + c.ToString());*/

            Console.ReadLine();

        }
    }
}
