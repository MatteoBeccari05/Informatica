﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasseAstratta
{
    abstract class Figura
    {
        int _lato;
        int _perimetro;

        public double Lato { get; private set; }

        public Figura(double lato)
        {
            Lato = lato;
        }

        

        public abstract double Perimetro();
        public abstract double Area();

        public override string ToString()
        {
            return string.Format($"Perimetro: {Perimetro()} ---- Area: {Area()}");
        }
        
    }

    class Quadrato : Figura
    {
        public Quadrato(double lato):base(lato)
        {

        }

        public override double Perimetro()
        {
            return Lato * 4;
        }

        public override double Area()
        {
            return Lato * Lato;
        }
    }

    class Cerchio : Figura
    {
        public Cerchio(double lato) : base(lato)
        {

        }

        public override double Perimetro()
        {
            return Lato * 2 *Math.PI;
        }

        public override double Area()
        {
            return Math.Pow(Lato, 2) * Math.PI;
        }

        
    }
}
