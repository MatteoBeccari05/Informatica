﻿namespace EsercizioData
{
    public enum Mese            //assegno al mese un numero che corrisponde alla sua posizione nell'anno
    {
        gennaio = 1,
        febbraio = 2,
        marzo = 3,
        aprile = 4,
        maggio = 5,
        giugno = 6, 
        luglio = 7,
        agosto = 8,
        settembre = 9,
        ottobre = 10,
        novembre = 11, 
        dicembre = 12
    }
}