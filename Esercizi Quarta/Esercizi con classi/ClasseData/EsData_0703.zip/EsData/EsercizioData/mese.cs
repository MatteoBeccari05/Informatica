﻿namespace EsercizioData
{
    public enum Mese            //assegno al mese un numero che corrisponde alla sua posizione nell'anno
    {
        Gennaio = 1,
        Febbraio = 2,
        Marzo = 3,
        Aprile = 4,
        Maggio = 5,
        Giugno = 6, 
        Luglio = 7,
        Agosto = 8,
        Settembre = 9,
        Ottobre = 10,
        Novembre = 11, 
        Dicembre = 12
    }
}