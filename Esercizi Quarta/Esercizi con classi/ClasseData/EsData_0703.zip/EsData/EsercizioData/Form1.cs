﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace EsercizioData
{
    public partial class Form1 : Form
    {
        Data data;
        string[] dt = new string[3];
        bool numLetter;   //se la data è numerica o letteraria 
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            gbMese.Enabled = false;
            gbBisestile.Enabled = false;
            gbUPDOWN.Enabled = false;
            btnNewDate.Enabled = false;
            Calendario.TodayDate = DateTime.Now;
        }

        private void button1_Click(object sender, EventArgs e)       //quando premo controlla 
        {
            BtnControlla();
        }

        private void BtnControlla()               //quando premo controlla 
        {
            Inserimento();                      //fa l'inserimento 
            Aggiorna();                  
            gbMese.Enabled = true;
            gbUPDOWN.Enabled = true;
            rbNumerico.Checked = true;
            gbBisestile.Enabled = true;
        }

        private void btnClose_Click(object sender, EventArgs e)             //pulsante chiudi 
        {
            if (MessageBox.Show("Chiudere il programma?", "Messaggio", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtInserimento_KeyPress(object sender, KeyPressEventArgs e)  //mi impedisce di inserire lettere 
        {
            char a = (char)e.KeyChar;
            if (!char.IsDigit(a) && e.KeyChar != '/' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            btnNewDate.Enabled = true;
        }

        private void btnNewDate_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void btnUP_Click(object sender, EventArgs e)
        {
            /*Data tmp = this.data;

            int g = Convert.ToInt32(UpDown.Value);
            tmp.CambiaGiorni(g);
            Reset();
            this.data = tmp;
            Aggiorna();
            tmp = null;*/
        }

        private void btnDOWN_Click(object sender, EventArgs e)
        {
            
        }

        private void rbCarattere_CheckedChanged(object sender, EventArgs e)
        {
            if (rbCarattere.Checked == true && numLetter == false)           //se il radiobutton carattere è attivo scrivo il mese in carattere 
            {
                numLetter = true;
                if (data != null) 
                {
                    Aggiorna();
                }
            }
        }

        private void Inserimento()
        {
            int day, month, year;
            try
            {
                if (txtInserimento.Text != string.Empty)
                {
                    dt = txtInserimento.Text.Split('/');       //divido la data tramite lo split 
                    string giorno = dt[0];                  //passo il giorno al primo elemento dell'array
                    string mese = dt[1];                //passo il mese al secondo elemento dell'array
                    string anno = dt[2];                //passo l'anno al terzo elemento dell'array+

                    day = int.Parse(giorno);
                    month = int.Parse(mese);            //converto la data in intero 
                    year = int.Parse(anno);

                    if (!numLetter)                             //se la data è numerica la converto in int 
                    {
                        data = new Data(day, Convert.ToInt32(month), year);
                    }

                    Calendario.SetDate(new DateTime(data.Anno, (int)data.Mese, data.Giorno));       //aggiorno il calendario
                }
                else
                {
                    MessageBox.Show("Inserire una data");
                    Reset();
                }        
            }
            catch (Exception e)
            {
                MessageBox.Show("Errore nel formato della data \n" + e.Message);
            }
        }

        

        private void rbNumerico_CheckedChanged(object sender, EventArgs e)
        {
            if (rbNumerico.Checked == true && numLetter == true)                    //se il radiobutton numerico è attivo scrivo il mese in numero
            {
                numLetter = false;
                if (data != null)
                {
                    Aggiorna();
                }
            }
        }

        private void cbBisestile_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void Calendario_DateSelected(object sender, DateRangeEventArgs e)
        {
            txtInserimento.Text = string.Empty;
            txtInserimento.Text = Calendario.SelectionRange.Start.ToString("dd / MMMM / yyyy");              //scrivo sulla textbox il giorno selezionato sul calendario 
        }

        public void Reset()
        {
            txtInserimento.Text = string.Empty;     //resetto la text box 
            gbUPDOWN.Enabled = false;             //disabilito la group box updown
            data = null;                        //azzero la data 
            btnNewDate.Enabled = false; 

            gbBisestile.Enabled = false; 
            gbMese.Enabled = false;
            cbBisestile.Checked = false;
            
        }


        private void Aggiorna()
        {
            try
            {
                if (txtInserimento.Text != string.Empty)
                {
                    txtInserimento.Text = data.Visualizza(numLetter);           //aggiorno la text box 
                    gbMese.Enabled = true;
                    gbBisestile.Enabled = true;
                    gbUPDOWN.Enabled = true;
                    btnNewDate.Enabled = true;

                    if (data.ControlloBisestile(Convert.ToInt32(dt[2])) == true) //se l'anno è bisestile si attiva la check box 
                    {
                        cbBisestile.Checked = true;
                    }
                    else
                    {
                        cbBisestile.Checked = false;            //se non è bisestile la check box di disattiva
                    }
                }
                else
                {
                    Reset();
                }
                
            }
            catch (Exception e)
            {
                Reset();
            }

        }

        private void Calendario_DateChanged(object sender, DateRangeEventArgs e)
        {

        }
    }
}
