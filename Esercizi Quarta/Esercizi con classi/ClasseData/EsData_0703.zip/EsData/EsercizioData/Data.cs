﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EsercizioData
{
    class Data : Controlli
    {
        int _giorno;
        Mese _mese;
        int _anno;
        bool bisestile;

        public Data(int day, int month, int year)
        {
            if (ControlloMese(month) == true)                //controllo il mese
            {
                if (ControlloAnno(year) == true)            //controllo l'anno 
                {
                    Bisestile = ControlloAnno(year);            //controllo se l'anno è bisestile 
                    if (ControllaGiorno(month, day, Bisestile))  //controllo il giorno in base al mese e in base se l'anno è bisestile 
                    {
                        Giorno = day;
                        Mese = (Mese)month;
                        Anno = year;
                    }
                    else
                    {
                        throw new Exception("Giorno sbagliato");      //se il giorno è sbagliato genero un eccezione 
                    }
                }
                else
                {
                    throw new Exception("Anno sbagliato");         //se l'anno è sbagliato genero un eccezione 
                }
            }
            else
            {
                throw new Exception("Mese sbagliato");             //se il mese è sbagliato genero un eccezione 
            }
        }

        public string Visualizza(bool meseCarattere)          //metodo per stampare a video la data
        {
            if (meseCarattere == true)
            {
                return string.Format($"{this.Giorno.ToString()} / {Mese.ToString()} / {Anno.ToString()}");    //stampo la data con il mese in carattere

            }
            else
            {
                return string.Format($"{this.Giorno.ToString()} / {(int)Mese} / {Anno.ToString()}");        //stampo la data con il mese intero 
            }
        }


        public void CambiaGiorni(int count)             //metodo per updown 
        {
            /*int giornoCambiato = this.Giorno;
            int meseCambiato = (int)this.Mese;
            bool bisestileCambiato = this.Bisestile;

            if (count > 0)              //se il numero nell'updown è maggiore di 0
            {
                for (int i = 0; i < count; i++)    //per ogni aumento del giorno 
                {
                    giornoCambiato+=1;
                    if (!ControllaGiorno(meseCambiato, giornoCambiato, bisestileCambiato))
                    {
                        giornoCambiato = 1;        //mese successivo 
                        meseCambiato += 1;      //incremento il mese
                        if (!ControlloMese(meseCambiato))
                        {
                            meseCambiato = 1;
                            
                        }
                    }
                }
                
            }
            else if(count<0)            //se il numero nell'updown è minore di 0
            {
                _giorno = _giorno - count;
            }*/
        }

        #region Proprieta
        public int Giorno
        {
            get
            {
                return _giorno;
            }

            private set
            {
                _giorno = value;
            }
        }
        
        public Mese Mese
        {
            get
            {
                return _mese;
            }

            private set
            {
                _mese = value;
            }
        }
       
        public int Anno
        {
            get
            {
                return _anno;
            }

            private set
            {
                _anno = value;
            }
        }

        public bool Bisestile
        {
            get
            {
                return bisestile;
            }
            private set
            {
                bisestile = value;
            }
        }
        #endregion


    }
}
