﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EsercizioData
{
    class Controlli
    {
        public bool ControlloMese(int month)        //Controlla se il mese numerico è corretto 
        {
            bool r = false;             //ritorno

            if (month >= 1 && month <= 12)
            {
                r = true;                   //se il mese è corretto torna true 
            }

            return r;               //se non è corretto torna false
        }

        public bool ControlloBisestile(int year)               //controlla se l'anno è bisestile
        {
            bool r = false;             //ritorno

            if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
            {
                r = true;                                               //se è bisestile torna true 
            }

            return r;                       //se non è bisestile torna false
        }

        public bool ControllaGiorno(int month, int day, bool bisestile)   //controlla se il giorno è corretto a seconda del mese 
        {
            bool r = false;             //ritorno
            if (day >= 1 && day <= GiorniMese(month, bisestile))     //se il giorno è corretto torna true
            {
                r = true;
            }
            return r;               //se non è corretto torna false
        }

        public bool ControlloAnno(int year)    //controlla l'anno
        {
            bool r = false;         //ritorno

            if (year >= 1600 && year<=9999)     //controllo che l'anno inserito sia tra il 1600 e il 9999
            {
                r = true;               //se l'anno è corretto torna true 
            }
            return r;                   //se non è corretto torna false
        }

        public int GiorniMese(int month, bool bisestile)           //controlla quanti giorni ha un mese
        {
            int r = -1;             //ritorno
            switch (month)
            {
                case 1: r = 31; break;
                case 3: r = 31; break;
                case 4: r = 30; break;              //assegno a tutti i mesi i loro rispettivi giorni 
                case 5: r = 31; break;
                case 6: r = 30; break;
                case 7: r = 31; break;
                case 8: r = 31; break;
                case 9: r = 30; break;
                case 10: r = 31; break;
                case 11: r = 30; break;
                case 12: r = 31; break;
                case 2:
                    if (bisestile)      //se l'anno è bisestile mette 29 a febbraio
                    {
                        r = 29;
                    }
                    else
                    {
                        r = 28;
                    }
                    break;
            }

            return r;
        }

        public string MeseLetterario(int month)   //se il mese è tra 1 e 12 lo converte 
        {
            if (ControlloMese(month))
            {
                if (month >= 1 && month <= 12)          //ritorna il mese in stringa 
                {
                    return ((Mese)month).ToString();
                }
                else
                {
                    throw new Exception("Mese sbagliato");    //se il mese è sbagliato genero un eccezione 
                }
            }
            else
            {
                throw new Exception("Mese sbagliato");           //se il mese è sbagliato enero un eccezione
            }
        }
    }
}
