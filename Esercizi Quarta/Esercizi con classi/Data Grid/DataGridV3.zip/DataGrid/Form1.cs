﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace DataGrid
{
    public partial class DataGrid : Form
    {
        List<Utente> abbonati;
        public DataGrid()
        {
            InitializeComponent();
            abbonati = new List<Utente>();
        }

        private void DataGrid_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void inserisciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Utente ut = new Utente(txtNome.Text, txtCognome.Text, Convert.ToInt32(txtCredito.Text));
                abbonati.Add(ut);
                dataGridView1.Rows.Add(ut.Cognome, ut.Nome, ut.Credito);
                txtNome.Text = string.Empty;
                txtCognome.Text = string.Empty;
                txtCredito.Text = string.Empty;
            }
            catch
            {
                MessageBox.Show("Inserire i dati", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cancellaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.Index != -1)
            {
                int selRow = dataGridView1.CurrentRow.Index;
                if (dataGridView1[0, selRow].Value != null && dataGridView1[1, selRow].Value != null && dataGridView1[2, selRow].Value != null)
                {
                    abbonati.RemoveAt(selRow);
                    dataGridView1.Rows.RemoveAt(selRow);
                }
                else
                {
                    MessageBox.Show("Riga vuota");
                }
            }
            else
            {
                MessageBox.Show("Cancellazione non riuscita", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void visualizzaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.Index != -1)
            {
                int selRow = dataGridView1.CurrentRow.Index;
                if (dataGridView1[0, selRow].Value != null && dataGridView1[1, selRow].Value != null && dataGridView1[2, selRow].Value != null)
                {
                    txtCognome.Text = abbonati[selRow].Cognome;
                    txtCredito.Text = abbonati[selRow].Credito.ToString();
                    txtNome.Text = abbonati[selRow].Nome;
                }
                else
                {
                    MessageBox.Show("Riga vuota");
                }
            }
            else
            {
                MessageBox.Show("Cancellazione non riuscita", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void esciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void posizionaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(txtRiga.Text) >= 0 || Convert.ToInt32(txtRiga.Text)<dataGridView1.RowCount)
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[Convert.ToInt32(txtRiga.Text)].Cells[0];
                dataGridView1.Rows[Convert.ToInt32(txtRiga.Text)].Selected = true;
            }
        }

        private void caricaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*abbonati.Add(new Utente("Michele", "Rizzo", 3));
            abbonati.Add(new Utente("Matteo", "Beccari", 7));
            abbonati.Add(new Utente("Giorgio", "Rossi", 23));*/

            VisualizzaGriglia();
        }

        private void visualizzaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        public void VisualizzaGriglia()
        {
            foreach (Utente i in abbonati)
            {
                dataGridView1.Rows.Add(i.Cognome, i.Nome, i.Credito);
            }
        }

        private void cancellaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abbonati.Clear();
            Cancella();
        }

        public void Cancella()
        {
            dataGridView1.Rows.Clear();
        }

        private void caricaListaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount - 1; i++)
            {
                Utente u1 = new Utente(dataGridView1[0, i].Value.ToString(), dataGridView1[1, i].Value.ToString(), (int)dataGridView1[2, i].Value);
                abbonati.Add(u1);
            }
        }

        private void salvaListaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abbonati.Add(new Utente("Michele", "Rizzo", 3));
            abbonati.Add(new Utente("Matteo", "Beccari", 7));
            abbonati.Add(new Utente("Giorgio", "Rossi", 23));

            dataGridView1.Rows.Clear();
            dataGridView1.RowCount = abbonati.Count + 1;
            for (int i = 0; i<dataGridView1.RowCount; i++)
            {
                dataGridView1[0, i].Value = abbonati[i].Cognome;
                dataGridView1[1, i].Value = abbonati[i].Nome;
                dataGridView1[2, i].Value = abbonati[i].Credito;
            }
        }

        private void salvaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog salvaFile = new SaveFileDialog();
            salvaFile.Filter = "FlottaFiles (*.flo) | *.flo; | All Files (*.*) | *.*;";
            salvaFile.FilterIndex = 1;
            salvaFile.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            if (salvaFile.ShowDialog() == DialogResult.OK)
            {
                FileStream file = new FileStream(salvaFile.FileName, FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(file, abbonati);
                file.Close();
            }
            
        }
    }
}
