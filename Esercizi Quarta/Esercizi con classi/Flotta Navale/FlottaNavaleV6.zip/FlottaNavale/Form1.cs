﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace FlottaNavale
{
    public partial class Form1 : Form
    {
        FlottaNavale flotta = new FlottaNavale();
        Nave f;
        Capitano c;
        public Form1()
        {
            InitializeComponent();
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            naveToolStripMenuItem.Enabled = false;
            comandanteToolStripMenuItem.Enabled = false;
            dataGridView1.ReadOnly = true;
            dataGridView2.ReadOnly = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void esciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void inserimentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNave fn = new FormNave();
            fn.ShowDialog();

            if (fn.DialogResult == DialogResult.OK)
            {
                f = new Nave(fn.nome, Convert.ToString(fn.stato), fn.velocita, Convert.ToInt32(fn.stazza));
                flotta.ListaNavi.Add(f);
                dataGridView1.Rows.Add(f.NomeNave, f.Stazza, f.Velocita, f.StatoNave);
            }
            else
            {
                fn.Close();
            }

        }

        private void creaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCapitano fc = new FormCapitano();
            fc.ShowDialog();

            if (fc.DialogResult == DialogResult.OK)
            {
                c = new Capitano(fc.nome, fc.telefono, fc.dataNascita, fc.stato);
                flotta.ListaCapitani.Add(c);
                dataGridView2.Rows.Add(c.Nome, c.Telefono, c.DataNascita, c.Stato);
            }
            else
            {
                fc.Close();
            }
        }

        private void modificaToolStripMenuItem1_Click(object sender, EventArgs e)       //nave
        {
            int selRow = dataGridView1.CurrentRow.Index;
            int rowsIndex = dataGridView1.CurrentRow.Index;
            int cellIndex = dataGridView1.CurrentCell.ColumnIndex;
            if (dataGridView1[0, selRow].Value != null && dataGridView1[1, selRow].Value != null && dataGridView1[2, selRow].Value != null)
            {
                if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.Index != -1)
                {
                    FormNave fn = new FormNave(flotta.ListaNavi[rowsIndex], rd: false);
                    fn.ShowDialog();
                    if (fn.DialogResult == DialogResult.OK)
                    {
                        flotta.ListaNavi.RemoveAt(rowsIndex);
                        flotta.ListaNavi.Insert(rowsIndex, fn.Nave);
                        dataGridView1.Rows.Clear();
                        flotta.ListaNavi.ForEach(delegate (Nave item) { dataGridView1.Rows.Add(item.NomeNave, item.Stazza.ToString(), item.Velocita.ToString(), item.StatoNave.ToString()); });
                        dataGridView1.CurrentCell = dataGridView1.Rows[rowsIndex].Cells[cellIndex];
                    }
                }
            }
            else
            {
                MessageBox.Show("Riga vuota");
            }


        }

        private void cancellaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.Index != -1)
            {
                int selRow = dataGridView1.CurrentRow.Index;
                if (dataGridView1[0, selRow].Value != null && dataGridView1[1, selRow].Value != null && dataGridView1[2, selRow].Value != null)
                {
                    dataGridView1.Rows.RemoveAt(selRow);
                    flotta.ListaNavi.RemoveAt(selRow);
                }
                else
                {
                    MessageBox.Show("Riga vuota");
                }
            }
            else
            {
                MessageBox.Show("Cancellazione non riuscita", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cancellaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView2.CurrentRow != null && dataGridView2.CurrentRow.Index != -1)
            {
                int selRow = dataGridView2.CurrentRow.Index;
                if (dataGridView2[0, selRow].Value != null && dataGridView2[1, selRow].Value != null && dataGridView2[2, selRow].Value != null)
                {
                    dataGridView2.Rows.RemoveAt(selRow);
                    flotta.ListaCapitani.RemoveAt(selRow);
                }
                else
                {
                    MessageBox.Show("Riga vuota");
                }
            }
            else
            {
                MessageBox.Show("Cancellazione non riuscita", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void creaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormFlotta ff = new FormFlotta();
            ff.ShowDialog();
            lblNomeFlotta.Text = ff.nomeFlotta;
            if (lblNomeFlotta.Text != string.Empty)
            {
                naveToolStripMenuItem.Enabled = true;
                comandanteToolStripMenuItem.Enabled = true;
            }
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void naveToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void lblNomeFlotta_Click(object sender, EventArgs e)
        {
            FormFlotta ff = new FormFlotta();
            ff.ShowDialog();
            lblNomeFlotta.Text = ff.nomeFlotta;
            if (lblNomeFlotta.Text != string.Empty)
            {
                naveToolStripMenuItem.Enabled = true;
                comandanteToolStripMenuItem.Enabled = true;
            }
        }

        private void modificaToolStripMenuItem_Click(object sender, EventArgs e)
        {

            int rowsIndex = dataGridView2.CurrentRow.Index;
            int cellIndex = dataGridView2.CurrentCell.ColumnIndex;
            int selRow = dataGridView2.CurrentRow.Index;
            if (dataGridView2[0, selRow].Value != null && dataGridView2[1, selRow].Value != null && dataGridView2[2, selRow].Value != null)
            {
                if (dataGridView2.CurrentRow != null && dataGridView2.CurrentRow.Index != -1)
                {
                    FormCapitano fn = new FormCapitano(flotta.ListaCapitani[rowsIndex], rd: false);
                    fn.ShowDialog();
                    if (fn.DialogResult == DialogResult.OK)
                    {
                        flotta.ListaCapitani.RemoveAt(rowsIndex);
                        flotta.ListaCapitani.Insert(rowsIndex, fn.Comandante);
                        dataGridView2.Rows.Clear();
                        flotta.ListaCapitani.ForEach(delegate (Capitano item) { dataGridView2.Rows.Add(item.Nome, item.Telefono, item.DataNascita.ToString(), item.Stato.ToString()); });
                        dataGridView2.CurrentCell = dataGridView2.Rows[rowsIndex].Cells[cellIndex];
                    }
                }
            }
            else
            {
                MessageBox.Show("Riga vuota");
            }
        }

        private void salvaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog salvaFile = new SaveFileDialog();
            salvaFile.Filter = "FlottaFiles (*.flo) | *.flo; | All files (*.*) | *.*;";
            salvaFile.FilterIndex = 1;
            salvaFile.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            if (salvaFile.ShowDialog() == DialogResult.OK)
            {
                FileStream file = new FileStream(salvaFile.FileName, FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(file, flotta.ListaCapitani);
                bf.Serialize(file, flotta.ListaNavi);
                file.Close();
            }
        }

        private void apriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "FlottaFiles (*.flo) | *.flo; | All files (*.*) | *.*;";
            open.FilterIndex = 1;
            open.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            open.Multiselect = false;
            open.CheckFileExists = true;

            if (open.ShowDialog() == DialogResult.OK)
            {
                FileStream file = new FileStream(open.FileName, FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                flotta.ListaCapitani = (List<Capitano>)bf.Deserialize(file);
                flotta.ListaNavi = (List<Nave>)bf.Deserialize(file);
                flotta.ListaNavi.ForEach(x => dataGridView1.Rows.Add(x.NomeNave, x.Stazza, x.Velocita, x.StatoNave));
                flotta.ListaCapitani.ForEach(x => dataGridView2.Rows.Add(x.Nome, x.Telefono, x.DataNascita, x.Stato));
                file.Close();
                
                
            }
        }
    }
}
