﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlottaNavale
{
    [Serializable]
    public class Capitano
    {
        string _nome;
        string _telefono; 
        string _dataNascita;
        string _stato;

        public Capitano(string nome, string telefono, string dataNascita, string stato)
        {
            Nome = nome;
            Telefono = telefono;
            DataNascita = dataNascita;
            Stato = stato;
        }

        public string Nome { get => _nome; set => _nome = value; }
        public string Telefono { get => _telefono; set => _telefono = value; }
        public string DataNascita { get => _dataNascita; set => _dataNascita = value; }
        public string Stato { get => _stato; set => _stato = value; }
    }
}
