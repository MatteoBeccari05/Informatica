﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlottaNavale
{
    public partial class FormNave : Form
    {
        
        FlottaNavale flotta = new FlottaNavale();
        Nave nave;
        internal Nave Nave { get => nave; private set => nave = value; }
        public string nome;
        public int stazza, velocita;
        public string stato;
        public FormNave()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
            btnModifica.Visible = false;
            this.cbStato.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        }

        public FormNave(Nave nave, bool rd = true) : this()
        {
            this.nave = nave;
            txtNome.Text = nave.NomeNave;
            txtStazza.Text = Convert.ToString(nave.Stazza);
            txtVelocita.Text = Convert.ToString(nave.Velocita);
            txtVelocita.ReadOnly = true;
            txtStazza.ReadOnly = true;
            txtNome.ReadOnly = true;
            cbStato.Text = nave.StatoNave;

            if (!rd)
            {
                btnOk.Visible = false;
                btnModifica.Visible = true;
                if (cbStato.Text == "Demolita")
                {
                    MessageBox.Show("Nave demolita");
                    cbStato.Enabled = false;
                    btnModifica.Visible = false;
                }
                btnOk.Click += btnModifica_Click;

            }

        }

        private void FormNave_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNome.Text.Length <= 20)
                {
                    if (txtStazza.Text.Length <= 4)
                    {
                        if (txtVelocita.Text.Length <= 3)
                        {
                            if (flotta.ControllaNomeNave(nave) == true)
                            {
                                nome = txtNome.Text;
                                stazza = Convert.ToInt32(txtStazza.Text);
                                velocita = Convert.ToInt32(txtVelocita.Text);
                                stato = cbStato.Text;

                                nave = new Nave(nome, stato, velocita, stazza);
                                DialogResult = DialogResult.OK;
                            }
                            else
                            {
                                MessageBox.Show("Errore, nave già inserita", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            
                        }
                        else
                        {
                            MessageBox.Show("Errore, velocità non corretta", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Errore, stazza non corretta", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Errore, nome troppo lungo", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Errore, reinserire i dati", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void btnModifica_Click(object sender, EventArgs e)
        {
            try
            {
                
                nave = new Nave(txtNome.Text, cbStato.Text, Convert.ToInt32(txtVelocita.Text), Convert.ToInt32(txtStazza.Text));
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Impossibile modificare la nave: {ex.Message}");
            }
        }
    }
}
