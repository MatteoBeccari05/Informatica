﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlottaNavale
{
    public partial class FormCapitano : Form
    {
        FlottaNavale flotta = new FlottaNavale();
        public string nome;
        public string telefono;
        public string dataNascita;
        public string stato;
        public FormCapitano()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
        }

        private void FormCapitano_Load(object sender, EventArgs e)
        {

        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (txtTelefono.Text != string.Empty && txtTelefono.Text.Length == 10)
                {
                    if (txtNome.Text.Length <= 20)
                    {
                        nome = txtNome.Text;
                        telefono = txtTelefono.Text;
                        dataNascita = dateTimePicker1.Text;
                        stato = cbStato.Text;

                        Capitano c = new Capitano(nome, telefono, dataNascita, stato);
                        flotta.AggiungiCapitano(c);
                        DialogResult = DialogResult.OK;
                    }
                    else
                    {
                        MessageBox.Show("Errore, nome troppo lungo", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Errore, numero di telefono non valido", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Errore, reinserire i dati", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
