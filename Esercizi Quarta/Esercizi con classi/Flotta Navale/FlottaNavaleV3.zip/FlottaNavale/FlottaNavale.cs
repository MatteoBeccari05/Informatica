﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlottaNavale
{
    class FlottaNavale
    {
        
        public List<Nave> ListaNavi = new List<Nave>();
        public List<Capitano> ListaCapitani = new List<Capitano>();

        public void AggiungiNave(Nave nave)
        {
            ListaNavi.Add(nave);
        }

        public void RemoveNave(Nave nave)
        {
            ListaNavi.Remove(nave);
        }

        public bool ControllaNomeNave(Nave n)
        {
            if (ListaNavi.Contains(n))
            {
                return false;
            }
            else
            {
                return true;
            }


        }



        public void AggiungiCapitano(Capitano capitano)
        {
            ListaCapitani.Add(capitano);
        }

        public void RemoveCapitano(Capitano capitano)
        {
            ListaCapitani.Remove(capitano);
        }
    }
}
