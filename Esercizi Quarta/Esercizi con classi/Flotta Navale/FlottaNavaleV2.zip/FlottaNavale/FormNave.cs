﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlottaNavale
{
    public partial class FormNave : Form
    {
        public string nome;
        public int stazza, velocita;
        public string stato;
        public FormNave()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
        }

        private void FormNave_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                nome = txtNome.Text;
                stazza = Convert.ToInt32(txtStazza.Text);
                velocita = Convert.ToInt32(txtVelocita.Text);
                stato = cbStato.Text;
                
                new Nave(nome, stato,velocita,stazza);
                DialogResult = DialogResult.OK;

            }
            catch(Exception)
            {
                MessageBox.Show("Errore, reinserire i dati", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
    }
}
