﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlottaNavale
{
    public partial class FormCapitano : Form
    {
        public string nome;
        public string telefono;
        public string dataNascita;
        public string stato;
        public FormCapitano()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
        }

        private void FormCapitano_Load(object sender, EventArgs e)
        {

        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                nome = txtNome.Text;
                telefono = txtTelefono.Text;
                dataNascita = dateTimePicker1.Text;
                stato = cbStato.Text;

                new Capitano(nome, telefono, dataNascita, stato);
                DialogResult = DialogResult.OK;

            }
            catch (Exception)
            {
                MessageBox.Show("Errore, reinserire i dati", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
