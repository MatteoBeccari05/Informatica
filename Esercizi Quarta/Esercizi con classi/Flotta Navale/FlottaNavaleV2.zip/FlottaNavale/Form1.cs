﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlottaNavale
{
    public partial class Form1 : Form
    {
        
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void esciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void inserimentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNave fn = new FormNave();
            fn.ShowDialog();

            if (fn.DialogResult == DialogResult.OK)
            {
                Nave f = new Nave(fn.nome, Convert.ToString(fn.stato), fn.velocita, Convert.ToInt32(fn.stazza));
                dataGridView1.Rows.Add(f.NomeNave, f.Stazza, f.Velocita, f.StatoNave);
            }
            else
            {
                fn.Close();
            }

        }

        private void creaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCapitano fc = new FormCapitano();
            fc.ShowDialog();

            if (fc.DialogResult == DialogResult.OK)
            {
                Capitano c = new Capitano(fc.nome, fc.telefono, fc.dataNascita, fc.stato);
                dataGridView2.Rows.Add(c.Nome, c.Telefono, c.DataNascita, c.Stato);
            }
            else
            {
                fc.Close();
            }
        }
    }
}
