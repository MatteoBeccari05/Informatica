﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlottaNavale
{
    [Serializable]
    public class Nave
    {
        string _nomeNave;
        string _statoNave;
        int _velocita;
        int _stazza;

        public Nave(string nomeNave, string statoNave, int velocita, int stazza)
        {
            NomeNave = nomeNave;
            StatoNave = statoNave;
            Velocita = velocita;
            Stazza = stazza;
        }

        public string NomeNave { get => _nomeNave; set => _nomeNave = value; }
        public string StatoNave { get => _statoNave; set => _statoNave = value; }
        public int Velocita { get => _velocita; set => _velocita = value; }
        public int Stazza { get => _stazza; set => _stazza = value; }

        public string ReturnNome()
        {
            return _nomeNave;
        }
    }
}
