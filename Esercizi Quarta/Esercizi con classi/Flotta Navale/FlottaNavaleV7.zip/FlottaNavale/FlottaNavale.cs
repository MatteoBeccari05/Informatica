﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlottaNavale
{
    class FlottaNavale
    {
        
        public List<Nave> ListaNavi = new List<Nave>();
        public List<Capitano> ListaCapitani = new List<Capitano>();

        public bool ControllaNomeNave(Nave n)
        {
            if (ListaNavi.Contains(n))
            {
                return false;
            }
            else
            {
                return true;
            }


        }
    }
}
