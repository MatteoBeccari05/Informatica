﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlottaNavale
{
    public partial class FormFlotta : Form
    {
        public string nomeFlotta;
        public FormFlotta()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
        }

        private void FormFlotta_Load(object sender, EventArgs e)
        {

        }

        private void btnCrea_Click(object sender, EventArgs e)
        {
            if (txtFlotta.Text != string.Empty)
            {
                nomeFlotta = txtFlotta.Text;
                DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Inserire una flotta", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
