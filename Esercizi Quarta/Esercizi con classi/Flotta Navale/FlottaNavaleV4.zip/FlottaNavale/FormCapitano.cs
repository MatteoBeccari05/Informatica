﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlottaNavale
{
    public partial class FormCapitano : Form
    {
        Capitano c;
        FlottaNavale flotta = new FlottaNavale();
        public string nome;
        public string telefono;
        public string dataNascita;
        public string stato;
        public FormCapitano()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
            btnModifica.Visible = false;
            dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.cbStato.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        }
        public Capitano Comandante { get => c; }

        public FormCapitano(Capitano c, bool rd = true) : this()
        {
            this.c = c;
            txtNome.Text = c.Nome;
            txtTelefono.Text = c.Telefono;
            dateTimePicker1.Value = Convert.ToDateTime(c.DataNascita);
            cbStato.Text = c.Stato;
            txtNome.ReadOnly = true;
            dateTimePicker1.Enabled = false;
            btnOk.Click -= btnOk_Click;

            if (!rd)
            {
                txtTelefono.ReadOnly = false;
                btnOk.Visible = false;
                btnModifica.Visible = true;
                
                if (cbStato.Text == "Pensione")
                {
                    MessageBox.Show("Comandante in pensione");
                    cbStato.Enabled = false;
                }
                btnOk.Click += btnModifica_Click;
            }
            
        }

        private void FormCapitano_Load(object sender, EventArgs e)
        {

        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (txtTelefono.Text != string.Empty && txtTelefono.Text.Length == 10)
                {
                    if (txtNome.Text.Length <= 20)
                    {
                        nome = txtNome.Text;
                        telefono = txtTelefono.Text;
                        dataNascita = dateTimePicker1.Text;
                        stato = cbStato.Text;

                        Capitano c = new Capitano(nome, telefono, dataNascita, stato);
                        DialogResult = DialogResult.OK;
                    }
                    else
                    {
                        MessageBox.Show("Errore, nome troppo lungo", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Errore, numero di telefono non valido", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Errore, reinserire i dati", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void btnModifica_Click(object sender, EventArgs e)
        {
            try
            {
                
                c = new Capitano(txtNome.Text, txtTelefono.Text, Convert.ToString(dateTimePicker1.Value), cbStato.Text);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Errore: {ex.Message}");
            }
        }
    }
}
