﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComboBox
{
    public partial class Form1 : Form
    {
        //bool _selezionato = false;
        Veicolo v1;
        List<Veicolo> _listaVeicoli;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            v1 = (Veicolo)comboBox1.SelectedItem;
            //textBox1.Text = v1.ToString();
            //_selezionato = true;
            /*if (!_selezionato)
            {
                
               
            }
            //else
            {
                _selezionato = false;
            }*/
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _listaVeicoli = new List<Veicolo>();
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            /*
            comboBox1.Items.Add(new Veicolo(43, "autocarro", StatoVeicolo.Nuovo));
            comboBox1.Items.Add(new Veicolo(44, "autovettura", StatoVeicolo.Nuovo));
            comboBox1.Items.Add(new Veicolo(45, "Trattore", StatoVeicolo.Vecchio));
            */
            _listaVeicoli.Add(new Veicolo(43, "autocarro", StatoVeicolo.Nuovo));
            _listaVeicoli.Add(new Veicolo(44, "autovettura", StatoVeicolo.Nuovo));
            _listaVeicoli.Add(new Veicolo(45, "Trattore", StatoVeicolo.Vecchio));
            comboBox1.DataSource = null;
            comboBox1.DataSource = _listaVeicoli;
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (v1 != null && comboBox1.SelectedIndex < _listaVeicoli.Count)
            {
                //v1.Descrizione = textBox2.Text;
                _listaVeicoli.Find(x => x.Descrizione == v1.Descrizione).Descrizione = textBox2.Text;
                v1.Descrizione = textBox2.Text;
                textBox1.Text = v1.ToString();
                comboBox1.DataSource = null;
                comboBox1.DataSource = _listaVeicoli;
                //_selezionato = true; // Risolvere la visualizzazione
            }
            else
            {
                MessageBox.Show("Errore", "Errore");
            }
        }
    }
}
