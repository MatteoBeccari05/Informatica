﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComboBox
{
    class Veicolo
    {
        StatoVeicolo _stato;
        public int NumeroTelaio { get; set; }
        public string Descrizione { get; set; }
        public StatoVeicolo Stato { get { return _stato; } set { _stato = value; } }

        public Veicolo(int nTelaio, string descrizione,StatoVeicolo stato)
        {
            NumeroTelaio = nTelaio;
            Descrizione = descrizione;
            Stato = stato;
        }
        public Veicolo() : this(0, "Descrizione", StatoVeicolo.Nuovo)
        {

        }
        public override string ToString()
        {
            return string.Format($"{Descrizione}    {Stato}");
        }
    }
    public enum StatoVeicolo
    {
        Nuovo,
        Vecchio
    }
}
