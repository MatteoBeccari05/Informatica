﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestione_Form
{
    public partial class Modale : Form
    {
        public Tstudente s1;
        public string messaggio;
        public string operazione;
        public Modale()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
            //acceptbutton=assegna al tasto invio l'operatività del pulsante btn_conferma
            AcceptButton = btn_Conferma;
            //cancelbutton=assegna al tasto esc l'operatività del pulsante btn_annulla
            CancelButton = btn_Annulla;
        }

        private void btn_Conferma_Click(object sender, EventArgs e)
        {
            try
            {
                messaggio = "inserimento";
                s1.nome = txt_nome.Text;
                s1.voto = Convert.ToInt32(txt_voto.Text);
                DialogResult = DialogResult.OK;
            }
            catch
            {
                MessageBox.Show("Errore", "Valori errati", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Annulla_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void txt_nome_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txt_voto_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Modale_Load(object sender, EventArgs e)
        {
            if (operazione == "Visualizza")
            {
                btn_Annulla.Visible = false;
            }
            if (s1.nome != "" && s1.voto != 0)
            {
                txt_nome.Text = s1.nome;
                txt_voto.Text = s1.voto.ToString();
            }
            
        }
    }
}
