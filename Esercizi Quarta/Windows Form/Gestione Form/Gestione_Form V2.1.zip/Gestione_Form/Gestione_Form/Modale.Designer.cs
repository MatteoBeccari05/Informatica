﻿
namespace Gestione_Form
{
    partial class Modale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Conferma = new System.Windows.Forms.Button();
            this.btn_Annulla = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_nome = new System.Windows.Forms.TextBox();
            this.txt_voto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Conferma
            // 
            this.btn_Conferma.Location = new System.Drawing.Point(101, 171);
            this.btn_Conferma.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_Conferma.Name = "btn_Conferma";
            this.btn_Conferma.Size = new System.Drawing.Size(86, 34);
            this.btn_Conferma.TabIndex = 0;
            this.btn_Conferma.Text = "Conferma";
            this.btn_Conferma.UseVisualStyleBackColor = true;
            this.btn_Conferma.Click += new System.EventHandler(this.btn_Conferma_Click);
            // 
            // btn_Annulla
            // 
            this.btn_Annulla.Location = new System.Drawing.Point(11, 171);
            this.btn_Annulla.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_Annulla.Name = "btn_Annulla";
            this.btn_Annulla.Size = new System.Drawing.Size(86, 34);
            this.btn_Annulla.TabIndex = 1;
            this.btn_Annulla.Text = "Annulla";
            this.btn_Annulla.UseVisualStyleBackColor = true;
            this.btn_Annulla.Click += new System.EventHandler(this.btn_Annulla_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nome e Cognome";
            // 
            // txt_nome
            // 
            this.txt_nome.Location = new System.Drawing.Point(35, 24);
            this.txt_nome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_nome.Name = "txt_nome";
            this.txt_nome.Size = new System.Drawing.Size(124, 20);
            this.txt_nome.TabIndex = 4;
            this.txt_nome.TextChanged += new System.EventHandler(this.txt_nome_TextChanged);
            // 
            // txt_voto
            // 
            this.txt_voto.Location = new System.Drawing.Point(35, 73);
            this.txt_voto.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_voto.Name = "txt_voto";
            this.txt_voto.Size = new System.Drawing.Size(123, 20);
            this.txt_voto.TabIndex = 7;
            this.txt_voto.TextChanged += new System.EventHandler(this.txt_voto_TextChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(83, 57);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 14);
            this.label2.TabIndex = 6;
            this.label2.Text = "Voto";
            // 
            // Modale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(198, 224);
            this.Controls.Add(this.txt_voto);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_nome);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Annulla);
            this.Controls.Add(this.btn_Conferma);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Modale";
            this.Text = "Modale";
            this.Load += new System.EventHandler(this.Modale_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Conferma;
        private System.Windows.Forms.Button btn_Annulla;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_nome;
        private System.Windows.Forms.TextBox txt_voto;
        private System.Windows.Forms.Label label2;
    }
}