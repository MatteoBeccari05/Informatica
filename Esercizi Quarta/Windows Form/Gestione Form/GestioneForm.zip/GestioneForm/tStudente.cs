﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestioneForm
{
    public struct tStudente
    {
        public string nome, cognome;
        public int voto;

        public override string ToString()
        {
            return string.Format($"{nome} : {voto}");
        }
    }
}
