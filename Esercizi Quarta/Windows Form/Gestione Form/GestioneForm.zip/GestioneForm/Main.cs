﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestioneForm
{
    public partial class GestioneForm : Form
    {
        List<tStudente> studente = new List<tStudente>();
        public GestioneForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void formNonModaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nModale fm = new nModale();
            fm.Show();
        }

        private void btnCloseMain_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void formModaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult rispostaForm;
            Modale fm = new Modale();
            rispostaForm= fm.ShowDialog();
            if (rispostaForm == DialogResult.OK)
            {
                MessageBox.Show("Conferma");
            }
            else if (rispostaForm == DialogResult.Cancel)
            {
                MessageBox.Show("Annulla");
            }    
        }

        private void inserisciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult rispostaForm;
            Modale fm = new Modale();
            rispostaForm = fm.ShowDialog();
            if (rispostaForm == DialogResult.OK)
            {
                MessageBox.Show("Conferma");
            }
            else if (rispostaForm == DialogResult.Cancel)
            {
                MessageBox.Show("Annulla");
            }

        }
    }
}
