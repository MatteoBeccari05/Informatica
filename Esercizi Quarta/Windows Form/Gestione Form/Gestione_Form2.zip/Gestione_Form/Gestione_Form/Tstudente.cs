﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestione_Form
{
    public struct Tstudente
    {
        public string nome;
        public int voto;
        public override string ToString()
        {
            return string.Format($"{nome} ");
        }
    }
}
