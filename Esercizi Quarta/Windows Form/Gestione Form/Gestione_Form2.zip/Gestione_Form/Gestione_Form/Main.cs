﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestione_Form
{
    public partial class Main : Form
    {
        List<Tstudente> studente = new List<Tstudente>();
        public Main()
        {
            InitializeComponent();
        }

        private void formNonModaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NModale fnm = new NModale();
            fnm.Show();
        }

        private void btn_CloseMain_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void formModaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult rispostaForm;
            Modale fm= new Modale();
            //fm.Show();
            rispostaForm = fm.ShowDialog();
            if (rispostaForm == DialogResult.OK)
            {
                MessageBox.Show("Conferma");
            }
            else if (rispostaForm == DialogResult.Cancel)
            {
                MessageBox.Show("Annulla, sei spacciato");
            }
        }

        private void elenco_visuale_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void inserisciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult rispostaForm;
            Modale fm = new Modale();
            //fm.Show();
            rispostaForm = fm.ShowDialog();
            if (rispostaForm == DialogResult.OK)
            {
                studente.Add(fm.s1);
                elenco_visuale.DataSource = null;
                elenco_visuale.DataSource = studente;
                //MessageBox.Show(fm.messaggio);
            }
            else if (rispostaForm == DialogResult.Cancel)
            {
                MessageBox.Show("Annulla, sei spacciato");
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void visualizzaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
            DialogResult rispostaForm;
            Modale fm = new Modale();
            if (elenco_visuale.SelectedIndex != -1)
            {
                fm.s1 = studente[elenco_visuale.SelectedIndex];
                fm.operazione = "Visualizza";
            }
                
            rispostaForm = fm.ShowDialog();
           
           
        }

        private void cancellaToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }
    }
}
