﻿
namespace Gestione_Form
{
    partial class Main
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.formToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formNonModaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formModaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inserisciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visualizzaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cancellaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btn_CloseMain = new System.Windows.Forms.Button();
            this.elenco_visuale = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formToolStripMenuItem,
            this.modificaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(600, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // formToolStripMenuItem
            // 
            this.formToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formNonModaleToolStripMenuItem,
            this.formModaleToolStripMenuItem});
            this.formToolStripMenuItem.Name = "formToolStripMenuItem";
            this.formToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.formToolStripMenuItem.Text = "Form";
            // 
            // formNonModaleToolStripMenuItem
            // 
            this.formNonModaleToolStripMenuItem.Name = "formNonModaleToolStripMenuItem";
            this.formNonModaleToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.formNonModaleToolStripMenuItem.Text = "Form_NonModale";
            this.formNonModaleToolStripMenuItem.Click += new System.EventHandler(this.formNonModaleToolStripMenuItem_Click);
            // 
            // formModaleToolStripMenuItem
            // 
            this.formModaleToolStripMenuItem.Name = "formModaleToolStripMenuItem";
            this.formModaleToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.formModaleToolStripMenuItem.Text = "Form_Modale";
            this.formModaleToolStripMenuItem.Click += new System.EventHandler(this.formModaleToolStripMenuItem_Click);
            // 
            // modificaToolStripMenuItem
            // 
            this.modificaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inserisciToolStripMenuItem,
            this.visualizzaToolStripMenuItem1,
            this.cancellaToolStripMenuItem});
            this.modificaToolStripMenuItem.Name = "modificaToolStripMenuItem";
            this.modificaToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.modificaToolStripMenuItem.Text = "Modifica";
            // 
            // inserisciToolStripMenuItem
            // 
            this.inserisciToolStripMenuItem.Name = "inserisciToolStripMenuItem";
            this.inserisciToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.inserisciToolStripMenuItem.Text = "Inserisci";
            this.inserisciToolStripMenuItem.Click += new System.EventHandler(this.inserisciToolStripMenuItem_Click);
            // 
            // visualizzaToolStripMenuItem1
            // 
            this.visualizzaToolStripMenuItem1.Name = "visualizzaToolStripMenuItem1";
            this.visualizzaToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.visualizzaToolStripMenuItem1.Text = "Visualizza";
            this.visualizzaToolStripMenuItem1.Click += new System.EventHandler(this.visualizzaToolStripMenuItem1_Click);
            // 
            // cancellaToolStripMenuItem
            // 
            this.cancellaToolStripMenuItem.Name = "cancellaToolStripMenuItem";
            this.cancellaToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.cancellaToolStripMenuItem.Text = "Cancella";
            this.cancellaToolStripMenuItem.Click += new System.EventHandler(this.cancellaToolStripMenuItem_Click);
            // 
            // btn_CloseMain
            // 
            this.btn_CloseMain.Location = new System.Drawing.Point(502, 312);
            this.btn_CloseMain.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_CloseMain.Name = "btn_CloseMain";
            this.btn_CloseMain.Size = new System.Drawing.Size(80, 44);
            this.btn_CloseMain.TabIndex = 1;
            this.btn_CloseMain.Text = "Close";
            this.btn_CloseMain.UseVisualStyleBackColor = true;
            this.btn_CloseMain.Click += new System.EventHandler(this.btn_CloseMain_Click);
            // 
            // elenco_visuale
            // 
            this.elenco_visuale.FormattingEnabled = true;
            this.elenco_visuale.Location = new System.Drawing.Point(11, 26);
            this.elenco_visuale.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.elenco_visuale.Name = "elenco_visuale";
            this.elenco_visuale.Size = new System.Drawing.Size(121, 147);
            this.elenco_visuale.TabIndex = 2;
            this.elenco_visuale.SelectedIndexChanged += new System.EventHandler(this.elenco_visuale_SelectedIndexChanged);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.elenco_visuale);
            this.Controls.Add(this.btn_CloseMain);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Main";
            this.Text = "Gestione Form";
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem formToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formNonModaleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formModaleToolStripMenuItem;
        private System.Windows.Forms.Button btn_CloseMain;
        private System.Windows.Forms.ListBox elenco_visuale;
        private System.Windows.Forms.ToolStripMenuItem modificaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inserisciToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visualizzaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cancellaToolStripMenuItem;
    }
}

