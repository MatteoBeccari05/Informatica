﻿
namespace Calcolatrice_Visual
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddizione = new System.Windows.Forms.Button();
            this.btnSottrazione = new System.Windows.Forms.Button();
            this.btnMoltiplicazione = new System.Windows.Forms.Button();
            this.btnDiviso = new System.Windows.Forms.Button();
            this.btnEsegui = new System.Windows.Forms.Button();
            this.btnAzzera = new System.Windows.Forms.Button();
            this.txtOp1 = new System.Windows.Forms.TextBox();
            this.txtOp2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOperazione = new System.Windows.Forms.TextBox();
            this.txtRisultato = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAddizione
            // 
            this.btnAddizione.BackColor = System.Drawing.Color.Plum;
            this.btnAddizione.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddizione.Location = new System.Drawing.Point(234, 33);
            this.btnAddizione.Name = "btnAddizione";
            this.btnAddizione.Size = new System.Drawing.Size(60, 34);
            this.btnAddizione.TabIndex = 0;
            this.btnAddizione.Text = "+";
            this.btnAddizione.UseVisualStyleBackColor = false;
            this.btnAddizione.Click += new System.EventHandler(this.btnAddizione_Click);
            // 
            // btnSottrazione
            // 
            this.btnSottrazione.BackColor = System.Drawing.Color.Plum;
            this.btnSottrazione.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSottrazione.Location = new System.Drawing.Point(300, 33);
            this.btnSottrazione.Name = "btnSottrazione";
            this.btnSottrazione.Size = new System.Drawing.Size(60, 34);
            this.btnSottrazione.TabIndex = 1;
            this.btnSottrazione.Text = "-";
            this.btnSottrazione.UseVisualStyleBackColor = false;
            this.btnSottrazione.Click += new System.EventHandler(this.btnSottrazione_Click);
            // 
            // btnMoltiplicazione
            // 
            this.btnMoltiplicazione.BackColor = System.Drawing.Color.Plum;
            this.btnMoltiplicazione.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMoltiplicazione.Location = new System.Drawing.Point(300, 73);
            this.btnMoltiplicazione.Name = "btnMoltiplicazione";
            this.btnMoltiplicazione.Size = new System.Drawing.Size(60, 34);
            this.btnMoltiplicazione.TabIndex = 2;
            this.btnMoltiplicazione.Text = "x";
            this.btnMoltiplicazione.UseVisualStyleBackColor = false;
            this.btnMoltiplicazione.Click += new System.EventHandler(this.btnMoltiplicazione_Click);
            // 
            // btnDiviso
            // 
            this.btnDiviso.BackColor = System.Drawing.Color.Plum;
            this.btnDiviso.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDiviso.Location = new System.Drawing.Point(234, 73);
            this.btnDiviso.Name = "btnDiviso";
            this.btnDiviso.Size = new System.Drawing.Size(60, 34);
            this.btnDiviso.TabIndex = 3;
            this.btnDiviso.Text = "/";
            this.btnDiviso.UseVisualStyleBackColor = false;
            this.btnDiviso.Click += new System.EventHandler(this.btnDiviso_Click);
            // 
            // btnEsegui
            // 
            this.btnEsegui.BackColor = System.Drawing.Color.Plum;
            this.btnEsegui.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEsegui.Location = new System.Drawing.Point(263, 241);
            this.btnEsegui.Name = "btnEsegui";
            this.btnEsegui.Size = new System.Drawing.Size(75, 34);
            this.btnEsegui.TabIndex = 4;
            this.btnEsegui.Text = "Esegui";
            this.btnEsegui.UseVisualStyleBackColor = false;
            this.btnEsegui.Click += new System.EventHandler(this.btnEsegui_Click);
            // 
            // btnAzzera
            // 
            this.btnAzzera.BackColor = System.Drawing.Color.Plum;
            this.btnAzzera.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAzzera.Location = new System.Drawing.Point(263, 299);
            this.btnAzzera.Name = "btnAzzera";
            this.btnAzzera.Size = new System.Drawing.Size(75, 34);
            this.btnAzzera.TabIndex = 5;
            this.btnAzzera.Text = "Azzera";
            this.btnAzzera.UseVisualStyleBackColor = false;
            this.btnAzzera.Click += new System.EventHandler(this.btnAzzera_Click);
            // 
            // txtOp1
            // 
            this.txtOp1.Location = new System.Drawing.Point(30, 33);
            this.txtOp1.Name = "txtOp1";
            this.txtOp1.Size = new System.Drawing.Size(100, 20);
            this.txtOp1.TabIndex = 6;
            this.txtOp1.TextChanged += new System.EventHandler(this.txtOp1_TextChanged);
            this.txtOp1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOp1_KeyPress);
            // 
            // txtOp2
            // 
            this.txtOp2.Location = new System.Drawing.Point(30, 101);
            this.txtOp2.Name = "txtOp2";
            this.txtOp2.Size = new System.Drawing.Size(100, 20);
            this.txtOp2.TabIndex = 7;
            this.txtOp2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOp2_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Operando 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Operando 2";
            // 
            // txtOperazione
            // 
            this.txtOperazione.Location = new System.Drawing.Point(30, 249);
            this.txtOperazione.Name = "txtOperazione";
            this.txtOperazione.ReadOnly = true;
            this.txtOperazione.Size = new System.Drawing.Size(100, 20);
            this.txtOperazione.TabIndex = 10;
            // 
            // txtRisultato
            // 
            this.txtRisultato.Location = new System.Drawing.Point(30, 299);
            this.txtRisultato.Name = "txtRisultato";
            this.txtRisultato.ReadOnly = true;
            this.txtRisultato.Size = new System.Drawing.Size(100, 20);
            this.txtRisultato.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Operazione ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 283);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Risultato";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Plum;
            this.btnClose.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(306, 369);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 35);
            this.btnClose.TabIndex = 14;
            this.btnClose.Text = "Chiudi";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(393, 416);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtRisultato);
            this.Controls.Add(this.txtOperazione);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtOp2);
            this.Controls.Add(this.txtOp1);
            this.Controls.Add(this.btnAzzera);
            this.Controls.Add(this.btnEsegui);
            this.Controls.Add(this.btnDiviso);
            this.Controls.Add(this.btnMoltiplicazione);
            this.Controls.Add(this.btnSottrazione);
            this.Controls.Add(this.btnAddizione);
            this.Name = "Form1";
            this.Text = "Calcolatrice";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddizione;
        private System.Windows.Forms.Button btnSottrazione;
        private System.Windows.Forms.Button btnMoltiplicazione;
        private System.Windows.Forms.Button btnDiviso;
        private System.Windows.Forms.Button btnEsegui;
        private System.Windows.Forms.Button btnAzzera;
        private System.Windows.Forms.TextBox txtOp1;
        private System.Windows.Forms.TextBox txtOp2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtOperazione;
        private System.Windows.Forms.TextBox txtRisultato;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnClose;
    }
}

