﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calcolatrice_Visual
{
    public partial class Form1 : Form
    {
        bool tmp;
        double supporto;
        int i = 0;
        double operando1 = 0;
        double operando2 = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAddizione_Click(object sender, EventArgs e)
        {
            i = 1;
            if (txtOp1.Text != string.Empty && txtOp2.Text != string.Empty)
            {
                txtOperazione.Text = txtOp1.Text + "+" + txtOp2.Text;
            }
            else
            {
                MessageBox.Show("Inserire gli operandi", "Errore");
            }
             
        }

        private void btnSottrazione_Click(object sender, EventArgs e)
        {
            i = 2;
            if (txtOp1.Text != string.Empty && txtOp2.Text != string.Empty)
            {
                txtOperazione.Text = txtOp1.Text + "-" + txtOp2.Text;
            }
            else
            {
                MessageBox.Show("Inserire gli operandi", "Errore");
            }
            
        }

        private void btnMoltiplicazione_Click(object sender, EventArgs e)
        {
            i = 3;
            if (txtOp1.Text != string.Empty && txtOp2.Text != string.Empty)
            {
                txtOperazione.Text = txtOp1.Text + "x" + txtOp2.Text;
            }
            else
            {
                MessageBox.Show("Inserire gli operandi", "Errore");
            }
            
        }

        private void btnDiviso_Click(object sender, EventArgs e)
        {
            i = 4;
            if (txtOp1.Text != string.Empty && txtOp2.Text != string.Empty)
            {
                txtOperazione.Text = txtOp1.Text + ":" + txtOp2.Text;
            }
            else
            {
                MessageBox.Show("Inserire gli operandi", "Errore");
            }
            
            if (txtOp2.Text == "0")
            {
                MessageBox.Show("Impossibile dividere per 0", "Errore");
                txtOp1.Text = string.Empty;
                txtOp2.Text = string.Empty;
                txtOperazione.Text = string.Empty;
                txtRisultato.Text = string.Empty;
            }
            
        }

        private void btnAzzera_Click(object sender, EventArgs e)
        {
            i = 0;
            supporto = 0;
            operando1 = 0;
            operando2 = 0;
            txtOp1.Text = string.Empty;
            txtOp2.Text = string.Empty;
            txtOperazione.Text = string.Empty;
            txtRisultato.Text = string.Empty;
        }

        private void btnEsegui_Click(object sender, EventArgs e)
        {
            switch (i)
            {
                case 1:
                    tmp = double.TryParse(txtOp1.Text, out operando1);
                    tmp = double.TryParse(txtOp2.Text, out operando2);
                    supporto = operando1 + operando2;
                    txtRisultato.Text = Convert.ToString(supporto); break;
                case 2:
                    tmp = double.TryParse(txtOp1.Text, out operando1);
                    tmp = double.TryParse(txtOp2.Text, out operando2);
                    supporto = operando1 - operando2;
                    txtRisultato.Text = Convert.ToString(supporto); break;

                case 3:
                    tmp = double.TryParse(txtOp1.Text, out operando1);
                    tmp = double.TryParse(txtOp2.Text, out operando2);
                    supporto = operando1 * operando2;
                    txtRisultato.Text = Convert.ToString(supporto); break;

                case 4:
                    tmp = double.TryParse(txtOp1.Text, out operando1);
                    tmp = double.TryParse(txtOp2.Text, out operando2);
                    supporto = operando1 / operando2;
                    txtRisultato.Text = Convert.ToString(supporto); break;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtOp1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtOp1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char a = (char)e.KeyChar;
            if (!char.IsDigit(a) && e.KeyChar != '\b' && a != ',')
            {
                e.Handled = true;
            }

        }

        private void txtOp2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char a = (char)e.KeyChar;
            if (!char.IsDigit(a) && e.KeyChar != '\b' && a != ',')
            {
                e.Handled = true;
            }

        }
    }
}
