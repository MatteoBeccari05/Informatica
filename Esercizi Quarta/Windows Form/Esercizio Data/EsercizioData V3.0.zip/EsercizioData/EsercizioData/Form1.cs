﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace EsercizioData
{
    public partial class Form1 : Form
    {
        static string[] data;
        static string[] mesi = { "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre" };
        static int[] Giorni = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        static string mese;
        static string giorno;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            gbMese.Enabled = false;
            gbBisestile.Enabled = false;
            gbUPDOWN.Enabled = false;
            btnNewDate.Enabled = false;
            monthCalendar1.TodayDate = DateTime.Now;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Inserimento();
            gbMese.Enabled = true;
            gbUPDOWN.Enabled = true;
            rbNumerico.Checked = true;
            gbBisestile.Enabled = true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Chiudere il programma?", "Messaggio", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtInserimento_KeyPress(object sender, KeyPressEventArgs e)
        {
            char a = (char)e.KeyChar;
            if (!char.IsDigit(a) && e.KeyChar != '/' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            btnNewDate.Enabled = true;
        }

        private void btnNewDate_Click(object sender, EventArgs e)
        {
            numericUpDown1.Value = 0;
            txtInserimento.Text = string.Empty;
            gbBisestile.Enabled = false;
            gbMese.Enabled = false;
            gbUPDOWN.Enabled = false;
        }

        private void btnUP_Click(object sender, EventArgs e)
        {
            int NewDay = Convert.ToInt32(data[0]) + Convert.ToInt32(numericUpDown1.Value);
            if (NewDay > 0 && NewDay < 32)
            {
                data[0] = NewDay.ToString();
                txtInserimento.Text = data[0] + "/" + data[1] + "/" + data[2];
            }
            else
            {
                MessageBox.Show("Data errata", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDOWN_Click(object sender, EventArgs e)
        {
            int NewDay = Convert.ToInt32(data[0]) - Convert.ToInt32(numericUpDown1.Value);
            if (NewDay > 0 && NewDay < 32)
            {
                data[0] = NewDay.ToString();
                txtInserimento.Text = data[0] + "/" + data[1] + "/" + data[2];
            }
            else
            {
                MessageBox.Show("Data errata", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void rbCarattere_CheckedChanged(object sender, EventArgs e)
        {
            DataLetterale();
        }

        private void Inserimento()
        {
            
            if (txtInserimento.Text != "")
            {
                data = txtInserimento.Text.Split('/');
                if (data.Length != 4)
                {
                    //
                }
                else
                {
                    mese = data[1];
                    giorno = data[0];
                    bool control = false;
                    int meseConvertito = 0;
                    if (mese.Length <= 2)
                    {
                        meseConvertito = Convert.ToInt32(mese);
                        if (!(meseConvertito >= 1 && meseConvertito <= 12))
                        {
                            MessageBox.Show("Valore sbagliato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            gbMese.Enabled = false;
                            rbCarattere.Enabled = false;
                        }
                    }
                    else if (mese.Length >= 5)
                    {
                        control = true;
                        if (!Controllo(mese))
                        {
                            MessageBox.Show("Valore sbagliato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            gbMese.Enabled = false;
                            rbCarattere.Enabled = false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Mese Errato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        gbMese.Enabled = false;
                        rbCarattere.Enabled = false;
                    }

                    if (giorno.Length <= 2)
                    {
                        int giornoConv = Convert.ToInt32(giorno);
                        if (giornoConv > 0 && giornoConv <= 31)
                        {
                            if (control)
                            {
                                for (int i = 0; i < mesi.Length; i++)
                                {
                                    if (mese.ToLower() == mesi[i].ToLower())
                                    {
                                        if (!(giornoConv <= Giorni[i]))
                                        {
                                            MessageBox.Show("Giorno Errato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            gbMese.Enabled = false;
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Giorno Errato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            gbMese.Enabled = false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Giorno Errato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        gbMese.Enabled = false;
                    }
                    if (!ControlloAnno())
                    {
                        MessageBox.Show("Anno Errato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        gbMese.Enabled = false;
                    }
                }
               
            }
            else
            {
                MessageBox.Show("Inserire una data", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                gbMese.Enabled = false;
            }
        }

        private bool Controllo(string mese)
        {
            foreach (string h in mesi)
            {
                if (h.ToLower() == mese.ToLower())
                {
                    return true;
                }
            }
            return false;
        }

        private bool ControlloAnno()
        {
            for (int i = 0; i < data[2].Length; i++)
            {
                if (!(data[2][i] >= 48 && data[2][i] <= 57))
                {
                    return false;
                }
            }
            return true;
        }

        private void rbNumerico_CheckedChanged(object sender, EventArgs e)
        {
            DataNumerica();
        }

        private void DataNumerica()
        {
            if (txtInserimento.Text != "")
            {
                try
                {
                    if (data[1].Length >= 5)
                    {
                        for (int i = 0; i < mesi.Length; i++)
                        {
                            if (data[1].ToLower() == mesi[i].ToLower())
                            {
                                i += 1;
                                data[1] = Convert.ToString(i);
                            }
                        }
                        txtInserimento.Text = data[0] + "/" + data[1] + "/" + data[2];
                    }
                }
                catch
                {
                    //MessageBox.Show("Inserire una data", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void DataLetterale()
        {
            if (txtInserimento.Text != "")
            {
                try
                {
                    if (data[1].Length <= 2)
                    {
                        int meseNum = Convert.ToInt32(data[1]);
                        data[1] = mesi[meseNum - 1];
                        txtInserimento.Text = data[0] + "/" + data[1] + "/" + data[2];
                    }
                }
                catch
                {
                    MessageBox.Show("Inserire una data", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void AnnoBisestile()
        {
            if (txtInserimento.Text != "")
            {
                try
                {
                    int anno = int.Parse(data[2]);
                    if ((anno % 4 == 0 && anno % 100 != 0) || anno % 400 == 0)
                    {
                        MessageBox.Show("L'anno è bisestile", "Informazione", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("L'anno non è bisestile", "Informazione", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch
                {
                    MessageBox.Show("Inserire una data", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void cbBisestile_CheckedChanged(object sender, EventArgs e)
        {
            AnnoBisestile();
        }
    }
}
