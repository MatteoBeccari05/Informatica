﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GiocoBottoni
{
    public partial class form1 : Form
    {
        int tentativi;
        int nVittoria;
        int nCasuale;
        Random numeri;
        bool[] array;
        const int costante = 10;
        Button[] bottoni;
        Point XY;
        int[] interi;

        public form1()
        {
            InitializeComponent();
        }

        private void form1_Load(object sender, EventArgs e)
        {
            numeri = new Random();
            bottoni = new Button[costante];
            array = new bool[costante];
            interi = new int[costante];
            btnPlay.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Chiudere il programma?", "Messaggio", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            
            int i = numeri.Next(0, costante);
            CancellaText();

            lblNumero.Text = interi[i].ToString();
            nVittoria = Convert.ToInt32(interi[i].ToString());
        }

        private void btnGenera_Click(object sender, EventArgs e)
        {
            btnPlay.Enabled = true;
            int contatore = 0;

            XY.X = 15;
            XY.Y = 100;
            for (int i = 1; i < bottoni.Length; i++)
            {
                bottoni[i] = new Button();
                bottoni[i].Location = new System.Drawing.Point(40, 110);
                bottoni[i].BackColor = System.Drawing.SystemColors.ActiveCaption;
                bottoni[i].Font = new System.Drawing.Font("Microsoft Sans Serif", 8.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                bottoni[i].ForeColor = System.Drawing.Color.Black;
                bottoni[i].Location = XY;
                bottoni[i].Name = "B2" + contatore;
                bottoni[i].Size = new System.Drawing.Size(60, 30);
                bottoni[i].TabIndex = 0;

                //bottoni[i].Text = (GeneraCasuale(array, costante, 0, numeri) + 1).ToString();
                interi[i] = GeneraArray(interi, 20, 50, numeri);
                bottoni[i].Text = interi[i].ToString();
                bottoni[i].UseVisualStyleBackColor = true;
                this.Controls.Add(bottoni[i]);
                XY.X = XY.X + 70;
                contatore++;
                bottoni[i].Click += VerificaBottoni;
            }
            btnGenera.Enabled = false;
        }
        
        private int GeneraCasuale(bool[] array, int Nmax, int Nmin, Random numeri)
        {

            int casuale;
            do
            {
                casuale = numeri.Next(Nmin, Nmax);

            } while (array[casuale]);

            array[casuale] = true;

            return casuale;


        }
        private int GeneraArray(int [] interi, int min, int max, Random numeri)
        {
            
            do
            {
                nCasuale = numeri.Next(min, max);
                

            } while (Array.IndexOf(interi, nCasuale)!=-1);
            
            return nCasuale;
            
        }
        private void CancellaText()
        {
            for (int i = 1; i < bottoni.Length; i++)
            {
                bottoni[i].BackColor = Color.White;
                bottoni[i].ForeColor = Color.White;
            }
        }

        private void VerificaBottoni(object sender, EventArgs e)
        {
            Button bottone = (Button)sender;
            if (bottone.Text == Convert.ToString(nVittoria))
            {
                bottone.BackColor = Color.Green;
                MessageBox.Show("Hai vinto!");
                Close();
            }
            else
            {
                bottone.BackColor = Color.Red;
                bottone.Enabled = false;

            }

            bottone.ForeColor = Color.Black;
        }
    }
}
