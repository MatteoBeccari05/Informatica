﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace giocobottoni
{
    public partial class Form1 : Form
    {
        int y,x= 10;
        int aggiunta = 60;
        int contatore = 0;
        Point xy;
        const int valore = 3;
        Button []vettBtn = new Button[valore];
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGenera_Click(object sender, EventArgs e)
        {
         
            for (int i = 0; i < vettBtn.Length; i++)
            {
                
                vettBtn[i] = new Button();
                vettBtn[i].Location = xy;
                vettBtn[i].Name = "bottone" + contatore;
                vettBtn[i].Text = Numcasuale().ToString();
                xy.X += (x + aggiunta);
                xy.Y = y;
                Controls.Add(vettBtn[i]);
                contatore++;

                /*btn[i].Size = new System.Drawing.Size(75, 23);
                btn[i].TabIndex = 0;
                btn[i].UseVisualStyleBackColor = true;*/


            }
        }
        int  Numcasuale()
        {
            int n2;
            bool controllo = false;
            Random numero = new Random();
            n2 = numero.Next(0, 10);
            do
            {
                for (int I = 0; I < contatore && !controllo; I++)
                {
                    if (n2.ToString() == vettBtn[I].Text)
                    {
                        controllo = true;
                        n2 = numero.Next(0, 10);
                    }
                   
                }
            } while (!controllo);
            return n2;
        }
    }
}
