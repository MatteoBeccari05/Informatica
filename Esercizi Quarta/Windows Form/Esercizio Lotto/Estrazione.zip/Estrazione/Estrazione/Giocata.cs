﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Estrazione
{
    public partial class FormGiocata : Form
    {
        public List<int> numeriGiocata = new List<int>();
        public FormGiocata()
        {
            InitializeComponent();
            MinimizeBox = false;            //per non far minimizzare la finestra
            MaximizeBox = false;            //per non massimizzare la finestra 
            FormBorderStyle = FormBorderStyle.FixedDialog;        //per non far ridimensionare la finestra
        }

        private void FormGiocata_Load(object sender, EventArgs e)
        {

        }

        private void btnConferma_Click(object sender, EventArgs e)
        {
            if (TB1.Text != "" && TB2.Text != "" && TB3.Text != "" && TB4.Text != "" && TB5.Text != "")  //controllo che le text box non siano vuote
            {
                try               //try catch per evitare che il programma vada in crash se l'utente inserisce numeri troppo grandi
                {
                    numeriGiocata.Add(Convert.ToInt32(TB1.Text));
                    numeriGiocata.Add(Convert.ToInt32(TB2.Text));                //converto i numeri e li inserisco in una lista
                    numeriGiocata.Add(Convert.ToInt32(TB3.Text));
                    numeriGiocata.Add(Convert.ToInt32(TB4.Text));
                    numeriGiocata.Add(Convert.ToInt32(TB5.Text));
                    DialogResult = DialogResult.OK;
                }
                catch(Exception)
                {
                    MessageBox.Show("Impossibile eseguire la giocata, controlla i numeri inseriti", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Inserire 5 numeri da giocare:", "Avviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;                      //se premo annulla esco dal form
        }

        private void TB1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))   //key press che mi impedisce di mettere lettere e simboli
            {
                e.Handled = true;
            }
        }

        private void TB2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))    //key press che mi impedisce di mettere lettere e simboli
            {
                e.Handled = true;
            }
        }

        private void TB3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))   //key press che mi impedisce di mettere lettere e simboli
            {
                e.Handled = true;
            }
        }

        private void TB4_TextChanged(object sender, EventArgs e)
        {

        }

        private void TB4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))   //key press che mi impedisce di mettere lettere e simboli
            {
                e.Handled = true;
            }
        }

        private void TB5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))  //key press che mi impedisce di mettere lettere e simboli
            {
                e.Handled = true;
            }
        }
    }
}
