﻿namespace Estrazione
{
    partial class FormGiocata
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormGiocata));
            this.label1 = new System.Windows.Forms.Label();
            this.TB4 = new System.Windows.Forms.TextBox();
            this.TB3 = new System.Windows.Forms.TextBox();
            this.TB5 = new System.Windows.Forms.TextBox();
            this.TB2 = new System.Windows.Forms.TextBox();
            this.TB1 = new System.Windows.Forms.TextBox();
            this.btnAnnulla = new System.Windows.Forms.Button();
            this.btnConferma = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 23);
            this.label1.TabIndex = 16;
            this.label1.Text = "Inserisci i numeri :";
            // 
            // TB4
            // 
            this.TB4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.TB4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB4.Location = new System.Drawing.Point(398, 24);
            this.TB4.Margin = new System.Windows.Forms.Padding(4);
            this.TB4.Name = "TB4";
            this.TB4.Size = new System.Drawing.Size(52, 26);
            this.TB4.TabIndex = 15;
            this.TB4.TextChanged += new System.EventHandler(this.TB4_TextChanged);
            this.TB4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TB4_KeyPress);
            // 
            // TB3
            // 
            this.TB3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.TB3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB3.Location = new System.Drawing.Point(338, 24);
            this.TB3.Margin = new System.Windows.Forms.Padding(4);
            this.TB3.Name = "TB3";
            this.TB3.Size = new System.Drawing.Size(52, 26);
            this.TB3.TabIndex = 14;
            this.TB3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TB3_KeyPress);
            // 
            // TB5
            // 
            this.TB5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.TB5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB5.Location = new System.Drawing.Point(458, 24);
            this.TB5.Margin = new System.Windows.Forms.Padding(4);
            this.TB5.Name = "TB5";
            this.TB5.Size = new System.Drawing.Size(52, 26);
            this.TB5.TabIndex = 13;
            this.TB5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TB5_KeyPress);
            // 
            // TB2
            // 
            this.TB2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.TB2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB2.Location = new System.Drawing.Point(278, 24);
            this.TB2.Margin = new System.Windows.Forms.Padding(4);
            this.TB2.Name = "TB2";
            this.TB2.Size = new System.Drawing.Size(52, 26);
            this.TB2.TabIndex = 12;
            this.TB2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TB2_KeyPress);
            // 
            // TB1
            // 
            this.TB1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.TB1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB1.Location = new System.Drawing.Point(218, 24);
            this.TB1.Margin = new System.Windows.Forms.Padding(4);
            this.TB1.Name = "TB1";
            this.TB1.Size = new System.Drawing.Size(52, 26);
            this.TB1.TabIndex = 11;
            this.TB1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TB1_KeyPress);
            // 
            // btnAnnulla
            // 
            this.btnAnnulla.BackColor = System.Drawing.Color.OrangeRed;
            this.btnAnnulla.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnnulla.Location = new System.Drawing.Point(416, 86);
            this.btnAnnulla.Margin = new System.Windows.Forms.Padding(4);
            this.btnAnnulla.Name = "btnAnnulla";
            this.btnAnnulla.Size = new System.Drawing.Size(97, 51);
            this.btnAnnulla.TabIndex = 10;
            this.btnAnnulla.Text = "Annulla";
            this.btnAnnulla.UseVisualStyleBackColor = false;
            this.btnAnnulla.Click += new System.EventHandler(this.btnAnnulla_Click);
            // 
            // btnConferma
            // 
            this.btnConferma.BackColor = System.Drawing.Color.LimeGreen;
            this.btnConferma.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConferma.Location = new System.Drawing.Point(311, 86);
            this.btnConferma.Margin = new System.Windows.Forms.Padding(4);
            this.btnConferma.Name = "btnConferma";
            this.btnConferma.Size = new System.Drawing.Size(97, 51);
            this.btnConferma.TabIndex = 9;
            this.btnConferma.Text = "Conferma";
            this.btnConferma.UseVisualStyleBackColor = false;
            this.btnConferma.Click += new System.EventHandler(this.btnConferma_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(183, 14);
            this.label2.TabIndex = 17;
            this.label2.Text = "Inserire cinque numeri da 1 a 90";
            // 
            // FormGiocata
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(526, 150);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB4);
            this.Controls.Add(this.TB3);
            this.Controls.Add(this.TB5);
            this.Controls.Add(this.TB2);
            this.Controls.Add(this.TB1);
            this.Controls.Add(this.btnAnnulla);
            this.Controls.Add(this.btnConferma);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormGiocata";
            this.Text = "Giocata";
            this.Load += new System.EventHandler(this.FormGiocata_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB4;
        private System.Windows.Forms.TextBox TB3;
        private System.Windows.Forms.TextBox TB5;
        private System.Windows.Forms.TextBox TB2;
        private System.Windows.Forms.TextBox TB1;
        private System.Windows.Forms.Button btnAnnulla;
        private System.Windows.Forms.Button btnConferma;
        private System.Windows.Forms.Label label2;
    }
}