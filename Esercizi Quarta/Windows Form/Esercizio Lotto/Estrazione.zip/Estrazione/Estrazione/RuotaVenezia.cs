﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Estrazione
{
    public partial class RuotaVenezia : Form
    {
        List<int> ListaNumeriEstratti = new List<int>();
        public RuotaVenezia()
        {
            InitializeComponent();
            MinimizeBox = false;            //per non far minimizzare la finestra
            MaximizeBox = false;            //per non massimizzare la finestra 
            FormBorderStyle = FormBorderStyle.FixedDialog;        //per non far ridimensionare la finestra
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void Risultati(int numeriAzzeccati)
        {
            if (numeriAzzeccati == 0)
            {
                lblAzzeccati.Text = "HAI PERSO, numeri Azzeccati: " + numeriAzzeccati.ToString();       //stampo il risultato 
                MessageBox.Show("HAI PERSO!", "Avviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(numeriAzzeccati==2)
            {
                lblAzzeccati.Text = "AMBO, numeri Azzeccati: " + numeriAzzeccati.ToString();
                MessageBox.Show("HAI VINTO!\nHai fatto ambo", "Avviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (numeriAzzeccati == 3)
            {
                lblAzzeccati.Text = "TERNA, numeri Azzeccati: " + numeriAzzeccati.ToString();
                MessageBox.Show("HAI VINTO!\nHai fatto terna", "Avviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (numeriAzzeccati == 4)
            {
                lblAzzeccati.Text = "QUATERNA, numeri Azzeccati: " + numeriAzzeccati.ToString();
                MessageBox.Show("HAI VINTO!\nHai fatto quaterna", "Avviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (numeriAzzeccati == 5)
            {
                lblAzzeccati.Text = "CINQUINA, numeri Azzeccati: " + numeriAzzeccati.ToString();
                MessageBox.Show("HAI VINTO!\nHai fatto cinquina", "Avviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void estraiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormGiocata gioco = new FormGiocata();
            gioco.ShowDialog();                                     //creo un nuovo form 
            int numeriAzzeccati = 0;
            
            if (gioco.DialogResult == DialogResult.OK)  
            {
                Random numeriLotto = new Random();                //variabile random per estrarre i numeri del lotto 
                int numeriEstratti;
                for (int i = 0; i < 5; i++)
                {
                    do
                    {
                        numeriEstratti = numeriLotto.Next(1, 91);             //estraggo cinque numeri da 1 a 90
                    }
                    while (ListaNumeriEstratti.Contains(numeriEstratti));
                    ListaNumeriEstratti.Add(numeriEstratti);               // aggiungo i numeri estratti ad una lista
                }
                ListaNumeriEstratti.ForEach(x => txtLotto.Text += x.ToString() + " - ");   //scrive i numeri estratti nella text box
                gioco.numeriGiocata.ForEach(x => lblInseriti.Text += x.ToString() + " - ");  //scrive i numeri inseriti dall'utente nella label
                for (int i = 0; i < 5; i++)   //scorro la lista 
                {
                    if (ListaNumeriEstratti.Contains(gioco.numeriGiocata[i]))  //controllo che i numeri inseriti dall'utente siano uguali a quelli estratti 
                    {
                        numeriAzzeccati++;   //se sono uguali incremento il contatore dei numeri azzeccati
                    }
                }
                Risultati(numeriAzzeccati);   //richiamo il metodo risultati che scriverà sulle label se l'utente ha vinto o perso
            }
            else
            {
                gioco.Close();     
            }
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            lblAzzeccati.Text = "Numeri Azzeccati:";         //pulisco le label
            lblInseriti.Text = "Numeri Inseriti:";
            txtLotto.Text = string.Empty;                   //pulisco la label
            ListaNumeriEstratti.Clear();                    //pulisco la lista dei numeri estratti
            FormGiocata tmp = new FormGiocata();
            tmp.numeriGiocata.Clear();                  //pulisco la lista dei numeri inseriti dall'utente 
        }
        private void LBLnInseriti_Click(object sender, EventArgs e)
        {

        }

        
    }
}
