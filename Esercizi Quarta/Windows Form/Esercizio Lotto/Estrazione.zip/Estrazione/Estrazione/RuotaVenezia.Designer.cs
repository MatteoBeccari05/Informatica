﻿namespace Estrazione
{
    partial class RuotaVenezia
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RuotaVenezia));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.giocataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estraiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.txtLotto = new System.Windows.Forms.TextBox();
            this.lblAzzeccati = new System.Windows.Forms.Label();
            this.lblInseriti = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.PaleGreen;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.giocataToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(382, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // giocataToolStripMenuItem
            // 
            this.giocataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.estraiToolStripMenuItem});
            this.giocataToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.giocataToolStripMenuItem.Name = "giocataToolStripMenuItem";
            this.giocataToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.giocataToolStripMenuItem.Text = "Giocata";
            // 
            // estraiToolStripMenuItem
            // 
            this.estraiToolStripMenuItem.Name = "estraiToolStripMenuItem";
            this.estraiToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.estraiToolStripMenuItem.Text = "Inserisci";
            this.estraiToolStripMenuItem.Click += new System.EventHandler(this.estraiToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Numeri del lotto";
            // 
            // txtLotto
            // 
            this.txtLotto.BackColor = System.Drawing.Color.PaleGreen;
            this.txtLotto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLotto.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotto.Location = new System.Drawing.Point(15, 53);
            this.txtLotto.Margin = new System.Windows.Forms.Padding(4);
            this.txtLotto.Multiline = true;
            this.txtLotto.Name = "txtLotto";
            this.txtLotto.ReadOnly = true;
            this.txtLotto.Size = new System.Drawing.Size(185, 39);
            this.txtLotto.TabIndex = 2;
            // 
            // lblAzzeccati
            // 
            this.lblAzzeccati.AutoSize = true;
            this.lblAzzeccati.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzzeccati.Location = new System.Drawing.Point(13, 105);
            this.lblAzzeccati.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAzzeccati.Name = "lblAzzeccati";
            this.lblAzzeccati.Size = new System.Drawing.Size(128, 19);
            this.lblAzzeccati.TabIndex = 6;
            this.lblAzzeccati.Text = "Numeri Azzeccati: ";
            // 
            // lblInseriti
            // 
            this.lblInseriti.AutoSize = true;
            this.lblInseriti.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInseriti.Location = new System.Drawing.Point(13, 131);
            this.lblInseriti.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInseriti.Name = "lblInseriti";
            this.lblInseriti.Size = new System.Drawing.Size(117, 19);
            this.lblInseriti.TabIndex = 5;
            this.lblInseriti.Text = "Numeri Inseriti : ";
            this.lblInseriti.Click += new System.EventHandler(this.LBLnInseriti_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReset.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(295, 166);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 36);
            this.btnReset.TabIndex = 7;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // RuotaVenezia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(382, 214);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblAzzeccati);
            this.Controls.Add(this.lblInseriti);
            this.Controls.Add(this.txtLotto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "RuotaVenezia";
            this.Text = "Ruota di Venezia";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem giocataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estraiToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLotto;
        private System.Windows.Forms.Label lblAzzeccati;
        private System.Windows.Forms.Label lblInseriti;
        private System.Windows.Forms.Button btnReset;
    }
}

