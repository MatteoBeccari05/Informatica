﻿
namespace AreaPerimetro
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblAltezza = new System.Windows.Forms.Label();
            this.LblBase = new System.Windows.Forms.Label();
            this.TxtBase = new System.Windows.Forms.TextBox();
            this.TxtAlt = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TxtRis = new System.Windows.Forms.TextBox();
            this.BtnClear = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.rbArea = new System.Windows.Forms.RadioButton();
            this.rbPerimetro = new System.Windows.Forms.RadioButton();
            this.btnCalc = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblAltezza
            // 
            this.LblAltezza.AutoSize = true;
            this.LblAltezza.BackColor = System.Drawing.Color.Transparent;
            this.LblAltezza.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAltezza.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LblAltezza.Location = new System.Drawing.Point(14, 60);
            this.LblAltezza.Name = "LblAltezza";
            this.LblAltezza.Size = new System.Drawing.Size(53, 18);
            this.LblAltezza.TabIndex = 2;
            this.LblAltezza.Text = "Altezza";
            this.LblAltezza.Click += new System.EventHandler(this.LblAltezza_Click);
            // 
            // LblBase
            // 
            this.LblBase.AutoSize = true;
            this.LblBase.BackColor = System.Drawing.Color.Transparent;
            this.LblBase.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblBase.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LblBase.Location = new System.Drawing.Point(14, 9);
            this.LblBase.Name = "LblBase";
            this.LblBase.Size = new System.Drawing.Size(37, 18);
            this.LblBase.TabIndex = 3;
            this.LblBase.Text = "Base";
            // 
            // TxtBase
            // 
            this.TxtBase.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBase.Location = new System.Drawing.Point(14, 26);
            this.TxtBase.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtBase.Name = "TxtBase";
            this.TxtBase.Size = new System.Drawing.Size(116, 26);
            this.TxtBase.TabIndex = 4;
            this.TxtBase.TextChanged += new System.EventHandler(this.TxtBase_TextChanged);
            this.TxtBase.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBase_KeyPress);
            // 
            // TxtAlt
            // 
            this.TxtAlt.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAlt.Location = new System.Drawing.Point(14, 77);
            this.TxtAlt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtAlt.Name = "TxtAlt";
            this.TxtAlt.Size = new System.Drawing.Size(116, 26);
            this.TxtAlt.TabIndex = 5;
            this.TxtAlt.TextChanged += new System.EventHandler(this.TxtAlt_TextChanged);
            this.TxtAlt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtAlt_KeyPress);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.TxtRis);
            this.groupBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(158, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(165, 90);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Risultato";
            // 
            // TxtRis
            // 
            this.TxtRis.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRis.Location = new System.Drawing.Point(6, 27);
            this.TxtRis.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtRis.Name = "TxtRis";
            this.TxtRis.ReadOnly = true;
            this.TxtRis.Size = new System.Drawing.Size(116, 21);
            this.TxtRis.TabIndex = 7;
            this.TxtRis.TextChanged += new System.EventHandler(this.TxtRis_TextChanged);
            // 
            // BtnClear
            // 
            this.BtnClear.BackColor = System.Drawing.Color.DarkGreen;
            this.BtnClear.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.BtnClear.FlatAppearance.CheckedBackColor = System.Drawing.Color.DimGray;
            this.BtnClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.BtnClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.BtnClear.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClear.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.BtnClear.Location = new System.Drawing.Point(129, 235);
            this.BtnClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(87, 44);
            this.BtnClear.TabIndex = 7;
            this.BtnClear.Text = "Pulisci";
            this.BtnClear.UseVisualStyleBackColor = false;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = System.Drawing.Color.Red;
            this.BtnClose.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.BtnClose.FlatAppearance.CheckedBackColor = System.Drawing.Color.DimGray;
            this.BtnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.BtnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.BtnClose.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClose.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.BtnClose.Location = new System.Drawing.Point(240, 234);
            this.BtnClose.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(87, 44);
            this.BtnClose.TabIndex = 8;
            this.BtnClose.Text = "Chiudi";
            this.BtnClose.UseVisualStyleBackColor = false;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // rbArea
            // 
            this.rbArea.AutoSize = true;
            this.rbArea.Location = new System.Drawing.Point(30, 140);
            this.rbArea.Name = "rbArea";
            this.rbArea.Size = new System.Drawing.Size(51, 20);
            this.rbArea.TabIndex = 9;
            this.rbArea.TabStop = true;
            this.rbArea.Text = "Area";
            this.rbArea.UseVisualStyleBackColor = true;
            this.rbArea.CheckedChanged += new System.EventHandler(this.rbArea_CheckedChanged);
            // 
            // rbPerimetro
            // 
            this.rbPerimetro.AutoSize = true;
            this.rbPerimetro.Location = new System.Drawing.Point(30, 166);
            this.rbPerimetro.Name = "rbPerimetro";
            this.rbPerimetro.Size = new System.Drawing.Size(81, 20);
            this.rbPerimetro.TabIndex = 10;
            this.rbPerimetro.TabStop = true;
            this.rbPerimetro.Text = "Perimetro";
            this.rbPerimetro.UseVisualStyleBackColor = true;
            this.rbPerimetro.CheckedChanged += new System.EventHandler(this.rbPerimetro_CheckedChanged);
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.Color.Aqua;
            this.btnCalc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(12, 235);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(87, 44);
            this.btnCalc.TabIndex = 11;
            this.btnCalc.Text = "Calcola";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(339, 291);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.rbPerimetro);
            this.Controls.Add(this.rbArea);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TxtAlt);
            this.Controls.Add(this.TxtBase);
            this.Controls.Add(this.LblBase);
            this.Controls.Add(this.LblAltezza);
            this.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Quadrilatero";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label LblAltezza;
        private System.Windows.Forms.Label LblBase;
        private System.Windows.Forms.TextBox TxtBase;
        private System.Windows.Forms.TextBox TxtAlt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TxtRis;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.RadioButton rbArea;
        private System.Windows.Forms.RadioButton rbPerimetro;
        private System.Windows.Forms.Button btnCalc;
    }
}

