﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AreaPerimetro
{
    public partial class Form1 : Form
    {
        bool tmp;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            rbArea.Checked = true;
        }
        private double Area()
        {
            
            return Convert.ToDouble(TxtBase.Text) * Convert.ToDouble(TxtAlt.Text);
        }
        private double Perimetro()
        {
            
            return (Convert.ToDouble(TxtBase.Text) + Convert.ToDouble(TxtAlt.Text)) * 2;
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            TxtRis.Text = "Area: "+Area();   
        }

        private void TxtRis_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            TxtRis.Text = "Perimetro: "+Perimetro();
            
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void LblAltezza_Click(object sender, EventArgs e)
        {

        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TxtAlt.Text = string.Empty;
            TxtBase.Text = string.Empty;
            TxtRis.Text = string.Empty;
            groupBox1.Visible= false;
        }

        private void rbArea_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void TxtBase_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtBase_KeyPress(object sender, KeyPressEventArgs e)
        {
            char a = (char)e.KeyChar;
            if (!char.IsDigit(a) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void TxtAlt_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void TxtAlt_KeyPress(object sender, KeyPressEventArgs e)
        {
            char a = (char)e.KeyChar;
            if (!char.IsDigit(a) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void rbPerimetro_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (rbPerimetro.Checked == true)
            {
                double bas = 0;
                double alt = 0;
                double risultato = 0;

                tmp = double.TryParse(TxtAlt.Text, out alt);
                tmp = double.TryParse(TxtBase.Text, out bas);

                risultato = (bas + alt) * 2;
                groupBox1.Visible = true;
                TxtRis.Text = risultato.ToString();
            }
            if (rbArea.Checked == true)
            {
                double bas = 0;
                double alt = 0;
                double risultato = 0;

                tmp = double.TryParse(TxtAlt.Text, out alt);
                tmp = double.TryParse(TxtBase.Text, out bas);

                risultato = bas * alt;
                groupBox1.Visible = true;
                TxtRis.Text = risultato.ToString();
            }
        }
    }
}
