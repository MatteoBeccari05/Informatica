﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Esercizio1901
{
    public partial class Form1 : Form
    {
        
        string loadImage;
        string percorso = Application.StartupPath;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = percorso + "\\carte";
            openFileDialog1.CheckFileExists = true;
            openFileDialog1.FileName = "default";
            openFileDialog1.DefaultExt = "jpg";
            openFileDialog1.Filter = "jpg files (*.jpg)|*.jpg|bmp files (*.bmp)|*.bmp";
            openFileDialog1.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            string imagepath = openFileDialog1.FileName;
            loadImage = Path.GetFileName(imagepath);
            pictureBox1.Image = Image.FromFile(imagepath);
        }

        public void Estrai()
        {
            Random casuale = new Random();
            int valoreEstratto = casuale.Next(0, 52);
            pictureBox2.Image = imageList1.Images[valoreEstratto];
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Estrai();
        }
    }
}
