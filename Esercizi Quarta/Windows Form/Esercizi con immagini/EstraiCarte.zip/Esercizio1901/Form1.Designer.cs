﻿
namespace Esercizio1901
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnEstrai = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnEstrai2 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.btnGioca = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(12, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 144);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // btnEstrai
            // 
            this.btnEstrai.Location = new System.Drawing.Point(12, 168);
            this.btnEstrai.Name = "btnEstrai";
            this.btnEstrai.Size = new System.Drawing.Size(100, 46);
            this.btnEstrai.TabIndex = 3;
            this.btnEstrai.Text = "Estrai carta";
            this.btnEstrai.UseVisualStyleBackColor = true;
            this.btnEstrai.Click += new System.EventHandler(this.button2_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "0.jpg");
            this.imageList1.Images.SetKeyName(1, "c1.jpg");
            this.imageList1.Images.SetKeyName(2, "c2.jpg");
            this.imageList1.Images.SetKeyName(3, "c3.jpg");
            this.imageList1.Images.SetKeyName(4, "c4.jpg");
            this.imageList1.Images.SetKeyName(5, "c5.jpg");
            this.imageList1.Images.SetKeyName(6, "c6.jpg");
            this.imageList1.Images.SetKeyName(7, "c7.jpg");
            this.imageList1.Images.SetKeyName(8, "c8.jpg");
            this.imageList1.Images.SetKeyName(9, "c9.jpg");
            this.imageList1.Images.SetKeyName(10, "c10.jpg");
            this.imageList1.Images.SetKeyName(11, "c11.jpg");
            this.imageList1.Images.SetKeyName(12, "c12.jpg");
            this.imageList1.Images.SetKeyName(13, "c13.jpg");
            this.imageList1.Images.SetKeyName(14, "f1.jpg");
            this.imageList1.Images.SetKeyName(15, "f2.jpg");
            this.imageList1.Images.SetKeyName(16, "f3.jpg");
            this.imageList1.Images.SetKeyName(17, "f4.jpg");
            this.imageList1.Images.SetKeyName(18, "f5.jpg");
            this.imageList1.Images.SetKeyName(19, "f6.jpg");
            this.imageList1.Images.SetKeyName(20, "f7.jpg");
            this.imageList1.Images.SetKeyName(21, "f8.jpg");
            this.imageList1.Images.SetKeyName(22, "f9.jpg");
            this.imageList1.Images.SetKeyName(23, "f10.jpg");
            this.imageList1.Images.SetKeyName(24, "f11.jpg");
            this.imageList1.Images.SetKeyName(25, "f12.jpg");
            this.imageList1.Images.SetKeyName(26, "f13.jpg");
            this.imageList1.Images.SetKeyName(27, "p1.jpg");
            this.imageList1.Images.SetKeyName(28, "p2.jpg");
            this.imageList1.Images.SetKeyName(29, "p3.jpg");
            this.imageList1.Images.SetKeyName(30, "p4.jpg");
            this.imageList1.Images.SetKeyName(31, "p5.jpg");
            this.imageList1.Images.SetKeyName(32, "p6.jpg");
            this.imageList1.Images.SetKeyName(33, "p7.jpg");
            this.imageList1.Images.SetKeyName(34, "p8.jpg");
            this.imageList1.Images.SetKeyName(35, "p9.jpg");
            this.imageList1.Images.SetKeyName(36, "p10.jpg");
            this.imageList1.Images.SetKeyName(37, "p11.jpg");
            this.imageList1.Images.SetKeyName(38, "p12.jpg");
            this.imageList1.Images.SetKeyName(39, "p13.jpg");
            this.imageList1.Images.SetKeyName(40, "q1.jpg");
            this.imageList1.Images.SetKeyName(41, "q2.jpg");
            this.imageList1.Images.SetKeyName(42, "q3.jpg");
            this.imageList1.Images.SetKeyName(43, "q4.jpg");
            this.imageList1.Images.SetKeyName(44, "q5.jpg");
            this.imageList1.Images.SetKeyName(45, "q6.jpg");
            this.imageList1.Images.SetKeyName(46, "q7.jpg");
            this.imageList1.Images.SetKeyName(47, "q8.jpg");
            this.imageList1.Images.SetKeyName(48, "q9.jpg");
            this.imageList1.Images.SetKeyName(49, "q10.jpg");
            this.imageList1.Images.SetKeyName(50, "q11.jpg");
            this.imageList1.Images.SetKeyName(51, "q12.jpg");
            this.imageList1.Images.SetKeyName(52, "q13.jpg");
            // 
            // btnEstrai2
            // 
            this.btnEstrai2.Location = new System.Drawing.Point(156, 168);
            this.btnEstrai2.Name = "btnEstrai2";
            this.btnEstrai2.Size = new System.Drawing.Size(100, 46);
            this.btnEstrai2.TabIndex = 5;
            this.btnEstrai2.Text = "Estrai carta";
            this.btnEstrai2.UseVisualStyleBackColor = true;
            this.btnEstrai2.Click += new System.EventHandler(this.btnEstrai2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(156, 5);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 144);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // btnGioca
            // 
            this.btnGioca.Location = new System.Drawing.Point(308, 63);
            this.btnGioca.Name = "btnGioca";
            this.btnGioca.Size = new System.Drawing.Size(100, 46);
            this.btnGioca.TabIndex = 6;
            this.btnGioca.Text = "Gioca";
            this.btnGioca.UseVisualStyleBackColor = true;
            this.btnGioca.Click += new System.EventHandler(this.btnGioca_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(308, 115);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(100, 46);
            this.btnReset.TabIndex = 7;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 237);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnGioca);
            this.Controls.Add(this.btnEstrai2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.btnEstrai);
            this.Controls.Add(this.pictureBox2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnEstrai;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btnEstrai2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.Button btnGioca;
        private System.Windows.Forms.Button btnReset;
    }
}

