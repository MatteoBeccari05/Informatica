﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Esercizio1901
{
    public partial class Form1 : Form
    {
        enum seme
        {
            cuori,
            quadri,
            fiori,
            picche
        }
        seme figura;
        Random valore = new Random();
        string loadImage;
        string percorso = Application.StartupPath + "\\carte";
        public Form1()
        {
            InitializeComponent();
            btnEstrai.Visible = false;
            btnEstrai2.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            
        }

        public string Estrai()
        {
            string valoreCarta="";
            seme figura;
            figura = (seme)valore.Next(0, 4);

            switch (figura)
            {
                case seme.cuori: valoreCarta = "c" + valore.Next(1, 14); break;
                case seme.quadri: valoreCarta = "q" + valore.Next(1, 14); break;
                case seme.fiori: valoreCarta = "f" + valore.Next(1, 14); break;
                case seme.picche: valoreCarta = "p" + valore.Next(1, 14); break;
            }
            return valoreCarta;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nome = Estrai();
            openFileDialog1.InitialDirectory = percorso;
            loadImage = Path.GetFileName(nome);
            pictureBox2.Image = Image.FromFile(percorso + "\\" + nome + ".jpg");
        }

        private void btnEstrai2_Click(object sender, EventArgs e)
        {
            string nome = Estrai();
            openFileDialog2.InitialDirectory = percorso;
            loadImage = Path.GetFileName(nome);
            pictureBox3.Image = Image.FromFile(percorso + "\\" + nome + ".jpg");
        }
        private void controllo()
        {
            if (pictureBox2.Image == pictureBox3.Image)
            {
                MessageBox.Show("HAI VINTO");
            }
        }

        private void btnGioca_Click(object sender, EventArgs e)
        {
            btnEstrai.Visible = true;
            btnEstrai2.Visible = true;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            btnEstrai.Visible = false;
            btnEstrai2.Visible = false;
            pictureBox2.Image = null;
            pictureBox3.Image = null;
        }
    }
}
