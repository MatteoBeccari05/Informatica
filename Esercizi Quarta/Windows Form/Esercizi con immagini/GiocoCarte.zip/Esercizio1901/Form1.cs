﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Esercizio1901
{
    public partial class Form1 : Form
    {
        enum seme
        {
            cuori,
            quadri,
            fiori,
            picche
        }

        seme figura;
        Random valore = new Random();
        string loadImage;
        string percorso = Application.StartupPath + "\\carte";
        string p1, p2;
        public Form1()
        {
            InitializeComponent();
            pictureBox2.Image = Image.FromFile(percorso + "\\" + "0" + ".jpg");
            pictureBox3.Image = Image.FromFile(percorso + "\\" + "0" + ".jpg");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            
        }

        public string Estrai()
        {
            string valoreCarta="";
            seme figura;
            figura = (seme)valore.Next(0, 4);

            switch (figura)
            {
                case seme.cuori: valoreCarta = "c" + valore.Next(1, 14); break;
                case seme.quadri: valoreCarta = "q" + valore.Next(1, 14); break;
                case seme.fiori: valoreCarta = "f" + valore.Next(1, 14); break;
                case seme.picche: valoreCarta = "p" + valore.Next(1, 14); break;
            }
            return valoreCarta;
            
        }

        private void btnGioca_Click(object sender, EventArgs e)
        {
            if (pictureBox2.Image == pictureBox3.Image && pictureBox2.Image!=null && pictureBox3.Image!=null)
            {
                MessageBox.Show("Hai vinto");
            }
            else
            {
                MessageBox.Show("Hai perso");
                reset();
            }

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            reset();
        }
        private void estrai1()
        {
            string nome = Estrai();
            openFileDialog1.InitialDirectory = percorso;
            loadImage = Path.GetFileName(nome);
            pictureBox2.Image = Image.FromFile(percorso + "\\" + nome + ".jpg");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            estrai1();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            estrai2();
        }

        private void estrai2()
        {
            string nome = Estrai();
            openFileDialog2.InitialDirectory = percorso;
            loadImage = Path.GetFileName(nome);
            pictureBox3.Image = Image.FromFile(percorso + "\\" + nome + ".jpg");
            
        }
        private void reset()
        {
            pictureBox2.Image = null;
            pictureBox3.Image = null;
            pictureBox2.Image = Image.FromFile(percorso + "\\" + "0" + ".jpg");
            pictureBox3.Image = Image.FromFile(percorso + "\\" + "0" + ".jpg");
        }


        
    }
}
