﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormImmagini
{
    public struct supereroe
    {
        public string nome;
        public string path;
        public string immagini;
        public override string ToString()
        {
            return string.Format($"{nome} - img: {immagini}");
        }
    }
    public partial class Form1 : Form
    {
        List<supereroe> lista = new List<supereroe>(3);
        public Form1()
        {
            InitializeComponent();
        }

        private void inserisciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ModImmagine fm = new ModImmagine();
            DialogResult risultato = fm.ShowDialog();
            if (risultato == DialogResult.OK)
            {
                lista.Add(fm.GetSupereroe());
                listBox1.DataSource = null;
                listBox1.DataSource = lista;

            }
        }

        private void visualizzaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
