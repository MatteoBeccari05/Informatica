﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FormImmagini
{
    public partial class ModImmagine : Form
    {
        supereroe s1;
        string loadImage;
        string percorso = Application.StartupPath;
        //OpenFileDialog openFileDialog1 = new OpenFileDialog();
        public ModImmagine()
        {
            InitializeComponent();
        }

        private void btn_sfoglia_Click(object sender, EventArgs e)
        {
            //textBox1.Text = percorso;
            openFileDialog1.InitialDirectory = percorso + "\\image";
            openFileDialog1.CheckFileExists = true;
            openFileDialog1.FileName = "default";
            openFileDialog1.DefaultExt = "jpg";
            openFileDialog1.Filter = "jpg files (*.jpg)|*.jpg|bmp files (*.bmp)|*.bmp";
            openFileDialog1.ShowDialog();
        }

        private void ModImmagine_Load(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            string imagepath = openFileDialog1.FileName;
            loadImage = Path.GetFileName(imagepath);
            pictureBox1.Image = Image.FromFile(imagepath);
        }

        private void btn_conferma_Click(object sender, EventArgs e)
        {
            s1.nome = textBox1.Text;
            s1.immagini = loadImage;
            DialogResult = DialogResult.OK;
        }

        public supereroe GetSupereroe()
        {
            return s1;
        }
    }
}
