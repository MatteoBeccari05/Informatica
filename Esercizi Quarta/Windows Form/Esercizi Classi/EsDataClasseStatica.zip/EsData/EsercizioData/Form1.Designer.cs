﻿namespace EsercizioData
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbInserimento = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtInserimento = new System.Windows.Forms.TextBox();
            this.btnControlla = new System.Windows.Forms.Button();
            this.btnNewDate = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.gbMese = new System.Windows.Forms.GroupBox();
            this.rbCarattere = new System.Windows.Forms.RadioButton();
            this.rbNumerico = new System.Windows.Forms.RadioButton();
            this.gbBisestile = new System.Windows.Forms.GroupBox();
            this.cbBisestile = new System.Windows.Forms.CheckBox();
            this.gbUPDOWN = new System.Windows.Forms.GroupBox();
            this.btnDOWN = new System.Windows.Forms.Button();
            this.btnUP = new System.Windows.Forms.Button();
            this.UpDown = new System.Windows.Forms.NumericUpDown();
            this.Calendario = new System.Windows.Forms.MonthCalendar();
            this.gbInserimento.SuspendLayout();
            this.gbMese.SuspendLayout();
            this.gbBisestile.SuspendLayout();
            this.gbUPDOWN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // gbInserimento
            // 
            this.gbInserimento.Controls.Add(this.label1);
            this.gbInserimento.Controls.Add(this.txtInserimento);
            this.gbInserimento.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbInserimento.Location = new System.Drawing.Point(12, 12);
            this.gbInserimento.Name = "gbInserimento";
            this.gbInserimento.Size = new System.Drawing.Size(258, 77);
            this.gbInserimento.TabIndex = 0;
            this.gbInserimento.TabStop = false;
            this.gbInserimento.Text = "Inserimento data";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "DATA";
            // 
            // txtInserimento
            // 
            this.txtInserimento.Location = new System.Drawing.Point(48, 31);
            this.txtInserimento.Name = "txtInserimento";
            this.txtInserimento.Size = new System.Drawing.Size(192, 23);
            this.txtInserimento.TabIndex = 0;
            this.txtInserimento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInserimento_KeyPress);
            // 
            // btnControlla
            // 
            this.btnControlla.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnControlla.Location = new System.Drawing.Point(318, 22);
            this.btnControlla.Name = "btnControlla";
            this.btnControlla.Size = new System.Drawing.Size(75, 44);
            this.btnControlla.TabIndex = 1;
            this.btnControlla.Text = "Controlla";
            this.btnControlla.UseVisualStyleBackColor = true;
            this.btnControlla.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnNewDate
            // 
            this.btnNewDate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewDate.Location = new System.Drawing.Point(399, 22);
            this.btnNewDate.Name = "btnNewDate";
            this.btnNewDate.Size = new System.Drawing.Size(75, 44);
            this.btnNewDate.TabIndex = 2;
            this.btnNewDate.Text = "Nuova data";
            this.btnNewDate.UseVisualStyleBackColor = true;
            this.btnNewDate.Click += new System.EventHandler(this.btnNewDate_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(359, 247);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 44);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Chiudi";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // gbMese
            // 
            this.gbMese.Controls.Add(this.rbCarattere);
            this.gbMese.Controls.Add(this.rbNumerico);
            this.gbMese.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbMese.Location = new System.Drawing.Point(12, 96);
            this.gbMese.Name = "gbMese";
            this.gbMese.Size = new System.Drawing.Size(126, 100);
            this.gbMese.TabIndex = 4;
            this.gbMese.TabStop = false;
            this.gbMese.Text = "Mese";
            // 
            // rbCarattere
            // 
            this.rbCarattere.AutoSize = true;
            this.rbCarattere.Location = new System.Drawing.Point(20, 56);
            this.rbCarattere.Name = "rbCarattere";
            this.rbCarattere.Size = new System.Drawing.Size(77, 19);
            this.rbCarattere.TabIndex = 1;
            this.rbCarattere.TabStop = true;
            this.rbCarattere.Text = "Carattere";
            this.rbCarattere.UseVisualStyleBackColor = true;
            this.rbCarattere.CheckedChanged += new System.EventHandler(this.rbCarattere_CheckedChanged);
            // 
            // rbNumerico
            // 
            this.rbNumerico.AutoSize = true;
            this.rbNumerico.Location = new System.Drawing.Point(20, 32);
            this.rbNumerico.Name = "rbNumerico";
            this.rbNumerico.Size = new System.Drawing.Size(79, 19);
            this.rbNumerico.TabIndex = 0;
            this.rbNumerico.TabStop = true;
            this.rbNumerico.Text = "Numerico";
            this.rbNumerico.UseVisualStyleBackColor = true;
            this.rbNumerico.CheckedChanged += new System.EventHandler(this.rbNumerico_CheckedChanged);
            // 
            // gbBisestile
            // 
            this.gbBisestile.Controls.Add(this.cbBisestile);
            this.gbBisestile.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbBisestile.Location = new System.Drawing.Point(144, 96);
            this.gbBisestile.Name = "gbBisestile";
            this.gbBisestile.Size = new System.Drawing.Size(126, 100);
            this.gbBisestile.TabIndex = 5;
            this.gbBisestile.TabStop = false;
            this.gbBisestile.Text = "Bisestile";
            // 
            // cbBisestile
            // 
            this.cbBisestile.AutoSize = true;
            this.cbBisestile.Location = new System.Drawing.Point(19, 43);
            this.cbBisestile.Name = "cbBisestile";
            this.cbBisestile.Size = new System.Drawing.Size(71, 19);
            this.cbBisestile.TabIndex = 0;
            this.cbBisestile.Text = "Bisestile";
            this.cbBisestile.UseVisualStyleBackColor = true;
            this.cbBisestile.CheckedChanged += new System.EventHandler(this.cbBisestile_CheckedChanged);
            // 
            // gbUPDOWN
            // 
            this.gbUPDOWN.Controls.Add(this.btnDOWN);
            this.gbUPDOWN.Controls.Add(this.btnUP);
            this.gbUPDOWN.Controls.Add(this.UpDown);
            this.gbUPDOWN.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbUPDOWN.Location = new System.Drawing.Point(12, 202);
            this.gbUPDOWN.Name = "gbUPDOWN";
            this.gbUPDOWN.Size = new System.Drawing.Size(258, 100);
            this.gbUPDOWN.TabIndex = 6;
            this.gbUPDOWN.TabStop = false;
            this.gbUPDOWN.Text = "UP/DOWN";
            // 
            // btnDOWN
            // 
            this.btnDOWN.Location = new System.Drawing.Point(162, 56);
            this.btnDOWN.Name = "btnDOWN";
            this.btnDOWN.Size = new System.Drawing.Size(63, 23);
            this.btnDOWN.TabIndex = 2;
            this.btnDOWN.Text = "DOWN";
            this.btnDOWN.UseVisualStyleBackColor = true;
            this.btnDOWN.Click += new System.EventHandler(this.btnDOWN_Click);
            // 
            // btnUP
            // 
            this.btnUP.Location = new System.Drawing.Point(162, 27);
            this.btnUP.Name = "btnUP";
            this.btnUP.Size = new System.Drawing.Size(63, 23);
            this.btnUP.TabIndex = 1;
            this.btnUP.Text = "UP";
            this.btnUP.UseVisualStyleBackColor = true;
            this.btnUP.Click += new System.EventHandler(this.btnUP_Click);
            // 
            // UpDown
            // 
            this.UpDown.Location = new System.Drawing.Point(15, 43);
            this.UpDown.Name = "UpDown";
            this.UpDown.Size = new System.Drawing.Size(111, 23);
            this.UpDown.TabIndex = 0;
            // 
            // Calendario
            // 
            this.Calendario.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Calendario.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calendario.Location = new System.Drawing.Point(282, 78);
            this.Calendario.Name = "Calendario";
            this.Calendario.TabIndex = 7;
            this.Calendario.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.Calendario_DateChanged);
            this.Calendario.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.Calendario_DateSelected);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(518, 310);
            this.Controls.Add(this.Calendario);
            this.Controls.Add(this.gbUPDOWN);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.gbBisestile);
            this.Controls.Add(this.gbMese);
            this.Controls.Add(this.btnNewDate);
            this.Controls.Add(this.btnControlla);
            this.Controls.Add(this.gbInserimento);
            this.Name = "Form1";
            this.Text = "Controllo Data";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbInserimento.ResumeLayout(false);
            this.gbInserimento.PerformLayout();
            this.gbMese.ResumeLayout(false);
            this.gbMese.PerformLayout();
            this.gbBisestile.ResumeLayout(false);
            this.gbBisestile.PerformLayout();
            this.gbUPDOWN.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.UpDown)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbInserimento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtInserimento;
        private System.Windows.Forms.Button btnControlla;
        private System.Windows.Forms.Button btnNewDate;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox gbMese;
        private System.Windows.Forms.RadioButton rbCarattere;
        private System.Windows.Forms.RadioButton rbNumerico;
        private System.Windows.Forms.GroupBox gbBisestile;
        private System.Windows.Forms.CheckBox cbBisestile;
        private System.Windows.Forms.GroupBox gbUPDOWN;
        private System.Windows.Forms.Button btnDOWN;
        private System.Windows.Forms.Button btnUP;
        private System.Windows.Forms.NumericUpDown UpDown;
        private System.Windows.Forms.MonthCalendar Calendario;
    }
}

