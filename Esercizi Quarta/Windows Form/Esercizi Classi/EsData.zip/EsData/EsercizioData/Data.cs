﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EsercizioData
{
    class Data
    {
        int _giorno;
        Mese _mese;
        int _anno;
        bool bisestile;

        public Data(int day, int month, int year)
        {
            if (ControlloMese(month) == true)
            {
                if (ControlloAnno(year) == true)
                {
                    Bisestile = ControlloAnno(year);
                    if (ControllaGiorno(month, day, Bisestile))
                    {
                        Giorno = day;
                        Mese = (Mese)month;
                        Anno = year;
                    }
                    else
                    {
                        throw new Exception("Giorno non valido");
                    }
                }
                else
                {
                    throw new Exception("Anno non valido");
                }
            }
            else
            {
                throw new Exception("Mese non valido");
            }
        }

        public static bool ControlloMese(int month)        //Controlla se il mese numerico è corretto 
        {
            bool r = false;             //ritorno

            if (month >= 1 && month <= 12)
            {
                r = true;
            }

            return r;
        }

        public void CambiaGiorni(int count)
        {
            int giornoCambiato = this.Giorno;
            int meseCambiato = (int)this.Mese;
            bool bisestileCambiato = this.Bisestile;

            if (count > 0)
            {
                for (int i = 0; i < count; i++)    //per ogni aumento del giorno 
                {
                    giornoCambiato+=1;
                    if (!ControllaGiorno(meseCambiato, giornoCambiato, bisestileCambiato))
                    {
                        giornoCambiato = 1;        //mese successivo 
                        meseCambiato += 1;      //incremento il mese
                        if (!ControlloMese(meseCambiato))
                        {
                            meseCambiato = 1;
                            
                        }
                    }
                }
                
            }
            else if(count<0)
            {
                _giorno = _giorno - count;
            }
        }

        public static bool ControlloBisestile(int year)               //controlla se l'anno è bisestile
        {
            bool r = false;             //ritorno

            if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
            {
                r = true;
            }

            return r;
        }

        public static bool ControllaGiorno(int month, int day, bool bisestile)   //controlla se il giorno è corretto a seconda del mese 
        {
            bool r = false;             //ritorno
            if (day >= 1 && day <= GiorniMese(month, bisestile))
            {
                r = true;
            }
            return r;
        }

        public static bool ControlloAnno(int year)    //controlla l'anno
        {
            bool r = false;         //ritorno

            if (year >= 1600)
            {
                r = true;
            }
            return r;
        }

        public static int GiorniMese(int month, bool bisestile)           //controlla quanti giorni ha un mese
        {
            int r = -1;             //ritorno
            switch (month)
            {
                case 1: r = 31; break;
                case 3: r = 31; break;
                case 4: r = 30; break;
                case 5: r = 31; break;
                case 6: r = 30; break;
                case 7: r = 31; break;
                case 8: r = 31; break;
                case 9: r = 30; break;
                case 10: r = 31; break;
                case 11: r = 30; break;
                case 12: r = 31; break;
                case 2:
                    if (bisestile)
                    {
                        r = 29;
                    }
                    else
                    {
                        r = 28;
                    }
                    break;
            }

            return r;
        }

        public static string MeseLetterario(int month)
        {
            if (ControlloMese(month))
            {
                if (month >= 1 && month <= 12)
                {
                    return ((Mese)month).ToString();
                }
                else
                {
                    throw new Exception("Mese non valido");
                }
            }
            else
            {
                throw new Exception("Mese non corretto");
            }
        }

        public static int MeseNumerico(string month)
        {
            int r = ConvertiMese(month);            //ritorno
            if (r != -1)
            {
                return r;
            }
            else
            {
                throw new Exception("Mese non valido");
            }
        }

        public static int ConvertiMese(string month)
        {
            int r = -1;          //ritorno
            switch (month)
            {
                case "Gennaio": r = 1; break;
                case "Febbraio": r = 2; break;
                case "Marzo": r = 3; break;
                case "Aprile": r = 4; break;
                case "Maggio": r = 5; break;
                case "Giugno": r = 6; break;
                case "Luglio": r = 7; break;
                case "Agosto": r = 8; break;
                case "Settembre": r = 9; break;
                case "Ottobre": r = 10; break;
                case "Novembre": r = 11; break;
                case "Dicembre": r = 12; break;
            }
            return r;
        }

        public string ToString(bool meseCarattere)          //metodo per stampare a video la data
        {
            if (meseCarattere == true)
            {
                return string.Format($"{this.Giorno.ToString()} / {Mese.ToString()} / {Anno.ToString()}");

            }
            else
            {
                return string.Format($"{this.Giorno.ToString()} / {(int)Mese} / {Anno.ToString()}");
            }
        }

        #region Proprieta
        public int Giorno
        {
            get
            {
                return _giorno;
            }

            private set
            {
                _giorno = value;
            }
        }
        
        public Mese Mese
        {
            get
            {
                return _mese;
            }

            private set
            {
                _mese = value;
            }
        }
       
        public int Anno
        {
            get
            {
                return _anno;
            }

            private set
            {
                _anno = value;
            }
        }

        public bool Bisestile
        {
            get
            {
                return bisestile;
            }
            private set
            {
                bisestile = value;
            }
        }
        #endregion


    }
}
