﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace EsercizioData
{
    public partial class Form1 : Form
    {
        Data data;
        string[] dt = new string[3];
        bool txt;   //se la data è numerica o letteraria 
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            gbMese.Enabled = false;
            gbBisestile.Enabled = false;
            gbUPDOWN.Enabled = false;
            btnNewDate.Enabled = false;
            Calendario.TodayDate = DateTime.Now;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Inserimento();
            gbMese.Enabled = true;
            gbUPDOWN.Enabled = true;
            rbNumerico.Checked = true;
            gbBisestile.Enabled = true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Chiudere il programma?", "Messaggio", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtInserimento_KeyPress(object sender, KeyPressEventArgs e)  //mi impedisce di inserire lettere 
        {
            char a = (char)e.KeyChar;
            if (!char.IsDigit(a) && e.KeyChar != '/' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            btnNewDate.Enabled = true;
        }

        private void btnNewDate_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void btnUP_Click(object sender, EventArgs e)
        {
            Data tmp = this.data;

            int g = Convert.ToInt32(UpDown.Value);
            tmp.CambiaGiorni(g);
            Reset();
            this.data = tmp;
            Aggiorna();
            tmp = null;
        }

        private void btnDOWN_Click(object sender, EventArgs e)
        {
            data.CambiaGiorni(Convert.ToInt32(UpDown.Value));
            Aggiorna();
        }

        private void rbCarattere_CheckedChanged(object sender, EventArgs e)
        {
            if (rbCarattere.Checked == true && txt == false)
            {
                txt = true;
                if (data != null) 
                {
                    this.Aggiorna();
                }
            }
        }

        private void Inserimento()
        {
            int day, month, year;
            try
            {
                dt = txtInserimento.Text.Split('/');
                string giorno = dt[0];
                string mese = dt[1];
                string anno = dt[2];

                day = int.Parse(giorno);
                month = int.Parse(mese);
                year = int.Parse(anno);

                if (!txt)
                {
                    data = new Data(day, Convert.ToInt32(month), year);
                }

                Calendario.SetDate(new DateTime(data.Anno, (int)data.Mese, data.Giorno));      //aggiorno il calendario 
            }
            catch (ApplicationException)
            {
                MessageBox.Show("Errore nel formato della data");
            }
        }

        

        private void rbNumerico_CheckedChanged(object sender, EventArgs e)
        {
            if (rbNumerico.Checked == true && txt == true)
            {
                txt = false;
                if (data != null)
                {
                    Aggiorna();
                }
            }
        }

        private void cbBisestile_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void Calendario_DateSelected(object sender, DateRangeEventArgs e)
        {
            txtInserimento.Text = string.Empty;
            txtInserimento.Text = Calendario.SelectionRange.Start.ToString("dd / MMMM / yyyy");
        }

        public void Reset()
        {
            txtInserimento.Text = string.Empty; 
            gbUPDOWN.Enabled = false; 
            data = null; 
            btnNewDate.Enabled = false; 
            if (txt == true) 
            {
                rbCarattere.Checked = true;
                rbNumerico.Checked = false;
            }
            else
            {
                rbCarattere.Checked = false;
                rbNumerico.Checked = true;
            }

            gbBisestile.Enabled = false; 
            gbMese.Enabled = false;
        }


        private void Aggiorna()
        {
            gbMese.Enabled = true;
            gbBisestile.Enabled = true;
            gbUPDOWN.Enabled = true;
            btnNewDate.Enabled = true; //rende visibili i vari controlli
            if (data.Bisestile == true) //check della checkbox se è bisestile
            {
                cbBisestile.Checked = true;
            }
            else
            {
                cbBisestile.Checked = false;
            }
            if (txt == true) 
            {
                rbCarattere.Checked = true;
                txt = true;
            }
            else
            {
                rbNumerico.Checked = true;
                txt = false;
            }
            txtInserimento.Text = data.ToString(txt); 

        }
    }
}
