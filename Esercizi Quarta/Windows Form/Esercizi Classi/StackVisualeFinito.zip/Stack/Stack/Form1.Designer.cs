﻿
namespace Stack
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.listaStack = new System.Windows.Forms.ListBox();
            this.btnTop = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnNElementi = new System.Windows.Forms.Button();
            this.btnPush = new System.Windows.Forms.Button();
            this.btnPop = new System.Windows.Forms.Button();
            this.txtInsert = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listaStack
            // 
            this.listaStack.FormattingEnabled = true;
            this.listaStack.Location = new System.Drawing.Point(12, 64);
            this.listaStack.Name = "listaStack";
            this.listaStack.Size = new System.Drawing.Size(154, 225);
            this.listaStack.TabIndex = 15;
            // 
            // btnTop
            // 
            this.btnTop.Location = new System.Drawing.Point(211, 156);
            this.btnTop.Name = "btnTop";
            this.btnTop.Size = new System.Drawing.Size(75, 45);
            this.btnTop.TabIndex = 14;
            this.btnTop.Text = "Cima dello stack";
            this.btnTop.UseVisualStyleBackColor = true;
            this.btnTop.Click += new System.EventHandler(this.btnTop_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(211, 261);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 25);
            this.btnClear.TabIndex = 13;
            this.btnClear.Text = "Reset";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnNElementi
            // 
            this.btnNElementi.Location = new System.Drawing.Point(211, 105);
            this.btnNElementi.Name = "btnNElementi";
            this.btnNElementi.Size = new System.Drawing.Size(75, 45);
            this.btnNElementi.TabIndex = 12;
            this.btnNElementi.Text = "Numero elementi";
            this.btnNElementi.UseVisualStyleBackColor = true;
            this.btnNElementi.Click += new System.EventHandler(this.btnNElementi_Click);
            // 
            // btnPush
            // 
            this.btnPush.Location = new System.Drawing.Point(211, 43);
            this.btnPush.Name = "btnPush";
            this.btnPush.Size = new System.Drawing.Size(75, 25);
            this.btnPush.TabIndex = 11;
            this.btnPush.Text = "Push";
            this.btnPush.UseVisualStyleBackColor = true;
            this.btnPush.Click += new System.EventHandler(this.btnPush_Click);
            // 
            // btnPop
            // 
            this.btnPop.Location = new System.Drawing.Point(211, 74);
            this.btnPop.Name = "btnPop";
            this.btnPop.Size = new System.Drawing.Size(75, 25);
            this.btnPop.TabIndex = 10;
            this.btnPop.Text = "Pop";
            this.btnPop.UseVisualStyleBackColor = true;
            this.btnPop.Click += new System.EventHandler(this.btnPop_Click);
            // 
            // txtInsert
            // 
            this.txtInsert.Location = new System.Drawing.Point(28, 28);
            this.txtInsert.Name = "txtInsert";
            this.txtInsert.Size = new System.Drawing.Size(116, 20);
            this.txtInsert.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Inserire un valore";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 298);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listaStack);
            this.Controls.Add(this.btnTop);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnNElementi);
            this.Controls.Add(this.btnPush);
            this.Controls.Add(this.btnPop);
            this.Controls.Add(this.txtInsert);
            this.Name = "Form1";
            this.Text = "Stack";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listaStack;
        private System.Windows.Forms.Button btnTop;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnNElementi;
        private System.Windows.Forms.Button btnPush;
        private System.Windows.Forms.Button btnPop;
        private System.Windows.Forms.TextBox txtInsert;
        private System.Windows.Forms.Label label1;
    }
}

