﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stack
{
    public partial class Form1 : Form
    {
        Stack stack = new Stack();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnNElementi_Click(object sender, EventArgs e)             //conto quanti elementi ci sono dentro lo stack 
        {
            ContaElementi();
        }

        public void AggiornaTXT()           //aggiorno la lista
        {
            listaStack.DataSource = null;
            listaStack.DataSource = stack.Ritorno;
            txtInsert.Text = string.Empty;
        }

        private void btnPush_Click(object sender, EventArgs e)
        {
            Push();
            AggiornaTXT();
        }

        private void btnTop_Click(object sender, EventArgs e)           //stampo a video il primo elemento dello stack 
        {
            ElementoCima();
        }

        private void btnClear_Click(object sender, EventArgs e)     //resetto lo stack 
        {
            stack.Reset();
            AggiornaTXT();
        }

        public void ElementoCima()
        {
            if (stack.GetElementi > 0)                                  //stampo l'elemento in cima allo stack (primo)
            {
                MessageBox.Show("Elemento in cima allo stack: " + Convert.ToString(stack.ElementoCima));
            }
            else
            {
                MessageBox.Show("Stack vuoto, inserire degli elementi");
            }
        }

        public void Push()
        {
            try
            {
                stack.Push(Convert.ToInt32(txtInsert.Text));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Impossibile eseguire il push: " + ex.Message);          //scrivo a video l'eccezzione ritornata
            }
        }

        public void ContaElementi()
        {
            if (stack.GetElementi > 0)              //controllo che ci siano elementi nello stack
            {
                MessageBox.Show($"Numero elementi: {stack.GetElementi}");               //conta gli elelemtni presenti all'interno dello stack
            }
            else
            {
                MessageBox.Show("Stack vuoto, inserire degli elementi");
            }
        }

        private void btnPop_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show("Elemento POP: " + Convert.ToString(stack.Pop()));         //stampo il pop (ultimo elemento stack)
            }
            catch(Exception ex)
            {
                MessageBox.Show("Errore: " + ex.Message);          //scrivo a video l'eccezzione ritornata
            }
        }
    }
}
