﻿
namespace TextBox
{
    partial class form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIns = new System.Windows.Forms.TextBox();
            this.lista = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblElementi = new System.Windows.Forms.Label();
            this.lblSelez = new System.Windows.Forms.Label();
            this.btnSelez = new System.Windows.Forms.Button();
            this.btnCarica = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnR2 = new System.Windows.Forms.Button();
            this.btnCaricaNum = new System.Windows.Forms.Button();
            this.btnDataS = new System.Windows.Forms.Button();
            this.btnRemFilosofo = new System.Windows.Forms.Button();
            this.SelezElem = new System.Windows.Forms.Button();
            this.gbBottoni = new System.Windows.Forms.GroupBox();
            this.gbListe = new System.Windows.Forms.GroupBox();
            this.btnTrova = new System.Windows.Forms.Button();
            this.btnRemoveList = new System.Windows.Forms.Button();
            this.btnNele = new System.Windows.Forms.Button();
            this.btnCapacità = new System.Windows.Forms.Button();
            this.btnAddList = new System.Windows.Forms.Button();
            this.lblCapacità = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCap = new System.Windows.Forms.Label();
            this.lblEl = new System.Windows.Forms.Label();
            this.btnCancella = new System.Windows.Forms.Button();
            this.btnRange = new System.Windows.Forms.Button();
            this.btnRimuoviTXT = new System.Windows.Forms.Button();
            this.btnCancella2 = new System.Windows.Forms.Button();
            this.gbBottoni.SuspendLayout();
            this.gbListe.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtIns
            // 
            this.txtIns.Location = new System.Drawing.Point(12, 30);
            this.txtIns.Name = "txtIns";
            this.txtIns.Size = new System.Drawing.Size(167, 20);
            this.txtIns.TabIndex = 0;
            this.txtIns.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIns_KeyPress);
            // 
            // lista
            // 
            this.lista.FormattingEnabled = true;
            this.lista.Location = new System.Drawing.Point(12, 56);
            this.lista.Name = "lista";
            this.lista.Size = new System.Drawing.Size(167, 290);
            this.lista.TabIndex = 1;
            this.lista.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Inserisci";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 234);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 45);
            this.button1.TabIndex = 3;
            this.button1.Text = "Cancella";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblElementi
            // 
            this.lblElementi.AutoSize = true;
            this.lblElementi.Location = new System.Drawing.Point(12, 394);
            this.lblElementi.Name = "lblElementi";
            this.lblElementi.Size = new System.Drawing.Size(0, 13);
            this.lblElementi.TabIndex = 4;
            // 
            // lblSelez
            // 
            this.lblSelez.AutoSize = true;
            this.lblSelez.Location = new System.Drawing.Point(12, 360);
            this.lblSelez.Name = "lblSelez";
            this.lblSelez.Size = new System.Drawing.Size(0, 13);
            this.lblSelez.TabIndex = 5;
            // 
            // btnSelez
            // 
            this.btnSelez.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSelez.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelez.Location = new System.Drawing.Point(12, 183);
            this.btnSelez.Name = "btnSelez";
            this.btnSelez.Size = new System.Drawing.Size(89, 45);
            this.btnSelez.TabIndex = 6;
            this.btnSelez.Text = "Seleziona";
            this.btnSelez.UseVisualStyleBackColor = false;
            this.btnSelez.Click += new System.EventHandler(this.btnSelez_Click);
            // 
            // btnCarica
            // 
            this.btnCarica.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCarica.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCarica.Location = new System.Drawing.Point(12, 30);
            this.btnCarica.Name = "btnCarica";
            this.btnCarica.Size = new System.Drawing.Size(89, 45);
            this.btnCarica.TabIndex = 7;
            this.btnCarica.Text = "Carica Stringhe";
            this.btnCarica.UseVisualStyleBackColor = false;
            this.btnCarica.Click += new System.EventHandler(this.btnCarica_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRemove.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(12, 81);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(89, 45);
            this.btnRemove.TabIndex = 8;
            this.btnRemove.Text = "Rimuovi";
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnR2
            // 
            this.btnR2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnR2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnR2.Location = new System.Drawing.Point(12, 132);
            this.btnR2.Name = "btnR2";
            this.btnR2.Size = new System.Drawing.Size(89, 45);
            this.btnR2.TabIndex = 9;
            this.btnR2.Text = "Remove TXT";
            this.btnR2.UseVisualStyleBackColor = false;
            this.btnR2.Click += new System.EventHandler(this.btnR2_Click);
            // 
            // btnCaricaNum
            // 
            this.btnCaricaNum.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCaricaNum.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaricaNum.Location = new System.Drawing.Point(106, 30);
            this.btnCaricaNum.Name = "btnCaricaNum";
            this.btnCaricaNum.Size = new System.Drawing.Size(89, 45);
            this.btnCaricaNum.TabIndex = 10;
            this.btnCaricaNum.Text = "Carica Numeri";
            this.btnCaricaNum.UseVisualStyleBackColor = false;
            this.btnCaricaNum.Click += new System.EventHandler(this.btnCaricaNum_Click);
            // 
            // btnDataS
            // 
            this.btnDataS.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDataS.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDataS.Location = new System.Drawing.Point(107, 82);
            this.btnDataS.Name = "btnDataS";
            this.btnDataS.Size = new System.Drawing.Size(89, 45);
            this.btnDataS.TabIndex = 11;
            this.btnDataS.Text = "Data Source";
            this.btnDataS.UseVisualStyleBackColor = false;
            this.btnDataS.Click += new System.EventHandler(this.btnDataS_Click);
            // 
            // btnRemFilosofo
            // 
            this.btnRemFilosofo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRemFilosofo.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemFilosofo.Location = new System.Drawing.Point(106, 133);
            this.btnRemFilosofo.Name = "btnRemFilosofo";
            this.btnRemFilosofo.Size = new System.Drawing.Size(89, 45);
            this.btnRemFilosofo.TabIndex = 12;
            this.btnRemFilosofo.Text = "Rimuovi Filosofo";
            this.btnRemFilosofo.UseVisualStyleBackColor = false;
            this.btnRemFilosofo.Click += new System.EventHandler(this.btnRemFilosofo_Click);
            // 
            // SelezElem
            // 
            this.SelezElem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.SelezElem.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelezElem.Location = new System.Drawing.Point(107, 184);
            this.SelezElem.Name = "SelezElem";
            this.SelezElem.Size = new System.Drawing.Size(89, 45);
            this.SelezElem.TabIndex = 13;
            this.SelezElem.Text = "Seleziona Elemento";
            this.SelezElem.UseVisualStyleBackColor = false;
            this.SelezElem.Click += new System.EventHandler(this.SelezElem_Click);
            // 
            // gbBottoni
            // 
            this.gbBottoni.Controls.Add(this.btnCaricaNum);
            this.gbBottoni.Controls.Add(this.SelezElem);
            this.gbBottoni.Controls.Add(this.button1);
            this.gbBottoni.Controls.Add(this.btnRemFilosofo);
            this.gbBottoni.Controls.Add(this.btnSelez);
            this.gbBottoni.Controls.Add(this.btnDataS);
            this.gbBottoni.Controls.Add(this.btnCarica);
            this.gbBottoni.Controls.Add(this.btnRemove);
            this.gbBottoni.Controls.Add(this.btnR2);
            this.gbBottoni.Location = new System.Drawing.Point(185, 30);
            this.gbBottoni.Name = "gbBottoni";
            this.gbBottoni.Size = new System.Drawing.Size(210, 316);
            this.gbBottoni.TabIndex = 14;
            this.gbBottoni.TabStop = false;
            this.gbBottoni.Text = "Lista";
            // 
            // gbListe
            // 
            this.gbListe.Controls.Add(this.btnCancella2);
            this.gbListe.Controls.Add(this.btnRimuoviTXT);
            this.gbListe.Controls.Add(this.btnRange);
            this.gbListe.Controls.Add(this.btnCancella);
            this.gbListe.Controls.Add(this.btnTrova);
            this.gbListe.Controls.Add(this.btnRemoveList);
            this.gbListe.Controls.Add(this.btnNele);
            this.gbListe.Controls.Add(this.btnCapacità);
            this.gbListe.Controls.Add(this.btnAddList);
            this.gbListe.Location = new System.Drawing.Point(401, 30);
            this.gbListe.Name = "gbListe";
            this.gbListe.Size = new System.Drawing.Size(222, 316);
            this.gbListe.TabIndex = 15;
            this.gbListe.TabStop = false;
            this.gbListe.Text = "Liste";
            // 
            // btnTrova
            // 
            this.btnTrova.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnTrova.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrova.Location = new System.Drawing.Point(6, 234);
            this.btnTrova.Name = "btnTrova";
            this.btnTrova.Size = new System.Drawing.Size(89, 45);
            this.btnTrova.TabIndex = 18;
            this.btnTrova.Text = "Trova";
            this.btnTrova.UseVisualStyleBackColor = false;
            // 
            // btnRemoveList
            // 
            this.btnRemoveList.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRemoveList.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveList.Location = new System.Drawing.Point(6, 183);
            this.btnRemoveList.Name = "btnRemoveList";
            this.btnRemoveList.Size = new System.Drawing.Size(89, 45);
            this.btnRemoveList.TabIndex = 17;
            this.btnRemoveList.Text = "Rimuovi";
            this.btnRemoveList.UseVisualStyleBackColor = false;
            this.btnRemoveList.Click += new System.EventHandler(this.btnRemoveList_Click);
            // 
            // btnNele
            // 
            this.btnNele.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnNele.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNele.Location = new System.Drawing.Point(6, 132);
            this.btnNele.Name = "btnNele";
            this.btnNele.Size = new System.Drawing.Size(89, 45);
            this.btnNele.TabIndex = 16;
            this.btnNele.Text = "N Elementi";
            this.btnNele.UseVisualStyleBackColor = false;
            this.btnNele.Click += new System.EventHandler(this.btnNele_Click);
            // 
            // btnCapacità
            // 
            this.btnCapacità.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCapacità.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCapacità.Location = new System.Drawing.Point(6, 81);
            this.btnCapacità.Name = "btnCapacità";
            this.btnCapacità.Size = new System.Drawing.Size(89, 45);
            this.btnCapacità.TabIndex = 15;
            this.btnCapacità.Text = "Capacità";
            this.btnCapacità.UseVisualStyleBackColor = false;
            this.btnCapacità.Click += new System.EventHandler(this.btnCapacità_Click);
            // 
            // btnAddList
            // 
            this.btnAddList.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddList.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddList.Location = new System.Drawing.Point(6, 30);
            this.btnAddList.Name = "btnAddList";
            this.btnAddList.Size = new System.Drawing.Size(89, 45);
            this.btnAddList.TabIndex = 14;
            this.btnAddList.Text = "Aggiungi";
            this.btnAddList.UseVisualStyleBackColor = false;
            this.btnAddList.Click += new System.EventHandler(this.btnAddList_Click);
            // 
            // lblCapacità
            // 
            this.lblCapacità.AutoSize = true;
            this.lblCapacità.Location = new System.Drawing.Point(641, 37);
            this.lblCapacità.Name = "lblCapacità";
            this.lblCapacità.Size = new System.Drawing.Size(52, 13);
            this.lblCapacità.TabIndex = 16;
            this.lblCapacità.Text = "Capacità:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(641, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Elementi:";
            // 
            // lblCap
            // 
            this.lblCap.AutoSize = true;
            this.lblCap.Location = new System.Drawing.Point(700, 37);
            this.lblCap.Name = "lblCap";
            this.lblCap.Size = new System.Drawing.Size(0, 13);
            this.lblCap.TabIndex = 18;
            // 
            // lblEl
            // 
            this.lblEl.AutoSize = true;
            this.lblEl.Location = new System.Drawing.Point(698, 72);
            this.lblEl.Name = "lblEl";
            this.lblEl.Size = new System.Drawing.Size(0, 13);
            this.lblEl.TabIndex = 19;
            // 
            // btnCancella
            // 
            this.btnCancella.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancella.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancella.Location = new System.Drawing.Point(101, 30);
            this.btnCancella.Name = "btnCancella";
            this.btnCancella.Size = new System.Drawing.Size(89, 45);
            this.btnCancella.TabIndex = 19;
            this.btnCancella.Text = "Cancella";
            this.btnCancella.UseVisualStyleBackColor = false;
            this.btnCancella.Click += new System.EventHandler(this.btnCancella_Click);
            // 
            // btnRange
            // 
            this.btnRange.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRange.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRange.Location = new System.Drawing.Point(101, 81);
            this.btnRange.Name = "btnRange";
            this.btnRange.Size = new System.Drawing.Size(89, 45);
            this.btnRange.TabIndex = 20;
            this.btnRange.Text = "Add Range";
            this.btnRange.UseVisualStyleBackColor = false;
            this.btnRange.Click += new System.EventHandler(this.btnRange_Click);
            // 
            // btnRimuoviTXT
            // 
            this.btnRimuoviTXT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRimuoviTXT.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRimuoviTXT.Location = new System.Drawing.Point(101, 133);
            this.btnRimuoviTXT.Name = "btnRimuoviTXT";
            this.btnRimuoviTXT.Size = new System.Drawing.Size(89, 45);
            this.btnRimuoviTXT.TabIndex = 21;
            this.btnRimuoviTXT.Text = "Rimuovi da TXT";
            this.btnRimuoviTXT.UseVisualStyleBackColor = false;
            this.btnRimuoviTXT.Click += new System.EventHandler(this.btnRimuoviTXT_Click);
            // 
            // btnCancella2
            // 
            this.btnCancella2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancella2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancella2.Location = new System.Drawing.Point(101, 183);
            this.btnCancella2.Name = "btnCancella2";
            this.btnCancella2.Size = new System.Drawing.Size(89, 45);
            this.btnCancella2.TabIndex = 22;
            this.btnCancella2.Text = "Cancella 2";
            this.btnCancella2.UseVisualStyleBackColor = false;
            this.btnCancella2.Click += new System.EventHandler(this.btnCancella2_Click);
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 442);
            this.Controls.Add(this.lblEl);
            this.Controls.Add(this.lblCap);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblCapacità);
            this.Controls.Add(this.gbListe);
            this.Controls.Add(this.gbBottoni);
            this.Controls.Add(this.lblSelez);
            this.Controls.Add(this.lblElementi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lista);
            this.Controls.Add(this.txtIns);
            this.Name = "form1";
            this.Text = "List Box";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbBottoni.ResumeLayout(false);
            this.gbListe.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIns;
        private System.Windows.Forms.ListBox lista;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblElementi;
        private System.Windows.Forms.Label lblSelez;
        private System.Windows.Forms.Button btnSelez;
        private System.Windows.Forms.Button btnCarica;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnR2;
        private System.Windows.Forms.Button btnCaricaNum;
        private System.Windows.Forms.Button btnDataS;
        private System.Windows.Forms.Button btnRemFilosofo;
        private System.Windows.Forms.Button SelezElem;
        private System.Windows.Forms.GroupBox gbBottoni;
        private System.Windows.Forms.GroupBox gbListe;
        private System.Windows.Forms.Button btnAddList;
        private System.Windows.Forms.Label lblCapacità;
        private System.Windows.Forms.Button btnNele;
        private System.Windows.Forms.Button btnCapacità;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCap;
        private System.Windows.Forms.Label lblEl;
        private System.Windows.Forms.Button btnRemoveList;
        private System.Windows.Forms.Button btnTrova;
        private System.Windows.Forms.Button btnCancella;
        private System.Windows.Forms.Button btnRange;
        private System.Windows.Forms.Button btnRimuoviTXT;
        private System.Windows.Forms.Button btnCancella2;
    }
}

