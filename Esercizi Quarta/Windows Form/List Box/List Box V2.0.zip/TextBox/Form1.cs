﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextBox
{
    public partial class form1 : Form
    {
        string[] filosofi = { "Socrate", "Aristotele", "Kant", "Nietche" };
        int[] numeri = { 2, 67, 54, 32, 6, 99, 44, 11, 28 };
        public form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtIns_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                lista.Items.Add(txtIns.Text);
                lista.SelectedIndex = 0;
                txtIns.Clear();
                lblElementi.Text = "Numero elementi: " + lista.Items.Count;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lista.Items.Clear();
            lblElementi.Text = "Numero elementi: " + lista.Items.Count;
            txtIns.Text = "";
            lblSelez.Text = "";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lista.SelectedIndex != -1 && lista.Items.Count!=0)
            {
                lblSelez.Text = "Elemento selezionato: " + lista.Items[lista.SelectedIndex].ToString();
            }
            else
            {
                lblSelez.Text = "Elemento selezionato: " + 0;
            }
        }

        private void btnSelez_Click(object sender, EventArgs e)
        {
            lista.Text = txtIns.Text;
        }

        private void btnCarica_Click(object sender, EventArgs e)
        {

            lista.Items.AddRange(filosofi);
            lblElementi.Text = "Numero elementi: " + lista.Items.Count;
            lista.SelectedIndex = 0;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (lista.Items.Count > 0)
            {
                lista.Items.RemoveAt(lista.SelectedIndex);
            }
            
            lblElementi.Text = "Numero elementi: " + lista.Items.Count;
            if (lista.Items.Count != 0)
            {
                lblElementi.Text = "Numero elementi: " + lista.Items.Count;
                lista.SelectedIndex = 0;
            }
        }

        private void btnR2_Click(object sender, EventArgs e)
        {
            if (lista.Items.IndexOf(txtIns.Text) == -1)
            {
                MessageBox.Show("Elemento non presente", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtIns.Text = string.Empty;
            }
            else
            {
                lista.Items.Remove(txtIns.Text);
                lblElementi.Text = "Numero elementi: " + lista.Items.Count;
                txtIns.Text = string.Empty;
            }
        }

        private void btnCaricaNum_Click(object sender, EventArgs e)
        {
            
            for (int i = 0; i < numeri.Length; i++)
            {
                lista.Items.Add(numeri[i]);
            }
            
            lblElementi.Text = "Numero elementi: " + lista.Items.Count;
            lista.SelectedIndex = 0;
        }

        private void btnDataS_Click(object sender, EventArgs e)
        {
            lista.DataSource = filosofi;
            lblElementi.Text = "Numero elementi: " + lista.Items.Count;
        }

        private void btnRemFilosofo_Click(object sender, EventArgs e)
        {
            if (lista.Items.IndexOf(txtIns.Text) == -1)
            {
                MessageBox.Show("Elemento non presente", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtIns.Text = string.Empty;
            }
            else
            {
                int indice = Array.FindIndex(filosofi, tmp => tmp == txtIns.Text);
                int j = 0;
                string[] array = new string[filosofi.Length - 1];

                for (int i = 0; i < filosofi.Length; i++)
                {
                    if (i != indice)
                    {
                        array[j++] = filosofi[i];

                    }
                }
                filosofi = array;
                lista.DataSource = filosofi;
                lblElementi.Text = "Numero elementi: " + lista.Items.Count;
                txtIns.Text = string.Empty;
            }
        }
    }
}
