﻿
namespace TextBox
{
    partial class form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIns = new System.Windows.Forms.TextBox();
            this.lista = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblElementi = new System.Windows.Forms.Label();
            this.lblSelez = new System.Windows.Forms.Label();
            this.btnSelez = new System.Windows.Forms.Button();
            this.btnCarica = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnR2 = new System.Windows.Forms.Button();
            this.btnCaricaNum = new System.Windows.Forms.Button();
            this.btnDataS = new System.Windows.Forms.Button();
            this.btnRemFilosofo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtIns
            // 
            this.txtIns.Location = new System.Drawing.Point(12, 30);
            this.txtIns.Name = "txtIns";
            this.txtIns.Size = new System.Drawing.Size(167, 20);
            this.txtIns.TabIndex = 0;
            this.txtIns.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIns_KeyPress);
            // 
            // lista
            // 
            this.lista.FormattingEnabled = true;
            this.lista.Location = new System.Drawing.Point(12, 56);
            this.lista.Name = "lista";
            this.lista.Size = new System.Drawing.Size(167, 290);
            this.lista.TabIndex = 1;
            this.lista.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Inserisci";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(195, 304);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 45);
            this.button1.TabIndex = 3;
            this.button1.Text = "Cancella";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblElementi
            // 
            this.lblElementi.AutoSize = true;
            this.lblElementi.Location = new System.Drawing.Point(192, 64);
            this.lblElementi.Name = "lblElementi";
            this.lblElementi.Size = new System.Drawing.Size(0, 13);
            this.lblElementi.TabIndex = 4;
            // 
            // lblSelez
            // 
            this.lblSelez.AutoSize = true;
            this.lblSelez.Location = new System.Drawing.Point(192, 30);
            this.lblSelez.Name = "lblSelez";
            this.lblSelez.Size = new System.Drawing.Size(0, 13);
            this.lblSelez.TabIndex = 5;
            // 
            // btnSelez
            // 
            this.btnSelez.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSelez.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelez.Location = new System.Drawing.Point(195, 253);
            this.btnSelez.Name = "btnSelez";
            this.btnSelez.Size = new System.Drawing.Size(89, 45);
            this.btnSelez.TabIndex = 6;
            this.btnSelez.Text = "Seleziona";
            this.btnSelez.UseVisualStyleBackColor = false;
            this.btnSelez.Click += new System.EventHandler(this.btnSelez_Click);
            // 
            // btnCarica
            // 
            this.btnCarica.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCarica.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCarica.Location = new System.Drawing.Point(195, 100);
            this.btnCarica.Name = "btnCarica";
            this.btnCarica.Size = new System.Drawing.Size(89, 45);
            this.btnCarica.TabIndex = 7;
            this.btnCarica.Text = "Carica Stringhe";
            this.btnCarica.UseVisualStyleBackColor = false;
            this.btnCarica.Click += new System.EventHandler(this.btnCarica_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRemove.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(195, 151);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(89, 45);
            this.btnRemove.TabIndex = 8;
            this.btnRemove.Text = "Rimuovi";
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnR2
            // 
            this.btnR2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnR2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnR2.Location = new System.Drawing.Point(195, 202);
            this.btnR2.Name = "btnR2";
            this.btnR2.Size = new System.Drawing.Size(89, 45);
            this.btnR2.TabIndex = 9;
            this.btnR2.Text = "Remove TXT";
            this.btnR2.UseVisualStyleBackColor = false;
            this.btnR2.Click += new System.EventHandler(this.btnR2_Click);
            // 
            // btnCaricaNum
            // 
            this.btnCaricaNum.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCaricaNum.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaricaNum.Location = new System.Drawing.Point(290, 100);
            this.btnCaricaNum.Name = "btnCaricaNum";
            this.btnCaricaNum.Size = new System.Drawing.Size(89, 45);
            this.btnCaricaNum.TabIndex = 10;
            this.btnCaricaNum.Text = "Carica Numeri";
            this.btnCaricaNum.UseVisualStyleBackColor = false;
            this.btnCaricaNum.Click += new System.EventHandler(this.btnCaricaNum_Click);
            // 
            // btnDataS
            // 
            this.btnDataS.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDataS.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDataS.Location = new System.Drawing.Point(290, 152);
            this.btnDataS.Name = "btnDataS";
            this.btnDataS.Size = new System.Drawing.Size(89, 45);
            this.btnDataS.TabIndex = 11;
            this.btnDataS.Text = "Data Source";
            this.btnDataS.UseVisualStyleBackColor = false;
            this.btnDataS.Click += new System.EventHandler(this.btnDataS_Click);
            // 
            // btnRemFilosofo
            // 
            this.btnRemFilosofo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRemFilosofo.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemFilosofo.Location = new System.Drawing.Point(289, 203);
            this.btnRemFilosofo.Name = "btnRemFilosofo";
            this.btnRemFilosofo.Size = new System.Drawing.Size(89, 45);
            this.btnRemFilosofo.TabIndex = 12;
            this.btnRemFilosofo.Text = "Rimuovi Filosofo";
            this.btnRemFilosofo.UseVisualStyleBackColor = false;
            this.btnRemFilosofo.Click += new System.EventHandler(this.btnRemFilosofo_Click);
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(390, 361);
            this.Controls.Add(this.btnRemFilosofo);
            this.Controls.Add(this.btnDataS);
            this.Controls.Add(this.btnCaricaNum);
            this.Controls.Add(this.btnR2);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnCarica);
            this.Controls.Add(this.btnSelez);
            this.Controls.Add(this.lblSelez);
            this.Controls.Add(this.lblElementi);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lista);
            this.Controls.Add(this.txtIns);
            this.Name = "form1";
            this.Text = "List Box";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIns;
        private System.Windows.Forms.ListBox lista;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblElementi;
        private System.Windows.Forms.Label lblSelez;
        private System.Windows.Forms.Button btnSelez;
        private System.Windows.Forms.Button btnCarica;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnR2;
        private System.Windows.Forms.Button btnCaricaNum;
        private System.Windows.Forms.Button btnDataS;
        private System.Windows.Forms.Button btnRemFilosofo;
    }
}

