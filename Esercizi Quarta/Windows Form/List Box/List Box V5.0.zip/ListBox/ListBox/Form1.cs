﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace listBox
{
    public partial class Form1 : Form
    {
        string[] filosofi = { "Socrate", "Aristotele", "Kant", "Nitche" };
        List<int> numeri = new List<int> { 1, 7, 12, 3, 9 };
        List<int> interi = new List<int>(3);
        List<int> interi2 = new List<int>(3);
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtIns_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                lista.Items.Add(txtIns.Text);
                lista.SelectedIndex = 0;
                txtIns.Clear();
                lblElementi.Text = "Numero elementi :" + lista.Items.Count;
            }


        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lista.Items.Clear();
            lblElementi.Text = "Numero elementi :" + lista.Items.Count;
            if (lista.SelectedIndex != -1)
                label2.Text = "Elemento selezionato: " + lista.Items[lista.SelectedIndex].ToString();
        }

        private void lista_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lista.SelectedIndex != -1 && lista.Items.Count != 0)
                label2.Text = "Elemento selezionato: " + lista.Items[lista.SelectedIndex].ToString();
            else
                label2.Text = "Elemento selezionato: " + 0;


        }

        private void btnSeleziona_Click(object sender, EventArgs e)
        {
            lista.Text = txtIns.Text;
        }

        private void btnCarica_Click(object sender, EventArgs e)
        {
            lista.Items.AddRange(filosofi);
            lblElementi.Text = "Numero elementi :" + lista.Items.Count;
            lista.SelectedIndex = 0;
        }

        private void btnRimuovi_Click(object sender, EventArgs e)
        {
            lista.Items.RemoveAt(lista.SelectedIndex);
            lblElementi.Text = "Numero elementi :" + lista.Items.Count;
            if (lista.Items.Count != 0)
            {
                lblElementi.Text = "Numero elementi :" + lista.Items.Count;
                lista.SelectedIndex = 0;
            }
        }

        private void btn_Remove_Txt_Click(object sender, EventArgs e)
        {
            if (lista.Items.IndexOf(txtIns.Text) == -1)
            {
                MessageBox.Show("Non è presente l'elemento nella lista", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                lista.Items.Remove(txtIns.Text);
            }
        }

        private void btn_interi_Click(object sender, EventArgs e)
        {
            int[] interi = { 4, 7, 9, 0 };
            foreach (int i in interi)
            {
                lista.Items.Add(i);
            }
            lblElementi.Text = "Numero elementi :" + lista.Items.Count;
            lista.SelectedIndex = 0;
        }

        private void btn_data_Click(object sender, EventArgs e)
        {
            lista.DataSource = filosofi;
        }

        private void btn_remove_data_Click(object sender, EventArgs e)
        {
            if (lista.Items.IndexOf(txtIns.Text) == -1)
            {
                MessageBox.Show("Non è presente l'elemento nella lista", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int indice = Array.FindIndex(filosofi, tmp => tmp == txtIns.Text);
                int j = 0;
                string[] array = new string[filosofi.Length - 1];
                for (int i = 0; i < filosofi.Length; i++)
                {
                    if (i != indice)
                    {
                        array[j++] = filosofi[i];
                    }
                }
                filosofi = array;
                lista.DataSource = filosofi;
            }
        }

        private void btnSelezionaElement_Click(object sender, EventArgs e)
        {
            txtIns.Text = lista.SelectedItem.ToString();


        }

        private void btnInserisci_Click(object sender, EventArgs e)
        {
            if (interi.Capacity > interi.Count)
            {
                interi.Add(int.Parse(txtIns.Text));
            }
            else
            {
                MessageBox.Show("Lista Piena", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            lista.DataSource = null;
            lista.DataSource = interi;
            txtIns.Text = "";
        }

        private void btnCapacità_Click(object sender, EventArgs e)
        {
            lblCapacità.Text = "Capacità: " + interi.Capacity.ToString();
        }

        private void btnElementi_Click(object sender, EventArgs e)
        {
            lblNElementi.Text = "N. Elementi: " + interi.Count.ToString();
        }

        private void btnCanc_Click(object sender, EventArgs e)
        {
            if (interi.Contains(Convert.ToInt32(lista.SelectedItem)))
            {
                interi.Remove(Convert.ToInt32(lista.SelectedItem));
            }
            lista.DataSource = null;
            lista.DataSource = interi;
        }

        private void btnTrova_Click(object sender, EventArgs e)
        {

        }

        private void btn_Cancella_Click(object sender, EventArgs e)
        {
            if (lista.SelectedIndex != -1)
            {
                interi.RemoveAt(lista.SelectedIndex);
                lista.DataSource = null;
                lista.DataSource = interi;
            }
            else
            {
                MessageBox.Show("Non hai selezionato alcun elemento");
            }
        }

        private void btn_AddRange_Click(object sender, EventArgs e)
        {
            interi.AddRange(numeri);
            lista.DataSource = null;
            lista.DataSource = interi;
        }

        private void btn_CancTb_Click(object sender, EventArgs e)
        {
            if (txtIns.Text != string.Empty)
            {
                int posizione;
                posizione = numeri.IndexOf(Convert.ToInt32(txtIns.Text));
                if (posizione != -1)
                {
                    numeri.RemoveAt(posizione);
                    lista.DataSource = null;
                    lista.DataSource = numeri;
                }
                else
                {
                    MessageBox.Show("Elemento non presente");
                }
            }
            else
            {
                MessageBox.Show("Non hai scritto alcun elemento");
            }
        }

        private void btn_Cancella2_Click(object sender, EventArgs e)
        {
            if (numeri.Contains(Convert.ToInt32(txtIns.Text)))
            {
                numeri.Remove(Convert.ToInt32(txtIns.Text));
                lista.DataSource = null;
                lista.DataSource = numeri;
            }
            else
            {
                MessageBox.Show("Non è presente l'elemento");
            }
        }

        private void btnTrovaTxt_Click(object sender, EventArgs e)
        {
            if (interi.IndexOf(Convert.ToInt32(txtIns.Text)) != -1)
            {
                lista.SelectedIndex = interi.IndexOf(Convert.ToInt32(txtIns.Text));
            }
            else
            {
                MessageBox.Show("Elemento non trovato");
            }

        }

        private void btntrova2_Click(object sender, EventArgs e)
        {
            if (interi.Contains(Convert.ToInt32(txtIns.Text)))
            {
                lista.Text = txtIns.Text;
            }
            else
            {
                MessageBox.Show("Elemento non trovato");
            }

        }

        private void BtnIns2_Click(object sender, EventArgs e)
        {
            int pos;
            pos = lista.SelectedIndex;
            interi.Insert(pos, Convert.ToInt32(txtIns.Text));
            lista.DataSource = null;
            lista.DataSource = interi;
        }

        private void btnraddoppia_Click(object sender, EventArgs e)
        {
            interi.Capacity = 2 * interi.Capacity;

        }

        private void btnCreaList_Click(object sender, EventArgs e)
        {
            interi2 = interi.FindAll(Predicato);
            lista.DataSource = null;
            lista.DataSource = interi2;
        }
        private bool Predicato(int valori)
        {
            return valori > Convert.ToInt32(txtIns.Text);
        }

        private void btnLamda_Click(object sender, EventArgs e)
        {
            interi2 = interi.FindAll(tmp=> tmp>Convert.ToInt32(txtIns.Text));
            lista.DataSource = null;
            lista.DataSource = interi2;
        }
    }
}
