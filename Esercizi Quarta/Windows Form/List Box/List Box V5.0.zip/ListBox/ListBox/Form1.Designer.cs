﻿
namespace listBox
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.lista = new System.Windows.Forms.ListBox();
            this.txtIns = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblElementi = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSeleziona = new System.Windows.Forms.Button();
            this.btnCarica = new System.Windows.Forms.Button();
            this.btnRimuovi = new System.Windows.Forms.Button();
            this.btn_Remove_Txt = new System.Windows.Forms.Button();
            this.btn_interi = new System.Windows.Forms.Button();
            this.btn_data = new System.Windows.Forms.Button();
            this.btn_remove_data = new System.Windows.Forms.Button();
            this.btnSelezionaElement = new System.Windows.Forms.Button();
            this.gpbLista = new System.Windows.Forms.GroupBox();
            this.gpbListe = new System.Windows.Forms.GroupBox();
            this.btnCreaList = new System.Windows.Forms.Button();
            this.btnraddoppia = new System.Windows.Forms.Button();
            this.BtnIns2 = new System.Windows.Forms.Button();
            this.btntrova2 = new System.Windows.Forms.Button();
            this.btnTrovaTxt = new System.Windows.Forms.Button();
            this.btn_Cancella2 = new System.Windows.Forms.Button();
            this.btn_CancTb = new System.Windows.Forms.Button();
            this.btn_AddRange = new System.Windows.Forms.Button();
            this.btn_Cancella = new System.Windows.Forms.Button();
            this.btnTrova = new System.Windows.Forms.Button();
            this.btnCanc = new System.Windows.Forms.Button();
            this.btnElementi = new System.Windows.Forms.Button();
            this.btnInserisci = new System.Windows.Forms.Button();
            this.btnCapacità = new System.Windows.Forms.Button();
            this.lblCapacità = new System.Windows.Forms.Label();
            this.lblNElementi = new System.Windows.Forms.Label();
            this.btnLamda = new System.Windows.Forms.Button();
            this.gpbLista.SuspendLayout();
            this.gpbListe.SuspendLayout();
            this.SuspendLayout();
            // 
            // lista
            // 
            this.lista.FormattingEnabled = true;
            this.lista.ItemHeight = 16;
            this.lista.Location = new System.Drawing.Point(21, 75);
            this.lista.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lista.Name = "lista";
            this.lista.Size = new System.Drawing.Size(120, 196);
            this.lista.TabIndex = 0;
            this.lista.SelectedIndexChanged += new System.EventHandler(this.lista_SelectedIndexChanged);
            // 
            // txtIns
            // 
            this.txtIns.Location = new System.Drawing.Point(21, 38);
            this.txtIns.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIns.Name = "txtIns";
            this.txtIns.Size = new System.Drawing.Size(120, 22);
            this.txtIns.TabIndex = 1;
            this.txtIns.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIns_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Inserisci :";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(17, 181);
            this.btnClear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(148, 23);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Cancella";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblElementi
            // 
            this.lblElementi.AutoSize = true;
            this.lblElementi.Location = new System.Drawing.Point(19, 274);
            this.lblElementi.Name = "lblElementi";
            this.lblElementi.Size = new System.Drawing.Size(123, 17);
            this.lblElementi.TabIndex = 4;
            this.lblElementi.Text = "Numero elementi :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 290);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Elemento selezionato :";
            // 
            // btnSeleziona
            // 
            this.btnSeleziona.Location = new System.Drawing.Point(17, 153);
            this.btnSeleziona.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSeleziona.Name = "btnSeleziona";
            this.btnSeleziona.Size = new System.Drawing.Size(148, 23);
            this.btnSeleziona.TabIndex = 6;
            this.btnSeleziona.Text = "Seleziona";
            this.btnSeleziona.UseVisualStyleBackColor = true;
            this.btnSeleziona.Click += new System.EventHandler(this.btnSeleziona_Click);
            // 
            // btnCarica
            // 
            this.btnCarica.Location = new System.Drawing.Point(17, 123);
            this.btnCarica.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCarica.Name = "btnCarica";
            this.btnCarica.Size = new System.Drawing.Size(148, 23);
            this.btnCarica.TabIndex = 7;
            this.btnCarica.Text = "Carica Filosofi";
            this.btnCarica.UseVisualStyleBackColor = true;
            this.btnCarica.Click += new System.EventHandler(this.btnCarica_Click);
            // 
            // btnRimuovi
            // 
            this.btnRimuovi.Location = new System.Drawing.Point(17, 94);
            this.btnRimuovi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRimuovi.Name = "btnRimuovi";
            this.btnRimuovi.Size = new System.Drawing.Size(148, 23);
            this.btnRimuovi.TabIndex = 8;
            this.btnRimuovi.Text = "Rimuovi";
            this.btnRimuovi.UseVisualStyleBackColor = true;
            this.btnRimuovi.Click += new System.EventHandler(this.btnRimuovi_Click);
            // 
            // btn_Remove_Txt
            // 
            this.btn_Remove_Txt.Location = new System.Drawing.Point(17, 65);
            this.btn_Remove_Txt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Remove_Txt.Name = "btn_Remove_Txt";
            this.btn_Remove_Txt.Size = new System.Drawing.Size(148, 23);
            this.btn_Remove_Txt.TabIndex = 9;
            this.btn_Remove_Txt.Text = "Rimuovi Testo";
            this.btn_Remove_Txt.UseVisualStyleBackColor = true;
            this.btn_Remove_Txt.Click += new System.EventHandler(this.btn_Remove_Txt_Click);
            // 
            // btn_interi
            // 
            this.btn_interi.Location = new System.Drawing.Point(17, 36);
            this.btn_interi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_interi.Name = "btn_interi";
            this.btn_interi.Size = new System.Drawing.Size(148, 23);
            this.btn_interi.TabIndex = 10;
            this.btn_interi.Text = "Inserisci type value";
            this.btn_interi.UseVisualStyleBackColor = true;
            this.btn_interi.Click += new System.EventHandler(this.btn_interi_Click);
            // 
            // btn_data
            // 
            this.btn_data.Location = new System.Drawing.Point(17, 210);
            this.btn_data.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_data.Name = "btn_data";
            this.btn_data.Size = new System.Drawing.Size(148, 23);
            this.btn_data.TabIndex = 11;
            this.btn_data.Text = "Data Source";
            this.btn_data.UseVisualStyleBackColor = true;
            this.btn_data.Click += new System.EventHandler(this.btn_data_Click);
            // 
            // btn_remove_data
            // 
            this.btn_remove_data.Location = new System.Drawing.Point(17, 240);
            this.btn_remove_data.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_remove_data.Name = "btn_remove_data";
            this.btn_remove_data.Size = new System.Drawing.Size(148, 23);
            this.btn_remove_data.TabIndex = 12;
            this.btn_remove_data.Text = "Rimuovi Filosofo";
            this.btn_remove_data.UseVisualStyleBackColor = true;
            this.btn_remove_data.Click += new System.EventHandler(this.btn_remove_data_Click);
            // 
            // btnSelezionaElement
            // 
            this.btnSelezionaElement.Location = new System.Drawing.Point(17, 270);
            this.btnSelezionaElement.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSelezionaElement.Name = "btnSelezionaElement";
            this.btnSelezionaElement.Size = new System.Drawing.Size(148, 23);
            this.btnSelezionaElement.TabIndex = 13;
            this.btnSelezionaElement.Text = "Seleziona Elemento";
            this.btnSelezionaElement.UseVisualStyleBackColor = true;
            this.btnSelezionaElement.Click += new System.EventHandler(this.btnSelezionaElement_Click);
            // 
            // gpbLista
            // 
            this.gpbLista.Controls.Add(this.btn_remove_data);
            this.gpbLista.Controls.Add(this.btnSelezionaElement);
            this.gpbLista.Controls.Add(this.btnClear);
            this.gpbLista.Controls.Add(this.btnSeleziona);
            this.gpbLista.Controls.Add(this.btn_data);
            this.gpbLista.Controls.Add(this.btnCarica);
            this.gpbLista.Controls.Add(this.btn_interi);
            this.gpbLista.Controls.Add(this.btnRimuovi);
            this.gpbLista.Controls.Add(this.btn_Remove_Txt);
            this.gpbLista.Location = new System.Drawing.Point(203, 15);
            this.gpbLista.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gpbLista.Name = "gpbLista";
            this.gpbLista.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gpbLista.Size = new System.Drawing.Size(243, 361);
            this.gpbLista.TabIndex = 14;
            this.gpbLista.TabStop = false;
            this.gpbLista.Text = "ListBox";
            // 
            // gpbListe
            // 
            this.gpbListe.Controls.Add(this.btnLamda);
            this.gpbListe.Controls.Add(this.btnCreaList);
            this.gpbListe.Controls.Add(this.btnraddoppia);
            this.gpbListe.Controls.Add(this.BtnIns2);
            this.gpbListe.Controls.Add(this.btntrova2);
            this.gpbListe.Controls.Add(this.btnTrovaTxt);
            this.gpbListe.Controls.Add(this.btn_Cancella2);
            this.gpbListe.Controls.Add(this.btn_CancTb);
            this.gpbListe.Controls.Add(this.btn_AddRange);
            this.gpbListe.Controls.Add(this.btn_Cancella);
            this.gpbListe.Controls.Add(this.btnTrova);
            this.gpbListe.Controls.Add(this.btnCanc);
            this.gpbListe.Controls.Add(this.btnElementi);
            this.gpbListe.Controls.Add(this.btnInserisci);
            this.gpbListe.Controls.Add(this.btnCapacità);
            this.gpbListe.Location = new System.Drawing.Point(545, 4);
            this.gpbListe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gpbListe.Name = "gpbListe";
            this.gpbListe.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gpbListe.Size = new System.Drawing.Size(355, 417);
            this.gpbListe.TabIndex = 15;
            this.gpbListe.TabStop = false;
            this.gpbListe.Text = "Liste";
            // 
            // btnCreaList
            // 
            this.btnCreaList.Location = new System.Drawing.Point(212, 60);
            this.btnCreaList.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCreaList.Name = "btnCreaList";
            this.btnCreaList.Size = new System.Drawing.Size(111, 28);
            this.btnCreaList.TabIndex = 25;
            this.btnCreaList.Text = "Find All";
            this.btnCreaList.UseVisualStyleBackColor = true;
            this.btnCreaList.Click += new System.EventHandler(this.btnCreaList_Click);
            // 
            // btnraddoppia
            // 
            this.btnraddoppia.Location = new System.Drawing.Point(212, 25);
            this.btnraddoppia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnraddoppia.Name = "btnraddoppia";
            this.btnraddoppia.Size = new System.Drawing.Size(111, 28);
            this.btnraddoppia.TabIndex = 24;
            this.btnraddoppia.Text = "Radoppia";
            this.btnraddoppia.UseVisualStyleBackColor = true;
            this.btnraddoppia.Click += new System.EventHandler(this.btnraddoppia_Click);
            // 
            // BtnIns2
            // 
            this.BtnIns2.Location = new System.Drawing.Point(8, 361);
            this.BtnIns2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnIns2.Name = "BtnIns2";
            this.BtnIns2.Size = new System.Drawing.Size(136, 28);
            this.BtnIns2.TabIndex = 23;
            this.BtnIns2.Text = "Inserimento 2";
            this.BtnIns2.UseVisualStyleBackColor = true;
            this.BtnIns2.Click += new System.EventHandler(this.BtnIns2_Click);
            // 
            // btntrova2
            // 
            this.btntrova2.Location = new System.Drawing.Point(8, 324);
            this.btntrova2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btntrova2.Name = "btntrova2";
            this.btntrova2.Size = new System.Drawing.Size(136, 28);
            this.btntrova2.TabIndex = 22;
            this.btntrova2.Text = "Trova 2";
            this.btntrova2.UseVisualStyleBackColor = true;
            this.btntrova2.Click += new System.EventHandler(this.btntrova2_Click);
            // 
            // btnTrovaTxt
            // 
            this.btnTrovaTxt.Location = new System.Drawing.Point(7, 288);
            this.btnTrovaTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTrovaTxt.Name = "btnTrovaTxt";
            this.btnTrovaTxt.Size = new System.Drawing.Size(137, 28);
            this.btnTrovaTxt.TabIndex = 14;
            this.btnTrovaTxt.Text = "Trova";
            this.btnTrovaTxt.UseVisualStyleBackColor = true;
            this.btnTrovaTxt.Click += new System.EventHandler(this.btnTrovaTxt_Click);
            // 
            // btn_Cancella2
            // 
            this.btn_Cancella2.Location = new System.Drawing.Point(7, 258);
            this.btn_Cancella2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Cancella2.Name = "btn_Cancella2";
            this.btn_Cancella2.Size = new System.Drawing.Size(137, 23);
            this.btn_Cancella2.TabIndex = 21;
            this.btn_Cancella2.Text = "Cancella 2";
            this.btn_Cancella2.UseVisualStyleBackColor = true;
            this.btn_Cancella2.Click += new System.EventHandler(this.btn_Cancella2_Click);
            // 
            // btn_CancTb
            // 
            this.btn_CancTb.Location = new System.Drawing.Point(7, 229);
            this.btn_CancTb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_CancTb.Name = "btn_CancTb";
            this.btn_CancTb.Size = new System.Drawing.Size(137, 23);
            this.btn_CancTb.TabIndex = 20;
            this.btn_CancTb.Text = "Cancella 1";
            this.btn_CancTb.UseVisualStyleBackColor = true;
            this.btn_CancTb.Click += new System.EventHandler(this.btn_CancTb_Click);
            // 
            // btn_AddRange
            // 
            this.btn_AddRange.Location = new System.Drawing.Point(7, 199);
            this.btn_AddRange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_AddRange.Name = "btn_AddRange";
            this.btn_AddRange.Size = new System.Drawing.Size(137, 23);
            this.btn_AddRange.TabIndex = 19;
            this.btn_AddRange.Text = "Addrange";
            this.btn_AddRange.UseVisualStyleBackColor = true;
            this.btn_AddRange.Click += new System.EventHandler(this.btn_AddRange_Click);
            // 
            // btn_Cancella
            // 
            this.btn_Cancella.Location = new System.Drawing.Point(7, 171);
            this.btn_Cancella.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Cancella.Name = "btn_Cancella";
            this.btn_Cancella.Size = new System.Drawing.Size(137, 23);
            this.btn_Cancella.TabIndex = 18;
            this.btn_Cancella.Text = "Cancella index";
            this.btn_Cancella.UseVisualStyleBackColor = true;
            this.btn_Cancella.Click += new System.EventHandler(this.btn_Cancella_Click);
            // 
            // btnTrova
            // 
            this.btnTrova.Location = new System.Drawing.Point(7, 142);
            this.btnTrova.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTrova.Name = "btnTrova";
            this.btnTrova.Size = new System.Drawing.Size(137, 23);
            this.btnTrova.TabIndex = 17;
            this.btnTrova.Text = "Trova";
            this.btnTrova.UseVisualStyleBackColor = true;
            this.btnTrova.Click += new System.EventHandler(this.btnTrova_Click);
            // 
            // btnCanc
            // 
            this.btnCanc.Location = new System.Drawing.Point(7, 113);
            this.btnCanc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCanc.Name = "btnCanc";
            this.btnCanc.Size = new System.Drawing.Size(137, 23);
            this.btnCanc.TabIndex = 16;
            this.btnCanc.Text = "Cancella";
            this.btnCanc.UseVisualStyleBackColor = true;
            this.btnCanc.Click += new System.EventHandler(this.btnCanc_Click);
            // 
            // btnElementi
            // 
            this.btnElementi.Location = new System.Drawing.Point(7, 84);
            this.btnElementi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnElementi.Name = "btnElementi";
            this.btnElementi.Size = new System.Drawing.Size(137, 23);
            this.btnElementi.TabIndex = 1;
            this.btnElementi.Text = "N. Elementi";
            this.btnElementi.UseVisualStyleBackColor = true;
            this.btnElementi.Click += new System.EventHandler(this.btnElementi_Click);
            // 
            // btnInserisci
            // 
            this.btnInserisci.Location = new System.Drawing.Point(7, 25);
            this.btnInserisci.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnInserisci.Name = "btnInserisci";
            this.btnInserisci.Size = new System.Drawing.Size(137, 23);
            this.btnInserisci.TabIndex = 0;
            this.btnInserisci.Text = "Inserisci";
            this.btnInserisci.UseVisualStyleBackColor = true;
            this.btnInserisci.Click += new System.EventHandler(this.btnInserisci_Click);
            // 
            // btnCapacità
            // 
            this.btnCapacità.Location = new System.Drawing.Point(7, 55);
            this.btnCapacità.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCapacità.Name = "btnCapacità";
            this.btnCapacità.Size = new System.Drawing.Size(137, 23);
            this.btnCapacità.TabIndex = 2;
            this.btnCapacità.Text = "Capacità";
            this.btnCapacità.UseVisualStyleBackColor = true;
            this.btnCapacità.Click += new System.EventHandler(this.btnCapacità_Click);
            // 
            // lblCapacità
            // 
            this.lblCapacità.AutoSize = true;
            this.lblCapacità.Location = new System.Drawing.Point(1020, 343);
            this.lblCapacità.Name = "lblCapacità";
            this.lblCapacità.Size = new System.Drawing.Size(63, 17);
            this.lblCapacità.TabIndex = 1;
            this.lblCapacità.Text = "Capacità";
            // 
            // lblNElementi
            // 
            this.lblNElementi.AutoSize = true;
            this.lblNElementi.Location = new System.Drawing.Point(1020, 359);
            this.lblNElementi.Name = "lblNElementi";
            this.lblNElementi.Size = new System.Drawing.Size(46, 17);
            this.lblNElementi.TabIndex = 2;
            this.lblNElementi.Text = "label4";
            // 
            // btnLamda
            // 
            this.btnLamda.Location = new System.Drawing.Point(212, 96);
            this.btnLamda.Margin = new System.Windows.Forms.Padding(4);
            this.btnLamda.Name = "btnLamda";
            this.btnLamda.Size = new System.Drawing.Size(111, 28);
            this.btnLamda.TabIndex = 26;
            this.btnLamda.Text = "find all =>";
            this.btnLamda.UseVisualStyleBackColor = true;
            this.btnLamda.Click += new System.EventHandler(this.btnLamda_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1108, 417);
            this.Controls.Add(this.lblCapacità);
            this.Controls.Add(this.lblNElementi);
            this.Controls.Add(this.gpbListe);
            this.Controls.Add(this.gpbLista);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblElementi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtIns);
            this.Controls.Add(this.lista);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "List box";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gpbLista.ResumeLayout(false);
            this.gpbListe.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lista;
        private System.Windows.Forms.TextBox txtIns;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblElementi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSeleziona;
        private System.Windows.Forms.Button btnCarica;
        private System.Windows.Forms.Button btnRimuovi;
        private System.Windows.Forms.Button btn_Remove_Txt;
        private System.Windows.Forms.Button btn_interi;
        private System.Windows.Forms.Button btn_data;
        private System.Windows.Forms.Button btn_remove_data;
        private System.Windows.Forms.Button btnSelezionaElement;
        private System.Windows.Forms.GroupBox gpbLista;
        private System.Windows.Forms.GroupBox gpbListe;
        private System.Windows.Forms.Button btnInserisci;
        private System.Windows.Forms.Label lblNElementi;
        private System.Windows.Forms.Label lblCapacità;
        private System.Windows.Forms.Button btnElementi;
        private System.Windows.Forms.Button btnCapacità;
        private System.Windows.Forms.Button btnCanc;
        private System.Windows.Forms.Button btnTrova;
        private System.Windows.Forms.Button btn_Cancella;
        private System.Windows.Forms.Button btn_AddRange;
        private System.Windows.Forms.Button btn_CancTb;
        private System.Windows.Forms.Button btn_Cancella2;
        private System.Windows.Forms.Button btnTrovaTxt;
        private System.Windows.Forms.Button btntrova2;
        private System.Windows.Forms.Button BtnIns2;
        private System.Windows.Forms.Button btnraddoppia;
        private System.Windows.Forms.Button btnCreaList;
        private System.Windows.Forms.Button btnLamda;
    }
}

