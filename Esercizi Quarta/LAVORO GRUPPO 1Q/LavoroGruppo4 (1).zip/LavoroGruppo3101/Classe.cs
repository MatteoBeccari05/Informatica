﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LavoroGruppo
{
    //mettere checkbox accanto a campi ByPassabili (guardare ByPassSet) sulle textbox
    public class Persona
    {
        private string nome;
        private string cognome;
        private int eta;
        private string nazionalita;
        private double peso;
        private int altezza;
        private string codicePassaporto;
        private MotivoVisita motivazione;
        private string descrizioneMotivazione;
        private bool stato;
        private System.Drawing.Bitmap img;

        public Persona(Persona p)
        {
            this.nome = p.nome;
            this.cognome = p.cognome;
            this.eta = p.eta;
            this.nazionalita = p.nazionalita;
            this.peso = p.peso;
            this.altezza = p.altezza;
            this.codicePassaporto = p.codicePassaporto;
            this.motivazione = p.motivazione;
            this.descrizioneMotivazione = p.descrizioneMotivazione;
            this.stato = p.stato;
            this.img = p.img;
        }
        public Persona(string nome, string cognome, int eta, string nazionalita, double peso, int altezza, string codicePassaporto, MotivoVisita motivazione, string descrizioneMotivazione, System.Drawing.Bitmap img, List<ByPassSet> bypassSet)
        {
            bool ByPassNome;
            bool ByPassCognome;
            bool ByPassEta;
            bool ByPassPeso;
            bool ByPassAltezza;



            SetByPass(out ByPassNome, out ByPassCognome, out ByPassEta, out ByPassPeso, out ByPassAltezza, bypassSet);

            if (ByPassNome == false)
            {
                switch (SetNome(nome))  //0 tutto ok, 1 stringa vuota, 2 nome troppo corto, 3 contiene numeri
                {
                    case 0: break;
                    case 1: throw new Exception("Nessun nome inserito"); break;
                    case 2: throw new Exception("Nome troppo corto"); break;
                    case 3: throw new Exception("Nome con numeri all'interno"); break;
                }
            }
            else
            {
                this.Nome = nome;
            }


            if (ByPassCognome == false)
            {
                switch (SetCognomeome(cognome)) //0 tutto ok, 1 stringa vuota, 2 nome troppo corto, 3 contiene numeri
                {
                    case 0: break;
                    case 1: throw new Exception("Nessun cognome inserito"); break;
                    case 2: throw new Exception("Cognome troppo corto"); break;
                    case 3: throw new Exception("Cognome con numeri all'interno"); break;
                }
            }
            else
            {
                this.Cognome = cognome;
            }

            if (ByPassEta == false)
            {
                switch (SetEta(eta))    //0 tutto ok, 1 eta' negativa, 2 eta' superiore o uguale a 123 (eta' max raggiunta al mondo)
                {
                    case 0: break;
                    case 1: throw new Exception("Eta' negativa"); break;
                    case 2: throw new Exception("Eta' troppo grande"); break;
                }
            }
            else
            {
                this.Eta = eta;
            }

            if (ByPassPeso == false)
            {
                switch (SetPeso(peso))  //0 tutto ok, 1 peso minore di 0,212kg, 2 peso maggiore di 635kg
                {
                    case 0: break;
                    case 1: throw new Exception("Peso troppo piccolo"); break;
                    case 2: throw new Exception("Peso troppo grande"); break;
                }
            }
            else
            {
                this.Peso = peso;
            }

            if (ByPassAltezza == false)
            {
                switch (SetAltezza(altezza))     //0 tutto ok, 1 altezza minore di 24cm, 2 altezza maggiore di 251cm
                {
                    case 0: break;
                    case 1: throw new Exception("Altezza troppo piccola"); break;
                    case 2: throw new Exception("Altezza troppo grande"); break;
                }
            }
            else
            {
                this.Altezza = altezza;
            }

            switch (SetCodicePassaporto(codicePassaporto))  //0 tutto ok, 1 errori
            {
                case 0: break;
                case 1: throw new Exception("Codice errato"); break;
            }

            switch (SetMotivoVisita(motivazione, descrizioneMotivazione))  //0 tutto ok, 1 motivaizone non specificata
            {
                case 0: break;
                case 1: throw new Exception("Motivazione non specificata"); break;
            }

            SetNazionalita(nazionalita);

            switch (SetImg(img))  //0 tutto ok, 1 immagine non presente
            {
                case 0: break;
                case 1: throw new Exception("Immagine non presente"); break;
            }

            this.Stato = false;


        }

        #region PROPRIETA'
        public string Nome
        {
            get
            {
                return nome;
            }
            private set
            {
                nome = value;
            }

        }

        public string Cognome
        {
            get
            {
                return cognome;
            }
            private set
            {
                cognome = value;
            }

        }

        public int Eta
        {
            get
            {
                return eta;
            }
            private set
            {
                eta = value;
            }

        }

        public string Nazionalita
        {
            get
            {
                return nazionalita;
            }
            private set
            {
                nazionalita = value;
            }
        }

        public double Peso
        {
            get
            {
                return peso;
            }
            private set
            {
                peso = value;
            }
        }

        public int Altezza
        {
            get
            {
                return altezza;
            }
            private set
            {
                altezza = value;
            }
        }

        public string CodicePassaporto
        {
            get
            {
                return codicePassaporto;
            }
            private set
            {
                codicePassaporto = value;
            }
        }

        public MotivoVisita Motivazione
        {
            get
            {
                return motivazione;
            }
            private set
            {
                motivazione = value;
            }
        }

        public string DescrizioneMotivazione
        {
            get
            {
                return descrizioneMotivazione;
            }
            private set
            {
                descrizioneMotivazione = value;
            }
        }

        public System.Drawing.Bitmap Img
        {
            get
            {
                return img;
            }

            private set
            {
                img = value;
            }
        }

        public bool Stato
        {
            get
            {
                return stato;
            }
            private set
            {
                stato = value;
            }
        }

        #endregion


        private int SetNome(string nome)       //metto private perche' cosi' facendo si ha una sicurezza maggiore nel maneggiare i dati
                                              //0 tutto ok, 1 stringa vuota, 2 nome troppo corto, 3 contiene numeri
        {
            int ritorno=TestNome(nome); 
            if (ritorno == 0)
            {
                this.Nome = nome;
            }
            return ritorno;


        }

        public static int TestNome(string nome)
        {
            int ritorno = 0, contaLettere = 0;
            if (nome == "")
            {
                ritorno = 1;
            }
            else
            {
                if (nome.Length < 3)
                {
                    ritorno = 2;
                }
                else
                {
                    for (int i = 0; ritorno == 0 && i < nome.Length; i++)
                    {
                        if (!(Convert.ToChar(nome.Substring(i, 1)) >= 'A' && Convert.ToChar(nome.Substring(i, 1)) <= 'Z' || Convert.ToChar(nome.Substring(i, 1)) >= 'a' && Convert.ToChar(nome.Substring(i, 1)) <= 'z'))
                        {
                            if (Convert.ToChar(nome.Substring(i, 1)) == ' ' && contaLettere >= 3)
                            {
                                contaLettere = 0;
                            }
                        }
                        else
                        {
                            contaLettere++;
                        }
                    }
                }
            }
            return ritorno;
        }

        private int SetCognomeome(string cognome)             //0 tutto ok, 1 stringa vuota, 2 nome troppo corto, 3 contiene numeri
        {
            int ritorno = TestCognome(cognome);
            if (ritorno == 0)
            {
                this.Cognome = cognome;
            }
            return ritorno;
        }

        public static int TestCognome(string cognome)
        {
            int ritorno = 0, contaLettere = 0;
            if (cognome == "")
            {
                ritorno = 1;
            }
            else
            {
                if (cognome.Length < 3)
                {
                    ritorno = 2;
                }
                else
                {
                    for (int i = 0; ritorno == 0 && i < cognome.Length; i++)
                    {
                        if (!(Convert.ToChar(cognome.Substring(i, 1)) >= 'A' && Convert.ToChar(cognome.Substring(i, 1)) <= 'Z' || Convert.ToChar(cognome.Substring(i, 1)) >= 'a' && Convert.ToChar(cognome.Substring(i, 1)) <= 'z'))
                        {
                            if (Convert.ToChar(cognome.Substring(i, 1)) == ' ' && contaLettere >= 3)
                            {
                                contaLettere = 0;
                            }
                        }
                        else
                        {
                            contaLettere++;
                        }
                    }
                }
            }
            return ritorno;
        }
        private int SetEta(int eta)    //0 tutto ok, 1 eta' negativa, 2 eta' superiore o uguale a 123 (eta' max raggiunta al mondo)
        {
            int ritorno = 0;

            if (eta < 0)
            {
                ritorno = 1;
            }
            else
            {
                if (eta >= 123)
                {
                    ritorno = 2;
                }
            }

            if (ritorno == 0)
            {
                this.Eta = eta;
            }

            return ritorno;
        }

        private void SetNazionalita(string nazionalita)
        {
            this.Nazionalita = nazionalita;
        }

        private int SetPeso(double peso)   //0 tutto ok, 1 peso minore di 0,212kg, 2 peso maggiore di 635kg
        {
            int ritorno = 0;
            if (peso < 0.212)
            {
                ritorno = 1;
            }
            else
            {
                if (peso > 635)
                {
                    ritorno = 2;
                }
            }

            if (ritorno == 0)
            {
                this.Peso = peso;
            }
            return ritorno;
        }

        private int SetAltezza(int altezza)    //0 tutto ok, 1 altezza minore di 24cm, 2 altezza maggiore di 251cm
        {
            int ritorno = 0;
            if (altezza < 24)
            {
                ritorno = 1;
            }
            else
            {
                if (altezza > 251)
                {
                    ritorno = 2;
                }
            }

            if (ritorno == 0)
            {
                this.Altezza = altezza;
            }
            return ritorno;
        }

        private int SetCodicePassaporto(string codicePassaporto)    //0 tutto ok, 1 errori
        {
            int ritorno = TestCodicePassaporto(codicePassaporto); //aggiunto toUpper
            if (ritorno == 0)
            {
                this.CodicePassaporto = codicePassaporto.ToUpper();
            }
            return ritorno;
        }

        public static int TestCodicePassaporto(string codicePassaporto)
        {
            int ritorno = 0;
            if (codicePassaporto.Length == 9)
            {
                for (int i = 0; i < 2; i++)
                {
                    if ((Convert.ToChar(codicePassaporto.ToUpper().Substring(i, 1)) >= 'A' && Convert.ToChar(codicePassaporto.ToUpper().Substring(i, 1)) <= 'Z') == false)
                    {
                        ritorno = 1;
                    }
                }

                for (int i = 2; ritorno == 0 && i < 9; i++)
                {
                    if ((Convert.ToChar(codicePassaporto.ToUpper().Substring(i, 1)) >= '0' && Convert.ToChar(codicePassaporto.ToUpper().Substring(i, 1)) <= '9') == false)
                    {
                        ritorno = 1;
                    }
                }
            }
            else
            {
                ritorno = 1;
            }

            return ritorno;
        }
        private int SetMotivoVisita(MotivoVisita motivazione, string descrizioneMotivazione)   //0 tutto ok, 1 motivaizone non specificata
        {
            int ritorno = 0;
            this.Motivazione = motivazione;

            if (motivazione == MotivoVisita.Altro)
            {
                if (descrizioneMotivazione != "")
                {
                    this.DescrizioneMotivazione = descrizioneMotivazione;
                }
                else
                {
                    ritorno = 1;
                }
            }

            return ritorno;
        }

        private int SetImg(System.Drawing.Bitmap img)   //0 tutto ok, 1 immagine non presente
        {
            int ritorno = 0;

            if (img != null)
            {
                this.Img = img;
            }
            else
            {
                ritorno = 1;
            }
            return ritorno;
        }

        private string StatoString()
        {
            if (this.Stato)
            {
                return "Approvato";
            }
            else
            {
                return "In fase di verifica";
            }
        }

        public override string ToString()
        {
            return string.Format($"Nome:{nome}   Cognome:{cognome}   Codice Passaporto:{codicePassaporto}   Approvato: {StatoString()}");
        }

        private void SetByPass(out bool nome, out bool cognome, out bool eta, out bool peso, out bool altezza, List<ByPassSet> array)
        {
            nome = false;
            cognome = false;
            eta = false;
            peso = false;
            altezza = false;

            if (array != null) //aggiunto
            {
                for (int i = 0; i < array.Count; i++)
                {
                    switch (array[i])
                    {
                        case ByPassSet.nome: nome = true; break;
                        case ByPassSet.cognome: cognome = true; break;
                        case ByPassSet.eta: eta = true; break;
                        case ByPassSet.peso: peso = true; break;
                        case ByPassSet.altezza: altezza = true; break;
                    }
                }
            }
        }

        public bool Approva()
        {
            if (this.stato == true)
            {
                return false;
            }
            else
            {
                this.stato = true;
                return true;
            }
        }
    }
}