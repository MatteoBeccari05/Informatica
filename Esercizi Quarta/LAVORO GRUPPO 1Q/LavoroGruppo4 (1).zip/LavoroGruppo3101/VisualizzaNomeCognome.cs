﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LavoroGruppo
{
    public partial class VisualizzaNomeCognome : Form
    {
        //simile al form principale, ma con la possibilità di visualizzare solo (si usa per gli omonimi)
        private List<Persona> lista; 
        private bool tema;
        private bool premium;
        public VisualizzaNomeCognome()
        {
            StartPosition = FormStartPosition.CenterScreen;
            MinimizeBox = false;
            MaximizeBox = false;
            InitializeComponent();
        }
        public VisualizzaNomeCognome(List<Persona> lista, bool tema,bool premium) : this()
        {
            this.lista = lista;
            this.tema = tema;
            this.premium = premium;
            listBox1.DataSource = null;
            listBox1.DataSource = lista;
            if (tema == true) //scegle tema chiaro/scruo
            {
                Scuro();
            }
            else
            {
                Chiaro();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex>=0)
            {
                bool modifica = false; //visualizzo il selezionato se premo visualizza
                Modale md = new Modale(lista[listBox1.SelectedIndex], tema,modifica,premium);
                md.ShowDialog();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex>=0) //visualizzo l'immagine
            {
                pictureBox1.Image = lista[listBox1.SelectedIndex].Img;
            }
        }
        public void Chiaro()
        {
            this.BackColor = Color.White;
            listBox1.BackColor = Color.White;
        }
        public void Scuro()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            listBox1.BackColor = Color.Gray;
        }

        private void VisualizzaNomeCognome_Load(object sender, EventArgs e)
        {

        }
    }

}
