﻿namespace LavoroGruppo
{
    public enum Nazionalita
    {
        italiana,
        tedesca,
        giapponese,
        americana,
        russa
    }
}