﻿namespace LavoroGruppo
{
    public enum ByPassSet      
    {
        nome,
        cognome,
        eta,
        peso,
        altezza
    }
}