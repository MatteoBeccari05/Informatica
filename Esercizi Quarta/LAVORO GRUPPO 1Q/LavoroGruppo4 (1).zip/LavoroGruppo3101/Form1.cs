﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LavoroGruppo
{
    public partial class Form1 : Form
    {
        Modale fm;
        Premium pfm;
        Ricerca rfm;
        Avvio schermata;
        List<Persona> registro;
        private bool premium;
        private bool tema;
        public Form1()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            Avvio();
            registro = new List<Persona>();
            premium = false;
            AbilitaToolStrip();
            AggiornaLBL();
            tema = false;
            MaximizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void inserisciToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void chiudiToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void visualizzaToolStripMenuItem1_Click(object sender, EventArgs e)
        {


        }

        private void attivaTemaScuroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Scuro();
        }

        private void disattivaTemaScuroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Chiaro();

        }

        public void Scuro()
        {
            tema = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            lista.BackColor = Color.Gray;
            menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            pictureBoxMain.BackColor = Color.Gray;
            label3.ForeColor = Color.White;
            label2.ForeColor = Color.White;
            menuStrip1.ForeColor = Color.White;
            lblVersione.ForeColor = Color.White;

        }

        public void Chiaro()
        {
            tema = false;
            this.BackColor = Color.White;
            lista.BackColor = Color.White;
            menuStrip1.BackColor = Color.White;
            pictureBoxMain.BackColor = Color.White;
            label3.ForeColor = Color.Black;
            label2.ForeColor = Color.Black;
            menuStrip1.ForeColor = Color.Black;
            lblVersione.ForeColor = Color.Black;
        }

        private bool Presente(Persona p)
        {
            for (int i = 0; i < registro.Count; i++)
            {
                if (p.CodicePassaporto == registro[i].CodicePassaporto)
                {
                    return true;
                }
            }
            return false;
        }


        private void inserimentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fm = new Modale(premium, tema);
            DialogResult risultato = fm.ShowDialog();
            if (risultato == DialogResult.OK)
            {
                if (!Presente(fm.p))
                {
                    registro.Add(fm.p);
                    lista.DataSource = null;
                    lista.DataSource = registro;
                    AbilitaToolStrip();
                    MessageBox.Show("Inserimento avvenuto con successo");
                }
                else
                {
                    MessageBox.Show("Passaporto gia' presente");
                }

            }
        }

        private void visualizzaToolStripMenuItem_Click(object sender, EventArgs e) //Visualizza con modale il componente selezionato (Ricerca-selezionato)
        {
            if (lista.SelectedIndex != -1)
            {
                bool modifica = false;
                fm = new Modale(registro[lista.SelectedIndex], tema,modifica,premium); //deve visualizzare e non modificare
                fm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Nessuna persona presente");
            }
        }

        private void premiumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            pfm = new Premium(premium, tema);
            pfm.ShowDialog();
            premium = pfm.premium;
            AggiornaLBL();
            
        }

        private void ricercaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void modificaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lista.SelectedIndex != -1)
            {
                if (registro[lista.SelectedIndex].Approva() == true)
                {
                    MessageBox.Show("Persona approvata");
                    lista.DataSource = null;
                    lista.DataSource = registro;
                }
                else
                {
                    MessageBox.Show("Non e' stato possibile approvare la persona perche' risulta gia' approvata");
                }
            }
            else
            {
                MessageBox.Show("Impossibile modificare una persona non inserita");
            }
        }

        private void eliminaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lista.SelectedIndex != -1)
            {
                if (MessageBox.Show($"Vuoi davvero eliminare {registro[lista.SelectedIndex].Nome} {registro[lista.SelectedIndex].Cognome}?", "Eliminazione", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    registro.RemoveAt(lista.SelectedIndex);
                    lista.DataSource = null;
                    lista.DataSource = registro;
                    AbilitaToolStrip();
                }
                else
                {
                    MessageBox.Show("Persona non eliminata");
                }
            }
            else
            {
                MessageBox.Show("Impossibile eliminare una persona non inserita");
            }
        }

        private void modificaToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void chiudiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lista_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lista.SelectedIndex >= 0)
            {
                pictureBoxMain.Image = registro[lista.SelectedIndex].Img;
                pictureBoxMain.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
            {
                pictureBoxMain.Image = null;
            }
        }

        private void AggiornaLBL()
        {
            if (premium == true)
            {
                lblVersione.Text = "Versione: Premium";
            }
            else
            {
                lblVersione.Text = "Versione: Base";
            }
        }

        private void modificaToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {

        }

        private void nomeCognomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<Persona> lista = new List<Persona>(); //lista di persone con nome e cognome (gestione omonimi)
            bool opzione = true; //ricerca nome-cognome
            rfm = new Ricerca(opzione,tema,premium); //scelgo nome e cognome con il form di inserimento (rierca)
            rfm.ShowDialog();
            if (rfm.DialogResult == DialogResult.OK)
            {
                string nome = rfm.parametro1;
                string cognome = rfm.parametro2; //prendo nome e cognome
                for (int i = 0; i < registro.Count; i++)
                {
                    if (registro[i].Nome.ToUpper() == nome.ToUpper() && registro[i].Cognome.ToUpper() == cognome.ToUpper())
                    {
                        lista.Add(registro[i]); //aggiungo alla lista i componenti con stesso nome e cognome
                    }
                }
                if (lista.Count > 0) //se ho trovato qualcuno 
                {
                    VisualizzaNomeCognome fvnc = new VisualizzaNomeCognome(lista, tema,premium); //visualizzo gli omonimi
                    fvnc.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Non sono state trovate persone con nome e cognome");
                }
            }
        }

        private void codicePassaportoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool opzione = false; //ricerca codice passaporto
            rfm = new Ricerca(opzione,tema,premium);
            rfm.ShowDialog();
            if (rfm.DialogResult == DialogResult.OK)
            {
                string codiceP = rfm.parametro1; //prendo il codcie passaporto
                int trovato = -1; //se non trovo nessuno (codice passaporto è univoco) rimane a -1
                for (int i = 0; i < registro.Count && trovato == -1; i++)
                {
                    if (registro[i].CodicePassaporto.ToUpper() == codiceP.ToUpper())
                    {
                        trovato = i;
                    }
                }
                if (trovato != -1) //se lo trvo lo visualizzo con modale
                {
                    bool modifica = false;
                    fm = new Modale(registro[trovato], tema, modifica,premium);
                    fm.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Codice Passaporto Non Presente");
                }
            }
        }

        private void codicePassaportoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            bool opzione = false; //ricerca codice passaporto
            rfm = new Ricerca(opzione,tema,premium);
            rfm.ShowDialog();
            if (rfm.DialogResult == DialogResult.OK)
            {
                string codiceP = rfm.parametro1;
                int trovato = -1;
                for (int i = 0; i < registro.Count && trovato == -1; i++)
                {
                    if (registro[i].CodicePassaporto.ToUpper() == codiceP.ToUpper())
                    {
                        trovato = i;
                    }
                }
                if (trovato != -1) //come con la ricerca, però ora modifico anzichè visualizzare
                {
                    bool modifica = true;
                    fm = new Modale(registro[trovato], tema,modifica,premium);
                    fm.ShowDialog();
                    if(fm.DialogResult==DialogResult.OK) //se la modifica è andata a buon fine, è come un inserimento nella posizione specifica di dove si trovava l'altro elemento che si vuole modificare
                        //quindi un inserimento nella lista in una posizione precisa e non una semplice add, ma una sovrascrittura
                    {
                        registro[trovato] = fm.p;//sovrascrivo e non inserisco con add
                        MessageBox.Show("Modifica avvenuta correttamente");
                        lista.DataSource = null; //aggiorno la lista
                        lista.DataSource = registro;
                    }
                }
                else
                {
                    MessageBox.Show("Codice Passaporto Non Presente");
                }
            }
        }

        private void selezionatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(lista.SelectedIndex>=0)
            {
                bool modifica = true;
                fm = new Modale(registro[lista.SelectedIndex], tema, modifica,premium);//modifico il selezionato senza ricercarlo per nome e cognome
                fm.ShowDialog();
                if (fm.DialogResult == DialogResult.OK)
                {
                    registro[lista.SelectedIndex] = fm.p;
                    MessageBox.Show("Modifica avvenuta correttamente");
                    lista.DataSource = null; //aggiorno la lista
                    lista.DataSource = registro;
                }
            }
        }

        private void AbilitaToolStrip()
        {
            if (registro.Count > 0)
            {
                visualizzaToolStripMenuItem.Enabled = true;
                modificaToolStripMenuItem.Enabled = true;
                eliminaToolStripMenuItem.Enabled = true;
                modificaToolStripMenuItem1.Enabled = true;
                modificaToolStripMenuItem2.Enabled = true;
            }
            else
            {
                visualizzaToolStripMenuItem.Enabled=false;
                modificaToolStripMenuItem.Enabled=false;
                eliminaToolStripMenuItem.Enabled=false;
                modificaToolStripMenuItem1.Enabled=false;
                modificaToolStripMenuItem2.Enabled=false;
            }
        }

        private void Avvio()
        {
            schermata = new Avvio();
            schermata.ShowDialog();
        }

        private void riconoscimentiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Riconoscimenti r1 = new Riconoscimenti();
            r1.ShowDialog();
        }
    }
}


