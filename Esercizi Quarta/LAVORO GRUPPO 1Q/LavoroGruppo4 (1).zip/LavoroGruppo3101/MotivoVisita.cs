﻿namespace LavoroGruppo
{
    public enum MotivoVisita
    {
        Lavoro,
        Salute,
        Turismo,
        Visita,
        Transito,
        Immigrazione,
        Altro
    }
}