﻿namespace LavoroGruppo
{
    public enum Stato
    {
        accettata,
        rifiutata,
        verifica
    }
}