﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LavoroGruppo
{
    public partial class Premium : Form
    {
        string chiave = "RT9231K0";
        public bool premium;
        public Premium()
        {
            InitializeComponent();
            MinimizeBox = false;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
        }

        public Premium(bool stato, bool tema):this()
        {
            premium = stato;
            if (tema == true)
            {
                Scuro();
            }
            else
            {
                Chiaro();
            }
        }

        public void Scuro()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            label1.ForeColor = Color.White;

        }

        public void Chiaro()
        {
            this.BackColor = Color.White;
            label1.ForeColor = Color.Black;
        }

        private void Premium_Load(object sender, EventArgs e)
        {

        }
        private int Controllokey()   //0 tutto ok, 1 chiave inserita troppo corta, 2 chiave diversa da quella rilasciata
        {
            int ritorno = 0;
            if (txtPremium.TextLength < 8)
            {
                ritorno = 1;
            }
            else
            {
                if (txtPremium.Text != chiave)
                {
                    ritorno = 2;
                }
            }
            return ritorno;
        }

        
        public void Risposta()
        {
            int ritorno = Controllokey();
            if (ritorno == 1)
            {
                MessageBox.Show("Chiave troppo corta");
            }
            else if (ritorno == 2)
            {
                MessageBox.Show("Chiave incorretta");
            }
            else if (ritorno == 0)
            {
                MessageBox.Show("Premium attivato correttamente");
                premium = true;
                Close();
                
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (premium == true)
            {
                MessageBox.Show("Premium gia' attivo");
            }
            else
            {
                Risposta();
            }
            
        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
