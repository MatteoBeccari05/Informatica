﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LavoroGruppo
{
    public partial class Ricerca : Form
    {
        public string parametro1, parametro2;   //parametro1 contiene o nome o codice passaporto parametro2 solo cognome
        private bool opzione;   //==true nome e cognome ==false codice passaporto
        public Ricerca()
        {
            InitializeComponent();
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterScreen;
            MinimizeBox = false;
            MaximizeBox = false;
        }

        public Ricerca(bool opzione,bool tema,bool premium):this() //premiumo per vedere o meno le checkbox come su modale
        {
            if (opzione == true)
            {
                textBox3.Visible = false;
                label3.Visible = false;
                if(premium==false)
                {
                    checkBox1.Visible = false;
                    checkBox2.Visible = false;
                }
            }
            else
            {
                textBox1.Visible = false;
                label1.Visible = false;
                textBox2.Visible = false;
                label2.Visible = false;
                checkBox1.Visible = false;
                checkBox2.Visible = false;
            }
            this.opzione = opzione;
            if (tema == true) //scegle il colore del tema DA COMPLETARE
            {
                Scuro();
            }
            else
            {
                Chiaro();
            }
        }

        private void btnAnnulla_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void btnCerca_Click(object sender, EventArgs e)
        {
            
            if(opzione == true)
            {
                bool errore=false;
                if(checkBox1.Checked == true)
                {
                    this.parametro1 = textBox1.Text;
                }
                else if(checkBox1.Checked == false)
                {
                    if (Persona.TestNome(textBox1.Text) == 0)
                    {
                        this.parametro1 = textBox1.Text;
                    }
                    else
                    {
                        MessageBox.Show("Errore, nome non acccettato");
                        errore=true;
                    }
                }
                if(checkBox2.Checked == true)
                {
                    this.parametro2 = textBox2.Text;
                }
                else if (checkBox2.Checked == false)
                {
                    if (Persona.TestCognome(textBox2.Text) == 0)
                    {
                        this.parametro2 = textBox2.Text;
                    }
                    else
                    {
                        MessageBox.Show("Errore, cognome non acccettato");
                        errore = true;
                    }
                }
                if (errore == false)
                {
                    DialogResult = DialogResult.OK;
                    Close();
                }
            }
            else
            {
                if (Persona.TestCodicePassaporto(textBox3.Text) == 0)
                {
                    this.parametro1=textBox3.Text;
                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    MessageBox.Show("Errore, codice passaporto non acccettato");
                }
            }
        }

        public void Chiaro()
        {
            this.BackColor = Color.White;
            label1.ForeColor = Color.Black;
            label2.ForeColor = Color.Black;
            label3.ForeColor = Color.Black;
        }
        public void Scuro()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            label1.ForeColor = Color.White;
            label2.ForeColor = Color.White;
            label3.ForeColor = Color.White;
        }

        private void Ricerca_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
