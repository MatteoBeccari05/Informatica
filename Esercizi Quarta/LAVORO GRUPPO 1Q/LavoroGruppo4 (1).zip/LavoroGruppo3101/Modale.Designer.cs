﻿
namespace LavoroGruppo
{
    partial class Modale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Modale));
            this.gbInformazioni = new System.Windows.Forms.GroupBox();
            this.checkAltezza = new System.Windows.Forms.CheckBox();
            this.checkPeso = new System.Windows.Forms.CheckBox();
            this.checkEta = new System.Windows.Forms.CheckBox();
            this.checkCognome = new System.Windows.Forms.CheckBox();
            this.checkNome = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEtà = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAltezza = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCognome = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDescrizione = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNazionalita = new System.Windows.Forms.TextBox();
            this.gbAltroInf = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCodice = new System.Windows.Forms.TextBox();
            this.pictureBoxModale = new System.Windows.Forms.PictureBox();
            this.btnAnnulla = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.gbMotivo = new System.Windows.Forms.GroupBox();
            this.rbTurismo = new System.Windows.Forms.RadioButton();
            this.rbAltro = new System.Windows.Forms.RadioButton();
            this.rbImmigrazione = new System.Windows.Forms.RadioButton();
            this.rbVisita = new System.Windows.Forms.RadioButton();
            this.rbTransito = new System.Windows.Forms.RadioButton();
            this.rbSalute = new System.Windows.Forms.RadioButton();
            this.rbLavoro = new System.Windows.Forms.RadioButton();
            this.lblImg = new System.Windows.Forms.Label();
            this.gbInformazioni.SuspendLayout();
            this.gbAltroInf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxModale)).BeginInit();
            this.gbMotivo.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbInformazioni
            // 
            this.gbInformazioni.Controls.Add(this.checkAltezza);
            this.gbInformazioni.Controls.Add(this.checkPeso);
            this.gbInformazioni.Controls.Add(this.checkEta);
            this.gbInformazioni.Controls.Add(this.checkCognome);
            this.gbInformazioni.Controls.Add(this.checkNome);
            this.gbInformazioni.Controls.Add(this.label5);
            this.gbInformazioni.Controls.Add(this.txtEtà);
            this.gbInformazioni.Controls.Add(this.label6);
            this.gbInformazioni.Controls.Add(this.txtAltezza);
            this.gbInformazioni.Controls.Add(this.label7);
            this.gbInformazioni.Controls.Add(this.txtPeso);
            this.gbInformazioni.Controls.Add(this.label2);
            this.gbInformazioni.Controls.Add(this.txtCognome);
            this.gbInformazioni.Controls.Add(this.txtNome);
            this.gbInformazioni.Controls.Add(this.label1);
            this.gbInformazioni.Location = new System.Drawing.Point(12, 12);
            this.gbInformazioni.Name = "gbInformazioni";
            this.gbInformazioni.Size = new System.Drawing.Size(202, 378);
            this.gbInformazioni.TabIndex = 0;
            this.gbInformazioni.TabStop = false;
            this.gbInformazioni.Text = "Informazioni principali";
            // 
            // checkAltezza
            // 
            this.checkAltezza.AutoSize = true;
            this.checkAltezza.Location = new System.Drawing.Point(146, 251);
            this.checkAltezza.Name = "checkAltezza";
            this.checkAltezza.Size = new System.Drawing.Size(15, 14);
            this.checkAltezza.TabIndex = 16;
            this.checkAltezza.UseVisualStyleBackColor = true;
            // 
            // checkPeso
            // 
            this.checkPeso.AutoSize = true;
            this.checkPeso.Location = new System.Drawing.Point(146, 198);
            this.checkPeso.Name = "checkPeso";
            this.checkPeso.Size = new System.Drawing.Size(15, 14);
            this.checkPeso.TabIndex = 15;
            this.checkPeso.UseVisualStyleBackColor = true;
            // 
            // checkEta
            // 
            this.checkEta.AutoSize = true;
            this.checkEta.Location = new System.Drawing.Point(146, 145);
            this.checkEta.Name = "checkEta";
            this.checkEta.Size = new System.Drawing.Size(15, 14);
            this.checkEta.TabIndex = 14;
            this.checkEta.UseVisualStyleBackColor = true;
            // 
            // checkCognome
            // 
            this.checkCognome.AutoSize = true;
            this.checkCognome.Location = new System.Drawing.Point(147, 96);
            this.checkCognome.Name = "checkCognome";
            this.checkCognome.Size = new System.Drawing.Size(15, 14);
            this.checkCognome.TabIndex = 13;
            this.checkCognome.UseVisualStyleBackColor = true;
            // 
            // checkNome
            // 
            this.checkNome.AutoSize = true;
            this.checkNome.Location = new System.Drawing.Point(148, 47);
            this.checkNome.Name = "checkNome";
            this.checkNome.Size = new System.Drawing.Size(15, 14);
            this.checkNome.TabIndex = 12;
            this.checkNome.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Età (max 123)";
            // 
            // txtEtà
            // 
            this.txtEtà.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEtà.Location = new System.Drawing.Point(9, 145);
            this.txtEtà.Name = "txtEtà";
            this.txtEtà.Size = new System.Drawing.Size(132, 20);
            this.txtEtà.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 233);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Altezza (da 24 a 251 cm))";
            // 
            // txtAltezza
            // 
            this.txtAltezza.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAltezza.Location = new System.Drawing.Point(9, 249);
            this.txtAltezza.Name = "txtAltezza";
            this.txtAltezza.Size = new System.Drawing.Size(132, 20);
            this.txtAltezza.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Peso (min 0.212 a 635 kg)";
            // 
            // txtPeso
            // 
            this.txtPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPeso.Location = new System.Drawing.Point(9, 198);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(132, 20);
            this.txtPeso.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Cognome (min. 3 caratteri)";
            // 
            // txtCognome
            // 
            this.txtCognome.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCognome.Location = new System.Drawing.Point(9, 94);
            this.txtCognome.Name = "txtCognome";
            this.txtCognome.Size = new System.Drawing.Size(132, 20);
            this.txtCognome.TabIndex = 2;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(9, 43);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(132, 20);
            this.txtNome.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome (min. 3 caratteri)";
            // 
            // txtDescrizione
            // 
            this.txtDescrizione.Location = new System.Drawing.Point(22, 188);
            this.txtDescrizione.Multiline = true;
            this.txtDescrizione.Name = "txtDescrizione";
            this.txtDescrizione.Size = new System.Drawing.Size(150, 46);
            this.txtDescrizione.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Nazionalità";
            // 
            // txtNazionalita
            // 
            this.txtNazionalita.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNazionalita.Location = new System.Drawing.Point(6, 91);
            this.txtNazionalita.Name = "txtNazionalita";
            this.txtNazionalita.Size = new System.Drawing.Size(132, 20);
            this.txtNazionalita.TabIndex = 4;
            // 
            // gbAltroInf
            // 
            this.gbAltroInf.Controls.Add(this.label4);
            this.gbAltroInf.Controls.Add(this.txtCodice);
            this.gbAltroInf.Controls.Add(this.label3);
            this.gbAltroInf.Controls.Add(this.txtNazionalita);
            this.gbAltroInf.Location = new System.Drawing.Point(220, 12);
            this.gbAltroInf.Name = "gbAltroInf";
            this.gbAltroInf.Size = new System.Drawing.Size(211, 122);
            this.gbAltroInf.TabIndex = 1;
            this.gbAltroInf.TabStop = false;
            this.gbAltroInf.Text = "Altre informazioni";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(194, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Codice passaporto (2 lettere e 7 numeri)";
            // 
            // txtCodice
            // 
            this.txtCodice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodice.Location = new System.Drawing.Point(6, 45);
            this.txtCodice.Name = "txtCodice";
            this.txtCodice.Size = new System.Drawing.Size(132, 20);
            this.txtCodice.TabIndex = 6;
            // 
            // pictureBoxModale
            // 
            this.pictureBoxModale.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBoxModale.Location = new System.Drawing.Point(447, 18);
            this.pictureBoxModale.Name = "pictureBoxModale";
            this.pictureBoxModale.Size = new System.Drawing.Size(180, 226);
            this.pictureBoxModale.TabIndex = 2;
            this.pictureBoxModale.TabStop = false;
            this.pictureBoxModale.Click += new System.EventHandler(this.pictureBoxModale_Click);
            // 
            // btnAnnulla
            // 
            this.btnAnnulla.Location = new System.Drawing.Point(447, 283);
            this.btnAnnulla.Name = "btnAnnulla";
            this.btnAnnulla.Size = new System.Drawing.Size(79, 42);
            this.btnAnnulla.TabIndex = 4;
            this.btnAnnulla.Text = "Annulla";
            this.btnAnnulla.UseVisualStyleBackColor = true;
            this.btnAnnulla.Click += new System.EventHandler(this.btnAnnulla_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(548, 283);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(79, 42);
            this.btnOK.TabIndex = 5;
            this.btnOK.Text = "Conferma";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // gbMotivo
            // 
            this.gbMotivo.Controls.Add(this.rbTurismo);
            this.gbMotivo.Controls.Add(this.rbAltro);
            this.gbMotivo.Controls.Add(this.txtDescrizione);
            this.gbMotivo.Controls.Add(this.rbImmigrazione);
            this.gbMotivo.Controls.Add(this.rbVisita);
            this.gbMotivo.Controls.Add(this.rbTransito);
            this.gbMotivo.Controls.Add(this.rbSalute);
            this.gbMotivo.Controls.Add(this.rbLavoro);
            this.gbMotivo.Location = new System.Drawing.Point(220, 141);
            this.gbMotivo.Name = "gbMotivo";
            this.gbMotivo.Size = new System.Drawing.Size(211, 249);
            this.gbMotivo.TabIndex = 6;
            this.gbMotivo.TabStop = false;
            this.gbMotivo.Text = "Motivo visita";
            // 
            // rbTurismo
            // 
            this.rbTurismo.AutoSize = true;
            this.rbTurismo.Location = new System.Drawing.Point(22, 142);
            this.rbTurismo.Name = "rbTurismo";
            this.rbTurismo.Size = new System.Drawing.Size(62, 17);
            this.rbTurismo.TabIndex = 6;
            this.rbTurismo.Text = "Turismo";
            this.rbTurismo.UseVisualStyleBackColor = true;
            // 
            // rbAltro
            // 
            this.rbAltro.AutoSize = true;
            this.rbAltro.Location = new System.Drawing.Point(22, 165);
            this.rbAltro.Name = "rbAltro";
            this.rbAltro.Size = new System.Drawing.Size(106, 17);
            this.rbAltro.TabIndex = 5;
            this.rbAltro.Text = "Altro (specificare)";
            this.rbAltro.UseVisualStyleBackColor = true;
            this.rbAltro.CheckedChanged += new System.EventHandler(this.rbAltro_CheckedChanged);
            // 
            // rbImmigrazione
            // 
            this.rbImmigrazione.AutoSize = true;
            this.rbImmigrazione.Location = new System.Drawing.Point(22, 119);
            this.rbImmigrazione.Name = "rbImmigrazione";
            this.rbImmigrazione.Size = new System.Drawing.Size(86, 17);
            this.rbImmigrazione.TabIndex = 4;
            this.rbImmigrazione.Text = "Immigrazione";
            this.rbImmigrazione.UseVisualStyleBackColor = true;
            // 
            // rbVisita
            // 
            this.rbVisita.AutoSize = true;
            this.rbVisita.Location = new System.Drawing.Point(22, 97);
            this.rbVisita.Name = "rbVisita";
            this.rbVisita.Size = new System.Drawing.Size(50, 17);
            this.rbVisita.TabIndex = 3;
            this.rbVisita.Text = "Visita";
            this.rbVisita.UseVisualStyleBackColor = true;
            // 
            // rbTransito
            // 
            this.rbTransito.AutoSize = true;
            this.rbTransito.Location = new System.Drawing.Point(22, 74);
            this.rbTransito.Name = "rbTransito";
            this.rbTransito.Size = new System.Drawing.Size(63, 17);
            this.rbTransito.TabIndex = 2;
            this.rbTransito.Text = "Transito";
            this.rbTransito.UseVisualStyleBackColor = true;
            // 
            // rbSalute
            // 
            this.rbSalute.AutoSize = true;
            this.rbSalute.Location = new System.Drawing.Point(22, 51);
            this.rbSalute.Name = "rbSalute";
            this.rbSalute.Size = new System.Drawing.Size(55, 17);
            this.rbSalute.TabIndex = 1;
            this.rbSalute.Text = "Salute";
            this.rbSalute.UseVisualStyleBackColor = true;
            // 
            // rbLavoro
            // 
            this.rbLavoro.AutoSize = true;
            this.rbLavoro.Checked = true;
            this.rbLavoro.Location = new System.Drawing.Point(22, 28);
            this.rbLavoro.Name = "rbLavoro";
            this.rbLavoro.Size = new System.Drawing.Size(58, 17);
            this.rbLavoro.TabIndex = 0;
            this.rbLavoro.TabStop = true;
            this.rbLavoro.Text = "Lavoro";
            this.rbLavoro.UseVisualStyleBackColor = true;
            // 
            // lblImg
            // 
            this.lblImg.AutoSize = true;
            this.lblImg.Location = new System.Drawing.Point(446, 247);
            this.lblImg.Name = "lblImg";
            this.lblImg.Size = new System.Drawing.Size(181, 13);
            this.lblImg.TabIndex = 7;
            this.lblImg.Text = "Cliccare per aggiungere un immagine";
            // 
            // Modale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 402);
            this.Controls.Add(this.lblImg);
            this.Controls.Add(this.gbMotivo);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnAnnulla);
            this.Controls.Add(this.pictureBoxModale);
            this.Controls.Add(this.gbAltroInf);
            this.Controls.Add(this.gbInformazioni);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Modale";
            this.Text = "Dati Personali";
            this.Load += new System.EventHandler(this.Modale_Load);
            this.gbInformazioni.ResumeLayout(false);
            this.gbInformazioni.PerformLayout();
            this.gbAltroInf.ResumeLayout(false);
            this.gbAltroInf.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxModale)).EndInit();
            this.gbMotivo.ResumeLayout(false);
            this.gbMotivo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbInformazioni;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNazionalita;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCognome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbAltroInf;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCodice;
        private System.Windows.Forms.PictureBox pictureBoxModale;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAltezza;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.Button btnAnnulla;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtEtà;
        private System.Windows.Forms.GroupBox gbMotivo;
        private System.Windows.Forms.RadioButton rbTransito;
        private System.Windows.Forms.RadioButton rbSalute;
        private System.Windows.Forms.RadioButton rbLavoro;
        private System.Windows.Forms.CheckBox checkAltezza;
        private System.Windows.Forms.CheckBox checkPeso;
        private System.Windows.Forms.CheckBox checkEta;
        private System.Windows.Forms.CheckBox checkCognome;
        private System.Windows.Forms.CheckBox checkNome;
        private System.Windows.Forms.TextBox txtDescrizione;
        private System.Windows.Forms.RadioButton rbImmigrazione;
        private System.Windows.Forms.RadioButton rbVisita;
        private System.Windows.Forms.RadioButton rbAltro;
        private System.Windows.Forms.RadioButton rbTurismo;
        private System.Windows.Forms.Label lblImg;
    }
}