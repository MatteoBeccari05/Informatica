﻿
namespace LavoroGruppo
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.inserimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visualizzaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.nomeCognomeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.codicePassaportoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificaToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.codicePassaportoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.selezionatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chiudiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impostazioniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attivaTemaScuroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disattivaTemaScuroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.premiumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lista = new System.Windows.Forms.ListBox();
            this.pictureBoxMain = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblVersione = new System.Windows.Forms.Label();
            this.riconoscimentiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMain)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inserimentoToolStripMenuItem,
            this.visualizzaToolStripMenuItem,
            this.modificaToolStripMenuItem,
            this.eliminaToolStripMenuItem,
            this.modificaToolStripMenuItem1,
            this.modificaToolStripMenuItem2,
            this.chiudiToolStripMenuItem,
            this.impostazioniToolStripMenuItem,
            this.premiumToolStripMenuItem,
            this.riconoscimentiToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(835, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // inserimentoToolStripMenuItem
            // 
            this.inserimentoToolStripMenuItem.Name = "inserimentoToolStripMenuItem";
            this.inserimentoToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.inserimentoToolStripMenuItem.Text = "Inserimento";
            this.inserimentoToolStripMenuItem.Click += new System.EventHandler(this.inserimentoToolStripMenuItem_Click);
            // 
            // visualizzaToolStripMenuItem
            // 
            this.visualizzaToolStripMenuItem.Name = "visualizzaToolStripMenuItem";
            this.visualizzaToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.visualizzaToolStripMenuItem.Text = "Visualizza";
            this.visualizzaToolStripMenuItem.Click += new System.EventHandler(this.visualizzaToolStripMenuItem_Click);
            // 
            // modificaToolStripMenuItem
            // 
            this.modificaToolStripMenuItem.Name = "modificaToolStripMenuItem";
            this.modificaToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.modificaToolStripMenuItem.Text = "Approva";
            this.modificaToolStripMenuItem.Click += new System.EventHandler(this.modificaToolStripMenuItem_Click);
            // 
            // eliminaToolStripMenuItem
            // 
            this.eliminaToolStripMenuItem.Name = "eliminaToolStripMenuItem";
            this.eliminaToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.eliminaToolStripMenuItem.Text = "Elimina";
            this.eliminaToolStripMenuItem.Click += new System.EventHandler(this.eliminaToolStripMenuItem_Click);
            // 
            // modificaToolStripMenuItem1
            // 
            this.modificaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nomeCognomeToolStripMenuItem,
            this.codicePassaportoToolStripMenuItem});
            this.modificaToolStripMenuItem1.Name = "modificaToolStripMenuItem1";
            this.modificaToolStripMenuItem1.Size = new System.Drawing.Size(57, 20);
            this.modificaToolStripMenuItem1.Text = "Ricerca";
            this.modificaToolStripMenuItem1.Click += new System.EventHandler(this.modificaToolStripMenuItem1_Click_1);
            // 
            // nomeCognomeToolStripMenuItem
            // 
            this.nomeCognomeToolStripMenuItem.Name = "nomeCognomeToolStripMenuItem";
            this.nomeCognomeToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.nomeCognomeToolStripMenuItem.Text = "Nome-Cognome";
            this.nomeCognomeToolStripMenuItem.Click += new System.EventHandler(this.nomeCognomeToolStripMenuItem_Click);
            // 
            // codicePassaportoToolStripMenuItem
            // 
            this.codicePassaportoToolStripMenuItem.Name = "codicePassaportoToolStripMenuItem";
            this.codicePassaportoToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.codicePassaportoToolStripMenuItem.Text = "Codice Passaporto";
            this.codicePassaportoToolStripMenuItem.Click += new System.EventHandler(this.codicePassaportoToolStripMenuItem_Click);
            // 
            // modificaToolStripMenuItem2
            // 
            this.modificaToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.codicePassaportoToolStripMenuItem1,
            this.selezionatoToolStripMenuItem});
            this.modificaToolStripMenuItem2.Name = "modificaToolStripMenuItem2";
            this.modificaToolStripMenuItem2.Size = new System.Drawing.Size(66, 20);
            this.modificaToolStripMenuItem2.Text = "Modifica";
            // 
            // codicePassaportoToolStripMenuItem1
            // 
            this.codicePassaportoToolStripMenuItem1.Name = "codicePassaportoToolStripMenuItem1";
            this.codicePassaportoToolStripMenuItem1.Size = new System.Drawing.Size(172, 22);
            this.codicePassaportoToolStripMenuItem1.Text = "Codice Passaporto";
            this.codicePassaportoToolStripMenuItem1.Click += new System.EventHandler(this.codicePassaportoToolStripMenuItem1_Click);
            // 
            // selezionatoToolStripMenuItem
            // 
            this.selezionatoToolStripMenuItem.Name = "selezionatoToolStripMenuItem";
            this.selezionatoToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.selezionatoToolStripMenuItem.Text = "Selezionato";
            this.selezionatoToolStripMenuItem.Click += new System.EventHandler(this.selezionatoToolStripMenuItem_Click);
            // 
            // chiudiToolStripMenuItem
            // 
            this.chiudiToolStripMenuItem.Name = "chiudiToolStripMenuItem";
            this.chiudiToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.chiudiToolStripMenuItem.Text = "Chiudi";
            this.chiudiToolStripMenuItem.Click += new System.EventHandler(this.chiudiToolStripMenuItem_Click);
            // 
            // impostazioniToolStripMenuItem
            // 
            this.impostazioniToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.attivaTemaScuroToolStripMenuItem,
            this.disattivaTemaScuroToolStripMenuItem});
            this.impostazioniToolStripMenuItem.Name = "impostazioniToolStripMenuItem";
            this.impostazioniToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.impostazioniToolStripMenuItem.Text = "Impostazioni";
            // 
            // attivaTemaScuroToolStripMenuItem
            // 
            this.attivaTemaScuroToolStripMenuItem.Name = "attivaTemaScuroToolStripMenuItem";
            this.attivaTemaScuroToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.attivaTemaScuroToolStripMenuItem.Text = "Attiva tema scuro";
            this.attivaTemaScuroToolStripMenuItem.Click += new System.EventHandler(this.attivaTemaScuroToolStripMenuItem_Click);
            // 
            // disattivaTemaScuroToolStripMenuItem
            // 
            this.disattivaTemaScuroToolStripMenuItem.Name = "disattivaTemaScuroToolStripMenuItem";
            this.disattivaTemaScuroToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.disattivaTemaScuroToolStripMenuItem.Text = "Disattiva tema scuro";
            this.disattivaTemaScuroToolStripMenuItem.Click += new System.EventHandler(this.disattivaTemaScuroToolStripMenuItem_Click);
            // 
            // premiumToolStripMenuItem
            // 
            this.premiumToolStripMenuItem.Name = "premiumToolStripMenuItem";
            this.premiumToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.premiumToolStripMenuItem.Text = "Premium";
            this.premiumToolStripMenuItem.Click += new System.EventHandler(this.premiumToolStripMenuItem_Click);
            // 
            // lista
            // 
            this.lista.FormattingEnabled = true;
            this.lista.Location = new System.Drawing.Point(12, 82);
            this.lista.Name = "lista";
            this.lista.Size = new System.Drawing.Size(597, 277);
            this.lista.TabIndex = 1;
            this.lista.SelectedIndexChanged += new System.EventHandler(this.lista_SelectedIndexChanged);
            // 
            // pictureBoxMain
            // 
            this.pictureBoxMain.BackColor = System.Drawing.Color.White;
            this.pictureBoxMain.Location = new System.Drawing.Point(631, 83);
            this.pictureBoxMain.Name = "pictureBoxMain";
            this.pictureBoxMain.Size = new System.Drawing.Size(181, 224);
            this.pictureBoxMain.TabIndex = 2;
            this.pictureBoxMain.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(700, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Foto";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(278, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Transitanti";
            // 
            // lblVersione
            // 
            this.lblVersione.AutoSize = true;
            this.lblVersione.Location = new System.Drawing.Point(711, 355);
            this.lblVersione.Name = "lblVersione";
            this.lblVersione.Size = new System.Drawing.Size(78, 13);
            this.lblVersione.TabIndex = 6;
            this.lblVersione.Text = "Versione: Base";
            // 
            // riconoscimentiToolStripMenuItem
            // 
            this.riconoscimentiToolStripMenuItem.Name = "riconoscimentiToolStripMenuItem";
            this.riconoscimentiToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.riconoscimentiToolStripMenuItem.Text = "Riconoscimenti";
            this.riconoscimentiToolStripMenuItem.Click += new System.EventHandler(this.riconoscimentiToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(835, 377);
            this.Controls.Add(this.lblVersione);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBoxMain);
            this.Controls.Add(this.lista);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Frontex";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMain)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem inserimentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visualizzaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eliminaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chiudiToolStripMenuItem;
        private System.Windows.Forms.ListBox lista;
        private System.Windows.Forms.PictureBox pictureBoxMain;
        private System.Windows.Forms.ToolStripMenuItem impostazioniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attivaTemaScuroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disattivaTemaScuroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem premiumToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblVersione;
        private System.Windows.Forms.ToolStripMenuItem modificaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem modificaToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem nomeCognomeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem codicePassaportoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem codicePassaportoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem selezionatoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem riconoscimentiToolStripMenuItem;
    }
}

