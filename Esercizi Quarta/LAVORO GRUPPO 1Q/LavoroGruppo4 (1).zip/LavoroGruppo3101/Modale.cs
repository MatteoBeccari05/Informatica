﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LavoroGruppo
{
    public partial class Modale : Form
    {
        public Persona p;
        public Modale()
        {
            InitializeComponent();
            MinimizeBox = false;
            MaximizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterScreen;
            txtDescrizione.Visible = false;
        }

        public Modale(Persona prs, bool tema, bool modifica, bool premium) : this() //aggiunto la variabiel modifica, dice se stiamo modificando o meno (rende editabili o meno alcuni campi)
        {
            if (modifica == false)
            {
                txtNome.Text = prs.Nome;
                txtCognome.Text = prs.Cognome;
                txtEtà.Text = Convert.ToString(prs.Eta);
                txtPeso.Text = Convert.ToString(prs.Peso);
                txtAltezza.Text = Convert.ToString(prs.Altezza);
                txtCodice.Text = prs.CodicePassaporto;
                txtNazionalita.Text = prs.Nazionalita;
                txtDescrizione.Text = prs.DescrizioneMotivazione;
                pictureBoxModale.Image = prs.Img;
                pictureBoxModale.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBoxModale.Click -= new EventHandler(pictureBoxModale_Click);//aggiunto
                txtNome.ReadOnly = true;
                txtCognome.ReadOnly = true;
                txtAltezza.ReadOnly = true;
                txtCodice.ReadOnly = true;
                txtEtà.ReadOnly = true;
                txtNazionalita.ReadOnly = true;
                txtPeso.ReadOnly = true;
                txtDescrizione.ReadOnly = true;
                switch (prs.Motivazione)
                {
                    case MotivoVisita.Lavoro: rbLavoro.Checked = true; break;
                    case MotivoVisita.Salute: rbSalute.Checked = true; break;
                    case MotivoVisita.Visita: rbVisita.Checked = true; break;
                    case MotivoVisita.Turismo: rbTurismo.Checked = true; break;
                    case MotivoVisita.Transito: rbTransito.Checked = true; break;
                    case MotivoVisita.Immigrazione: rbImmigrazione.Checked = true; break;
                    case MotivoVisita.Altro: rbAltro.Checked = true; txtDescrizione.Visible = true; break;
                }
                checkNome.Visible = false;
                checkCognome.Visible = false;
                checkAltezza.Visible = false;
                checkEta.Visible = false;
                checkPeso.Visible = false;
                rbAltro.Enabled = false;
                rbImmigrazione.Enabled = false;
                rbLavoro.Enabled = false;
                rbSalute.Enabled = false;
                rbVisita.Enabled = false;
                rbTransito.Enabled = false;
                rbTurismo.Enabled = false;
                btnAnnulla.Enabled = false;
                btnAnnulla.Visible = false;
                btnOK.Click -= btnOK_Click;
                btnOK.Click += new EventHandler(btnOK_Click2);
                btnOK.Text = "Chiudi";
            }
            else if (modifica == true) //se modifica è true solo il campo codice passaporto non può essere modificato, gli altri devono avere un valore base pari alla persona passata
            {
                if (premium == true) //visualizza o meno i check per il bypass se è premium o meno ----- SPOSTATO
                {
                    checkNome.Visible = true;
                    checkCognome.Visible = true;
                    checkEta.Visible = true;
                    checkPeso.Visible = true;
                    checkAltezza.Visible = true;
                    checkNome.Visible = true;
                    checkCognome.Visible = true;
                    checkNome.Checked = true;
                    checkCognome.Checked = true;
                    checkEta.Checked = true;
                    checkPeso.Checked = true;
                    checkAltezza.Checked = true;
                    AggiornaLBL();
                }
                else
                {
                    checkNome.Visible = false;
                    checkCognome.Visible = false;
                    checkEta.Visible = false;
                    checkPeso.Visible = false;
                    checkAltezza.Visible = false;
                }
                p = new Persona(prs);
                txtNome.Text = prs.Nome;
                txtCognome.Text = prs.Cognome;
                txtEtà.Text = Convert.ToString(prs.Eta);
                txtPeso.Text = Convert.ToString(prs.Peso);
                txtAltezza.Text = Convert.ToString(prs.Altezza);
                txtCodice.Text = prs.CodicePassaporto;
                txtNazionalita.Text = prs.Nazionalita;
                txtDescrizione.Text = prs.DescrizioneMotivazione;
                pictureBoxModale.Image = prs.Img;
                pictureBoxModale.SizeMode = PictureBoxSizeMode.StretchImage;
                txtCodice.ReadOnly = true;
                switch (prs.Motivazione)
                {
                    case MotivoVisita.Lavoro: rbLavoro.Checked = true; break;
                    case MotivoVisita.Salute: rbSalute.Checked = true; break;
                    case MotivoVisita.Visita: rbVisita.Checked = true; break;
                    case MotivoVisita.Turismo: rbTurismo.Checked = true; break;
                    case MotivoVisita.Transito: rbTransito.Checked = true; break;
                    case MotivoVisita.Immigrazione: rbImmigrazione.Checked = true; break;
                    case MotivoVisita.Altro: rbAltro.Checked = true; txtDescrizione.Visible = true; break;
                }
            }
            if (tema == true) //seleziona il colore del tema
            {
                Scuro();
            }
            else
            {
                Chiaro();
            }
           
        }
        public Modale(bool premium, bool tema) : this()
        {
            if (premium == true)    //visualizza o meno i check per il bypass se è premium o meno
            {
                checkNome.Visible = true;
                checkCognome.Visible = true;
                checkEta.Visible = true;
                checkPeso.Visible = true;
                checkAltezza.Visible = true;
                checkNome.Checked = true;
                checkCognome.Checked = true;
                checkEta.Checked = true;
                checkPeso.Checked = true;
                checkAltezza.Checked = true;
                AggiornaLBL();
            }
            else
            {
                checkNome.Visible = false;
                checkCognome.Visible = false;
                checkEta.Visible = false;
                checkPeso.Visible = false;
                checkAltezza.Visible = false;
            }
            if (tema == true)
            {
                Scuro();
            }
            else
            {
                Chiaro();
            }
        }

        private void AggiornaLBL()    //aggiorno le label per la versione premium 
        {
            label1.Text = "Nome";
            label2.Text = "Cognome";
            label5.Text = "Età";
            label7.Text = "Altezza";
            label6.Text = "Peso";
        }

        private void Modale_Load(object sender, EventArgs e)
        {

        }

        public void Scuro()         //tema scuro 
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            pictureBoxModale.BackColor = Color.White;
            label3.ForeColor = Color.White;
            label2.ForeColor = Color.White;
            label1.ForeColor = Color.White;
            label2.ForeColor = Color.White;
            label3.ForeColor = Color.White;
            label4.ForeColor = Color.White;
            label5.ForeColor = Color.White;
            label6.ForeColor = Color.White;
            label7.ForeColor = Color.White;
            rbAltro.ForeColor = Color.White;
            rbImmigrazione.ForeColor = Color.White;
            rbLavoro.ForeColor = Color.White;
            rbSalute.ForeColor = Color.White;
            rbTransito.ForeColor = Color.White;
            rbTurismo.ForeColor = Color.White;
            rbVisita.ForeColor = Color.White;
            gbInformazioni.ForeColor = Color.White;
            gbAltroInf.ForeColor = Color.White;
            gbMotivo.ForeColor = Color.White;
            lblImg.ForeColor = Color.White;

        }

        public void Chiaro()        //disattiva il tema scuro 
        {
            this.BackColor = Color.White;
            pictureBoxModale.BackColor = Color.Black;
            label1.ForeColor = Color.Black;
            label3.ForeColor = Color.Black;
            label2.ForeColor = Color.Black;
            label4.ForeColor = Color.Black;
            label5.ForeColor = Color.Black;
            label6.ForeColor = Color.Black;
            label7.ForeColor = Color.Black;
            rbAltro.ForeColor = Color.Black;
            rbImmigrazione.ForeColor = Color.Black;
            rbLavoro.ForeColor = Color.Black;
            rbSalute.ForeColor = Color.Black;
            rbTransito.ForeColor = Color.Black;
            rbTurismo.ForeColor = Color.Black;
            rbVisita.ForeColor = Color.Black;
            gbInformazioni.ForeColor = Color.Black;
            gbAltroInf.ForeColor = Color.Black;
            gbMotivo.ForeColor = Color.Black;
            lblImg.ForeColor = Color.Black;
        }

        public Persona Inserimento(out bool ritorno)
        {
            List<ByPassSet> lista = new List<ByPassSet>();
            Persona pr = null;
            string nome = txtNome.Text, cognome = txtCognome.Text, codPassaporto = txtCodice.Text, naz = txtNazionalita.Text, desc = txtDescrizione.Text;
            int eta, altezza;
            double peso;
            MotivoVisita motivo = MotivoVisita.Altro;
            ritorno = false;
            Bitmap img = (Bitmap)pictureBoxModale.Image;

            //controllo quale checkbox è stata selezionata con la versione premium
            if (checkNome.Checked == true) { lista.Add(ByPassSet.nome); }
            if (checkCognome.Checked == true) { lista.Add(ByPassSet.cognome); }
            if (checkEta.Checked == true) { lista.Add(ByPassSet.eta); }
            if (checkAltezza.Checked == true) { lista.Add(ByPassSet.altezza); }
            if (checkPeso.Checked == true) { lista.Add(ByPassSet.peso); }


            //controllo di quale radio button è stato selezionato
            if (rbLavoro.Checked == true) { motivo = MotivoVisita.Lavoro; }
            if (rbSalute.Checked == true) { motivo = MotivoVisita.Salute; }
            if (rbTransito.Checked == true) { motivo = MotivoVisita.Transito; }
            if (rbVisita.Checked == true) { motivo = MotivoVisita.Visita; }
            if (rbImmigrazione.Checked == true) { motivo = MotivoVisita.Immigrazione; }
            if (rbTurismo.Checked == true) { motivo = MotivoVisita.Turismo; }
            if (rbAltro.Checked == true) { motivo = MotivoVisita.Altro; }


            if (int.TryParse(txtEtà.Text, out eta) == false)        //vari controlli con try parse (età, altezza e peso)
                MessageBox.Show("Eta' non valida");                 //se ci sono errori nell'inserimento il programma non va in eccezione
            else if (int.TryParse(txtAltezza.Text, out altezza) == false)
                MessageBox.Show("Altezza non valida");
            else if (double.TryParse(txtPeso.Text, out peso) == false)
                MessageBox.Show("Peso non valido");
            else
            {
                try   //controllo tutti i dati, se c'è qualche eccezzione stampa un messaggio di errore
                {
                    pr = new Persona(nome, cognome, eta, naz, peso, altezza, codPassaporto, motivo, desc, img, lista);
                    ritorno = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Non e' stato possibile inserire una persona\n {ex.Message}");
                }
            }
            return pr;
        }

        private void btnAnnulla_Click(object sender, EventArgs e)       //botttone annulla del form modale 
        {
            DialogResult = DialogResult.Cancel;
        }

        private void btnOK_Click(object sender, EventArgs e)            //bottone ok form modale (inserimento)
        {
            bool test;
            p = Inserimento(out test);
            if (test == true)
            {
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private void btnOK_Click2(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            Close();
        }



        private void pictureBoxModale_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.CheckFileExists = true;    //permette di verificare l'esistenza del file
            op.InitialDirectory = System.IO.Directory.GetCurrentDirectory() + "\\Immagini\\";
            op.DefaultExt = "jpg";
            op.Filter = "jpg files (*.jpg)|*.jpg|bmp files (*.bmp)|*.bmp";   //visualizzo tutti i file che hanno la stessa estensione
            if (op.ShowDialog() == DialogResult.OK)
            {
                pictureBoxModale.Image = new Bitmap(op.FileName);
                pictureBoxModale.SizeMode = PictureBoxSizeMode.StretchImage;
            }

        }

        private void rbAltro_CheckedChanged(object sender, EventArgs e)    //se il motivo visita è selezionato su altro attiva la text box della descrizione
        {
            if (rbAltro.Checked == true)
            {
                txtDescrizione.Visible = true;
            }
            else
            {
                txtDescrizione.Visible = false;
            }
        }

        
    }
}
